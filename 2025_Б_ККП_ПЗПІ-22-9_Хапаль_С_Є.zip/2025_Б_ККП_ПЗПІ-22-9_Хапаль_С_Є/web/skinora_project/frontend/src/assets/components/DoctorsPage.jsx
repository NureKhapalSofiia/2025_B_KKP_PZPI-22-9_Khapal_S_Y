import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import "../styles/products.css";

export default function DoctorsPage() {
  const [active, setActive] = useState("doctors");
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctorId, setSelectedDoctorId] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchDoctors();
  }, []);



  const fetchDoctors = () => {
    const token = localStorage.getItem("token");

    fetch("http://localhost:8080/api/doctor/all", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Unauthorized");
        return res.json();
      })
      .then((data) => {
        console.log("Отримані лікарі:", data);
        setDoctors(data);
      })
      .catch((err) => console.error("Помилка завантаження лікарів:", err));
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userInfo");
    navigate("/");
  };

  const handleEdit = () => {
  if (!selectedDoctorId) {
    alert("Оберіть лікаря для редагування");
    return;
  }
  navigate(`/doctors/edit/${selectedDoctorId}`);
};


const handleDelete = async () => {
  if (!selectedDoctorId) {
    alert("Оберіть лікаря для видалення");
    return;
  }

  const confirmDelete = window.confirm("Ви впевнені, що хочете видалити цього лікаря?");
  if (!confirmDelete) return;

  try {
    const token = localStorage.getItem("token");
    const res = await fetch(`http://localhost:8080/api/admin/doctor/${selectedDoctorId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (res.ok) {
      alert("Лікаря видалено");
      setSelectedDoctorId(null);
      fetchDoctors(); // 🔁 оновлюємо таблицю
    } else {
        console.log("Статус:", res.status);
const text = await res.text();
console.log("Тіло відповіді:", text);
      console.warn("Помилка при видаленні лікаря:", text);
      alert("Помилка видалення: " + text);
    }
  } catch (err) {
    console.error("Мережева помилка:", err);
    alert("Не вдалося видалити лікаря.");
  }
};


  return (
    <div className="page-wrapper">
           <Sidebar active={active} setActive={setActive} />
      

      <div className="content-block">
         <div className="top-bar">
          
          <button className="action-button" onClick={handleEdit}>
            Редагувати
          </button>
          <button className="action-button" onClick={handleDelete}>
            Видалити
          </button>

        </div>

        <div className="table-wrapper">
          <table className="product-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>ПІБ</th>
                <th>Email</th>
                <th>Досвід (років)</th>
                <th>Біографія</th>
              </tr>
            </thead>
            <tbody>
              {doctors.map((doctor) => (
                <tr
                  key={doctor.id}
                  onClick={() => setSelectedDoctorId(doctor.id)}
                  className={selectedDoctorId === doctor.id ? "selected-row" : ""}
                >
                  <td>{doctor.id}</td>
                  <td>{doctor.user?.fullName || "—"}</td>
                  <td>{doctor.user?.email || "—"}</td>
                  <td>{doctor.expirienceYears}</td>
                  <td>{doctor.bio}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
