import React, { useState } from "react";
import Sidebar from "../components/Sidebar";
import { useParams } from "react-router-dom";
import "../styles/doctor.css";
import "../styles/addProduct.css";
import { useNavigate } from "react-router-dom";

export default function AddMeasurementPage() {
  const { patientId } = useParams();
  const [active, setActive] = useState("patients");
const navigate = useNavigate();

  const [formData, setFormData] = useState({
    moistureLevel: "",
    temperature: "",
    skinType: "Normal",
    comments: "",
  });

  const doctorId = JSON.parse(localStorage.getItem("userInfo"))?.id;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    try {
      const res = await fetch(`http://localhost:8080/api/doctor/patients/measurements`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          patientName: patientId, // або інше значення, якщо треба ім'я
          deviceId: 1, // заглушка або обрати з іншого джерела
          skinType: formData.skinType,
          moistureLevel: formData.moistureLevel,
          temperature: parseFloat(formData.temperature),
          comments: formData.comments,
        }),
      });

      if (!res.ok) throw new Error("Не вдалося зберегти аналіз");
      alert("Аналіз збережено успішно!");
      navigate("/doctor/patients");
    } catch (err) {
      alert("Помилка: " + err.message);
    }
  };

  return (
    <div className="add-page-wrapper">
      <div className="sidebar-background">
        <Sidebar active={active} setActive={setActive} />
      </div>

      <div className="add-content">
        <div className="add-title">Додати аналіз</div>

        <form className="add-form" onSubmit={handleSubmit}>
          <input
            type="text"
            name="moistureLevel"
            placeholder="moisture"
            value={formData.moistureLevel}
            onChange={handleChange}
          />

          <input
            type="text"
            name="temperature"
            placeholder="temperature"
            value={formData.temperature}
            onChange={handleChange}
          />

          <select
            name="skinType"
            className="dropdown-input"
            value={formData.skinType}
            onChange={handleChange}
          >
            <option value="Normal">Normal</option>
            <option value="Oily">Oily</option>
            <option value="Dry">Dry</option>
            <option value="Combination">Combination</option>
            <option value="Sensitive">Sensitive</option>
          </select>

          <textarea
            name="comments"
            placeholder="text"
            value={formData.comments}
            onChange={handleChange}
          />

          <button type="submit" className="action-button">
            Зберегти аналіз
          </button>
        </form>
      </div>
    </div>
  );
}
