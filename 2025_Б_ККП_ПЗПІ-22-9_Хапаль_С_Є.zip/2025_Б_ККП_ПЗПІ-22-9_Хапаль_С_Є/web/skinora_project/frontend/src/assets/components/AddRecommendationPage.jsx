import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { useParams } from "react-router-dom";
import "../styles/doctor.css";
import "../styles/addProduct.css";
import { useNavigate } from "react-router-dom";

export default function AddRecommendationPage() {
  const { patientId } = useParams();
  const [active, setActive] = useState("patients");
const navigate = useNavigate();

  const [productQuery, setProductQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [comment, setComment] = useState("");

  const doctorId = JSON.parse(localStorage.getItem("userInfo"))?.id;

  const handleProductInput = async (e) => {
    const value = e.target.value;
    setProductQuery(value);

    // Обнуляємо ID тільки якщо користувач вручну змінює текст після вибору
    if (!suggestions.some((p) => p.name.toLowerCase() === value.toLowerCase())) {
  setSelectedProductId(null);
}


    if (value.length < 2) {
      setSuggestions([]);
      return;
    }

    const token = localStorage.getItem("token");
    try {
      const res = await fetch(`http://localhost:8080/api/doctor/products/search?query=${encodeURIComponent(value)}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) throw new Error("Пошук не вдався");

      const data = await res.json();
      setSuggestions(data);
    } catch (err) {
      console.error("Помилка пошуку продуктів:", err);
      setSuggestions([]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!selectedProductId) {
      alert("Оберіть продукт зі списку!");
      return;
    }

    const token = localStorage.getItem("token");

    try {
      const url = `http://localhost:8080/api/doctor/patients/${patientId}/recommendations?doctorId=${doctorId}&productId=${selectedProductId}&text=${encodeURIComponent(comment)}`;

      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) throw new Error("Не вдалося зберегти рекомендацію");
      alert("Рекомендацію збережено успішно!");
      navigate("/doctor/patients");
    } catch (error) {
      alert("Помилка: " + error.message);
    }
  };

  return (
    <div className="add-page-wrapper">
      <div className="sidebar-background">
        <Sidebar active={active} setActive={setActive} />
      </div>

      <div className="add-content">
        <div className="add-title">Нова рекомендація</div>

        <form className="add-form" onSubmit={handleSubmit}>
          <div style={{ position: "relative", width: "100%" }}>
            <input
              type="text"
              name="product"
              placeholder="Назва продукту"
              value={productQuery}
              onChange={handleProductInput}
              autoComplete="off"
            />

            {suggestions.length > 0 && (
              <ul className="dropdown-list">
                {suggestions.map((item) => (
                  <li
                    key={item.id}
                    onClick={() => {
                      setProductQuery(item.name);
                      setSelectedProductId(item.id);
                      setSuggestions([]);
                    }}
                    className="dropdown-item"
                  >
                    {item.name}
                  </li>
                ))}
              </ul>
            )}
          </div>

          <textarea
            name="comment"
            placeholder="Коментар або деталі"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />

          <button type="submit" className="action-button">
            Зберегти рекомендацію
          </button>
        </form>
      </div>
    </div>
  );
}
