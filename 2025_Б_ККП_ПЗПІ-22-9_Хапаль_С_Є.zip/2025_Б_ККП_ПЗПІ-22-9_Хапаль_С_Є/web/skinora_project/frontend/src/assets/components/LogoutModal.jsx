// src/components/LogoutModal.jsx
import React from "react";
import "../styles/LogoutModal.css";

export default function LogoutModal({ onConfirm, onCancel }) {
  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <button className="close-btn" onClick={onCancel}>×</button>
        <p className="modal-text">Бажаєте вийти з акаунту?</p>
        <div className="modal-actions">
          <button className="modal-button" onClick={onConfirm}>Так</button>
          <button className="modal-button" onClick={onCancel}>Ні</button>
        </div>
      </div>
    </div>
  );
}
