// src/components/LoginPage.jsx
import React, { useState } from "react";
import "../styles/login.css";

export default function LoginPage({ onLogin }) {

  const [email, setEmail] = useState("");
const [password, setPassword] = useState("");

  const handleSubmit = async (e) => {
  e.preventDefault();

  try {
    const response = await fetch("http://localhost:8080/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });

    if (response.ok) {
      const data = await response.json();

      // Зберігаємо токен у localStorage (для наступних запитів)
      localStorage.setItem("token", data.token);

      // Можна також зберегти інформацію про користувача
      localStorage.setItem("user", JSON.stringify(data.userInfo));

      // Передаємо далі у додатку (наприклад, щоб перейти на сторінку продуктів)
onLogin({ email, password });
    } else {
      alert("Невірний логін або пароль");
    }
  } catch (error) {
    console.error("Помилка при вході:", error);
    alert("Сервер недоступний");
  }
};

  return (
    <div className="login-container">
      <form className="login-box" onSubmit={handleSubmit}>
        <h2>Вхід</h2>
        <input
          type="email"
          placeholder="ел. пошта"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="пароль"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button type="submit">Увійти</button>
      </form>
    </div>
  );
}

