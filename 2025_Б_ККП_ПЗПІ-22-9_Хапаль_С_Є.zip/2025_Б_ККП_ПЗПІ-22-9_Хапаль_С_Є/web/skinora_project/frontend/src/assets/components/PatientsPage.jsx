import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Sidebar from "../components/Sidebar";
import '../styles/products.css';

export default function PatientsPage() {
  const [patients, setPatients] = useState([]);
  const [active, setActive] = useState("patients");
  const navigate = useNavigate();
  const [selectedPatientId, setSelectedPatientId] = useState(null);


  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userInfo");
    navigate("/");
  };

  const fetchPatients = async () => {
    try {
      const token = localStorage.getItem("token");
      console.log("Токен:", token);

      const response = await axios.get('http://localhost:8080/api/admin/patients', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      console.log("Пацієнти:", response.data);
      setPatients(response.data);
    } catch (error) {
      console.error('Failed to fetch patients:', error);
      if (error.response) {
        console.error("Статус:", error.response.status);
        console.error("Дані:", error.response.data);
      }
    }
  };


  useEffect(() => {
    fetchPatients();
  }, []);

  return (
    <div className="page-wrapper">
           <Sidebar active={active} setActive={setActive} />
      

      <div className="content-block">
        <div className="top-bar">
          <button
  className="action-button"
  onClick={() => {
    if (!selectedPatientId) {
      alert("Оберіть пацієнта для перегляду");
      return;
    }
    navigate(`/patients/${selectedPatientId}`);
  }}
>
  Переглянути
</button>
        </div>
        <div className="table-wrapper">
          <table className="product-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Дата народження</th>
                <th>Доктор</th>
                <th>Нотатки</th>
              </tr>
            </thead>
            <tbody>
              {patients.map((p) => (
                <tr
  key={p.id}
  onClick={() => setSelectedPatientId(p.id)}
  className={selectedPatientId === p.id ? "selected-row" : ""}
>

                  <td>{p.id}</td>
                                    <td>{p.dateOfBirthday ? new Date(p.dateOfBirthday).toLocaleDateString('uk-UA') : '—'}</td>
                  <td>{p.doctor?.user?.fullName || '—'}</td>
                  <td>{p.notes}</td>
                
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
