import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import "../styles/products.css"; // або створити patientDetail.css

export default function PatientDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [active, setActive] = useState("patients");

  const [measurements, setMeasurements] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [usedProducts, setUsedProducts] = useState([]);
  const [usingProducts, setUsingProducts] = useState([]);

  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) return;

    const headers = { Authorization: `Bearer ${token}` };

    axios.get(`http://localhost:8080/api/admin/measurements/patient/${id}`, { headers })
      .then(res => setMeasurements(res.data))
      .catch(err => console.error("Помилка аналізів:", err));

    axios.get(`http://localhost:8080/api/admin/recommendation/patient/${id}`, { headers })
      .then(res => setRecommendations(res.data))
      .catch(err => console.error("Помилка рекомендацій:", err));

    axios.get(`http://localhost:8080/api/admin/used-products/patient/${id}`, { headers })
      .then(res => setUsedProducts(res.data))
      .catch(err => console.error("Помилка used:", err));

    axios.get(`http://localhost:8080/api/admin/using-products/patient/${id}`, { headers })
      .then(res => setUsingProducts(res.data))
      .catch(err => console.error("Помилка using:", err));
  }, [id]);

  return (
    <div className="page-wrapper">
      {/* Sidebar */}
          <Sidebar active={active} setActive={setActive} />
     

      {/* Main content */}
     <div className="content-block patient-detail">
  <div className="tables-grid">

    {/* Аналізи */}
    <div className="data-table">
      <h3>Аналізи</h3>
      <div className="table-scroll-wrapper">
        <table>
          <thead>
            <tr>
              <th>skin_type</th>
              <th>moisture</th>
              <th>temperature</th>
              <th>taken_at</th>
            </tr>
          </thead>
          <tbody>
            {measurements.map(m => (
              <tr key={m.id}>
                <td>{m.skinType}</td>
                <td>{m.moistureLevel}</td>
                <td>{m.temperature}</td>
                <td>{m.takenAt ? new Date(m.takenAt).toLocaleDateString('uk-UA') : '—'}</td>

              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>

    {/* Прописані засоби */}
    <div className="data-table">
      <h3>Прописані засоби</h3>
      <div className="table-scroll-wrapper">
        <table>
          <thead>
            <tr>
              <th>product</th>
              <th>doctor</th>
              <th>start</th>
              <th>end</th>
            </tr>
          </thead>
          <tbody>
            {recommendations.map(r => (
              <tr key={r.id}>
                <td>{r.product?.name}</td>
                <td>{r.doctor?.user?.fullName}</td>
               <td>{r.startDate ? new Date(r.startDate).toLocaleDateString('uk-UA') : '—'}</td>
          <td>{r.endDate ? new Date(r.endDate).toLocaleDateString('uk-UA') : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>

    {/* Використані засоби */}
    <div className="data-table">
      <h3>Використані засоби</h3>
      <div className="table-scroll-wrapper">
        <table>
          <thead>
            <tr>
              <th>product</th>
              <th>start</th>
              <th>end</th>
            </tr>
          </thead>
          <tbody>
            {usedProducts.map(p => (
              <tr key={p.id}>
                <td>{p.product?.name}</td>
                <td>{p.startDate ? new Date(p.startDate).toLocaleDateString('uk-UA') : '—'}</td>
          <td>{p.endDate ? new Date(p.endDate).toLocaleDateString('uk-UA') : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>

    {/* У використанні */}
    <div className="data-table">
      <h3>У використанні</h3>
      <div className="table-scroll-wrapper">
        <table>
          <thead>
            <tr>
              <th>product</th>
              <th>start</th>
              <th>end</th>
            </tr>
          </thead>
          <tbody>
            {usingProducts.map(p => (
              <tr key={p.id}>
                <td>{p.product?.name}</td>
                  <td>{p.startDate ? new Date(p.startDate).toLocaleDateString('uk-UA') : '—'}</td>
          <td>{p.endDate ? new Date(p.endDate).toLocaleDateString('uk-UA') : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>
      </div>
  );
}
