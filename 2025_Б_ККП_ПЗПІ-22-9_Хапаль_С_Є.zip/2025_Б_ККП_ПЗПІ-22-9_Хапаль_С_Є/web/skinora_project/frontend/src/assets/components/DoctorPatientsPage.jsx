import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { useNavigate } from "react-router-dom";
import "../styles/doctor.css";


export default function DoctorPatientsPage() {
  const [patients, setPatients] = useState([]);
  const [active, setActive] = useState("patients");
  const navigate = useNavigate();
const [selectedPatient, setSelectedPatient] = useState(null);

  const fetchDoctorPatients = async () => {
    const token = localStorage.getItem("token");

    try {
      const response = await fetch(`http://localhost:8080/api/doctor/patients?userId=9`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) throw new Error(`Помилка доступу: ${response.status}`);
      const data = await response.json();
      setPatients(data);
    } catch (error) {
      console.error("Не вдалося завантажити пацієнтів лікаря:", error);
    }
  };

  useEffect(() => {
    fetchDoctorPatients();
  }, []);

  return (
    <div className="page-wrapper" style={{ display: "flex" }}>
      <Sidebar active={active} setActive={setActive} />
      <div className="content-block centered-content" style={{ flex: 1, padding: "20px" }}>
        {/* Кнопка зверху */}
      <div className="top-button-container">
        <button
          className="action-button"
          onClick={() => {
            if (selectedPatient) {
              navigate(`/patients/${selectedPatient.id}`);
            } else {
              alert("Оберіть пацієнта для перегляду.");
            }
          }}
        >
          Переглянути
        </button>
        </div>

        <div style={{ display: "flex" }}>
          {/* Таблиця */}
          <div style={{ flex: 1 }}>
<table className="patients-table">              <thead>
                <tr>
                  <th>ID</th>
                  <th>ПІБ</th>
                  <th>Стать</th>
                  <th>Email</th>
                   <th>Нотатка</th> 
                </tr>
              </thead>
              <tbody>
                {patients.map((patient) => (
                 <tr
                  key={patient.id}
                  onClick={() => setSelectedPatient(patient)}
                  className={selectedPatient?.id === patient.id ? "selected-row" : ""}
                >

                    <td>{patient.id}</td>
    <td>{patient.fullName || "—"}</td> 
      <td>{patient.gender}</td>
<td>{patient.email || "—"}</td>
      <td>{patient.notes || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

           {/* Кнопки справа */}
          <div className="right-buttons">
            <button
              className="action-button"
              onClick={() => {
                if (selectedPatient) {
                  navigate(`/patients/${selectedPatient.id}/add-recommendation`);
                } else {
                  alert("Оберіть пацієнта спочатку.");
                }
              }}
            >
              Додати<br />рекомендацію
            </button>
            <button
              className="action-button"
              onClick={() => {
                if (selectedPatient) {
                  navigate(`/patients/${selectedPatient.id}/add-measurement`);
                } else {
                  alert("Оберіть пацієнта спочатку.");
                }
              }}
            >
              Додати<br />аналіз
            </button>

            <button
  className="action-button"
  onClick={() => {
    if (selectedPatient) {
      navigate(`/patients/${selectedPatient.id}/edit-note`);
    } else {
      alert("Оберіть пацієнта спочатку.");
    }
  }}
>
  Змінити<br />нотатку
</button>

          </div>
        </div>
      </div>
    </div>
  );
}
