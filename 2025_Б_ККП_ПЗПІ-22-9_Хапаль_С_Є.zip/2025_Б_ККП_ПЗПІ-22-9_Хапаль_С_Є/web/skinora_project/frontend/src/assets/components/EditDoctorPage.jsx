import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import "../styles/addProduct.css";

export default function EditDoctorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [active, setActive] = useState("doctors");

  const [expirienceYears, setExpirienceYears] = useState("");
  const [bio, setBio] = useState("");

  useEffect(() => {
    fetchDoctorData();
  }, []);

  const fetchDoctorData = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`http://localhost:8080/api/admin/doctor/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) throw new Error("Помилка завантаження лікаря");

      const doctor = await response.json();
      setExpirienceYears(doctor.expirienceYears || "");
      setBio(doctor.bio || "");
    } catch (err) {
      alert("Не вдалося отримати дані лікаря");
      console.error(err);
    }
  };


  
  const handleSave = async () => {
    try {
      const token = localStorage.getItem("token");

      const response = await fetch(`http://localhost:8080/api/admin/doctor/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          expirienceYears: Number(expirienceYears),
          bio,
        }),
      });

      if (response.ok) {
        alert("Лікаря оновлено!");
        navigate("/doctors");
      } else {
        const text = await response.text();
        alert("Помилка оновлення: " + text);
      }
    } catch (err) {
      console.error("Помилка запиту:", err);
      alert("Щось пішло не так...");
    }
  };

  return (
    <div className="add-page-wrapper">
           <Sidebar active={active} setActive={setActive} />
      

      <div className="add-content">
        <div className="add-title">Редагувати лікаря</div>
        <form className="add-form" onSubmit={(e) => e.preventDefault()}>
          <input
            type="number"
            placeholder="Досвід (років)"
            value={expirienceYears}
            onChange={(e) => setExpirienceYears(e.target.value)}
          />
          <textarea
            placeholder="Біографія"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
          />
          <button type="button" className="add-title11" onClick={handleSave}>
            Зберегти
          </button>
        </form>
      </div>
    </div>
  );
}
