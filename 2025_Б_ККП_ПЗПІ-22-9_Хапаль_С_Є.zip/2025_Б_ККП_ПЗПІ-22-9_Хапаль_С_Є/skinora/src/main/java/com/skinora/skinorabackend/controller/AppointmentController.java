package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.Appointment;
import com.skinora.skinorabackend.service.AppointmentService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@RequiredArgsConstructor
public class AppointmentController {

    private final AppointmentService appointmentService;

    // DTO для создания записи (соответствует клиентскому CreateAppointmentRequest)
    @Data
    public static class CreateAppointmentRequest {
        private PatientReference patient;
        private DoctorReference doctor;
        private String datetime; // ISO format string
        private String notes;
        private String status;
    }

    @Data
    public static class PatientReference {
        private Integer id;
    }

    @Data
    public static class DoctorReference {
        private Integer id;
    }

    // Отримати всі записи пацієнта
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<Appointment>> getAppointmentsByPatient(@PathVariable Integer patientId) {
        try {
            System.out.println("AppointmentController.getAppointmentsByPatient() called for patientId: " + patientId);
            List<Appointment> appointments = appointmentService.getAppointmentsByPatient(patientId);
            System.out.println("AppointmentController: returning " + appointments.size() + " appointments");
            return ResponseEntity.ok(appointments);
        } catch (Exception e) {
            System.err.println("Error getting appointments for patient " + patientId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Отримати всі записи лікаря
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<Appointment>> getAppointmentsByDoctor(@PathVariable Integer doctorId) {
        try {
            System.out.println("AppointmentController.getAppointmentsByDoctor() called for doctorId: " + doctorId);
            List<Appointment> appointments = appointmentService.getAppointmentsByDoctor(doctorId);
            System.out.println("AppointmentController: returning " + appointments.size() + " appointments");
            return ResponseEntity.ok(appointments);
        } catch (Exception e) {
            System.err.println("Error getting appointments for doctor " + doctorId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Створити новий запис
    @PostMapping
    public ResponseEntity<Appointment> createAppointment(@RequestBody CreateAppointmentRequest request) {
        try {
            System.out.println("==========================================");
            System.out.println("AppointmentController.createAppointment() called");
            System.out.println("Raw request: " + request);

            if (request == null) {
                System.err.println("ERROR: Request is null");
                return ResponseEntity.badRequest().build();
            }

            if (request.getPatient() == null) {
                System.err.println("ERROR: Patient is null");
                return ResponseEntity.badRequest().build();
            }

            if (request.getDoctor() == null) {
                System.err.println("ERROR: Doctor is null");
                return ResponseEntity.badRequest().build();
            }

            System.out.println("Patient ID: " + request.getPatient().getId());
            System.out.println("Doctor ID: " + request.getDoctor().getId());
            System.out.println("DateTime: " + request.getDatetime());
            System.out.println("Notes: " + request.getNotes());
            System.out.println("Status: " + request.getStatus());

            Appointment appointment = appointmentService.createAppointment(
                    request.getPatient().getId(),
                    request.getDoctor().getId(),
                    request.getDatetime(),
                    request.getNotes(),
                    request.getStatus() != null ? request.getStatus() : "PENDING"
            );

            System.out.println("AppointmentController: appointment created successfully with ID: " + appointment.getId());
            return ResponseEntity.ok(appointment);

        } catch (RuntimeException e) {
            System.err.println("RUNTIME ERROR in createAppointment: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            System.err.println("GENERAL ERROR in createAppointment: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Скасувати запис
    @PatchMapping("/{appointmentId}/cancel")
    public ResponseEntity<Void> cancelAppointment(@PathVariable Integer appointmentId) {
        try {
            System.out.println("AppointmentController.cancelAppointment() called for appointmentId: " + appointmentId);
            appointmentService.cancelAppointment(appointmentId);
            System.out.println("AppointmentController: appointment cancelled successfully");
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            System.err.println("Appointment not found: " + appointmentId);
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            System.err.println("Error cancelling appointment " + appointmentId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Підтвердити запис
    @PatchMapping("/{appointmentId}/confirm")
    public ResponseEntity<Void> confirmAppointment(@PathVariable Integer appointmentId) {
        try {
            System.out.println("AppointmentController.confirmAppointment() called for appointmentId: " + appointmentId);
            appointmentService.confirmAppointment(appointmentId);
            System.out.println("AppointmentController: appointment confirmed successfully");
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            System.err.println("Appointment not found: " + appointmentId);
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            System.err.println("Error confirming appointment " + appointmentId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Тестовый эндпоинт
    @GetMapping("/test")
    public ResponseEntity<String> test() {
        System.out.println("AppointmentController.test() called");
        return ResponseEntity.ok("Appointment controller is working!");
    }
}