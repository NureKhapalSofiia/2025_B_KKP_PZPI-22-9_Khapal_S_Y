package com.skinora.skinorabackend.service;

import com.skinora.skinorabackend.entity.*;
import com.skinora.skinorabackend.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ChatService {

    private final ChatRepository chatRepository;
    private final MessageRepository messageRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public ChatService(ChatRepository chatRepository, MessageRepository messageRepository,
                       PatientRepository patientRepository, DoctorRepository doctorRepository) {
        this.chatRepository = chatRepository;
        this.messageRepository = messageRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    //Отримати всі чати пацієнта
    public List<Chat> getChatsByPatient(Integer patientId) {
        System.out.println("ChatService.getChatsByPatient() called for patientId: " + patientId);
        List<Chat> chats = chatRepository.findByParticipant1_Id(patientId);
        System.out.println("Found " + chats.size() + " chats for patient " + patientId);
        return chats;
    }

    //Отримати чат пацієнта з конкретним лікарем
    public Chat getChatByPatientAndDoctor(Integer patientId, Integer doctorId) {
        System.out.println("ChatService.getChatByPatientAndDoctor() called for patient: " + patientId + ", doctor: " + doctorId);
        return chatRepository.findByParticipant1_IdAndParticipant2_Id(patientId, doctorId)
                .orElseThrow(() -> new RuntimeException("Chat between patient " + patientId + " and doctor " + doctorId + " not found"));
    }

    //Отримати всі повідомлення чату
    public List<Message> getMessagesByChat(Integer chatId) {
        System.out.println("ChatService.getMessagesByChat() called for chatId: " + chatId);

        // Проверяем существование чата
        Chat chat = chatRepository.findById(chatId)
                .orElseThrow(() -> new RuntimeException("Chat not found with id: " + chatId));

        // Получаем сообщения по chatId
        List<Message> messages = messageRepository.findByChatIdOrderBySentAt(chatId);
        System.out.println("Found " + messages.size() + " messages for chat " + chatId);
        return messages;
    }

    //Надіслати повідомлення в чат
    public Message sendMessage(Integer chatId, Message message) {
        System.out.println("ChatService.sendMessage() called for chatId: " + chatId + ", message: " + message.getMessage());

        Chat chat = chatRepository.findById(chatId)
                .orElseThrow(() -> new RuntimeException("Chat not found with id: " + chatId));

        message.setChatId(chatId);
        message.setSentAt(LocalDateTime.now());
        message.setIsRead(false);

        Message savedMessage = messageRepository.save(message);
        System.out.println("Message saved with id: " + savedMessage.getId());
        return savedMessage;
    }

    // Дополнительный метод для создания чата между пациентом и доктором
    public Chat createChat(Integer patientId, Integer doctorId) {
        System.out.println("ChatService.createChat() called for patient: " + patientId + ", doctor: " + doctorId);

        // Проверяем, не существует ли уже чат
        var existingChat = chatRepository.findByParticipant1_IdAndParticipant2_Id(patientId, doctorId);
        if (existingChat.isPresent()) {
            System.out.println("Chat already exists with id: " + existingChat.get().getId());
            return existingChat.get();
        }

        // Получаем пациента и доктора
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + patientId));

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + doctorId));

        // Создаем новый чат
        Chat newChat = Chat.builder()
                .participant1(patient)
                .participant2(doctor)
                .build();

        Chat savedChat = chatRepository.save(newChat);
        System.out.println("New chat created with id: " + savedChat.getId());
        return savedChat;
    }
}