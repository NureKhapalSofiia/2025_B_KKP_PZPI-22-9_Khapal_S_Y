package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.*;
import com.skinora.skinorabackend.repository.DoctorRepository;
import com.skinora.skinorabackend.repository.PatientRepository;
import com.skinora.skinorabackend.repository.ProductRepository;
import com.skinora.skinorabackend.service.DoctorService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/doctor")
public class DoctorController {

    private final DoctorService doctorService;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final ProductRepository productRepository;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class PatientResponse {
        private Integer id;
        private String fullName;
        private String gender;
        private String email;
        private String notes;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private static class AddMeasurementRequest {
        private String patientName;
        private Integer deviceId;
        private String skinType;
        private String moistureLevel;
        private LocalDateTime takenAt;
        private Double temperature;
        private String comments;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private static class AssignProductRequest {
        private Integer productId;
        private Integer doctorId;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CreateRecommendationRequest {
        private Integer doctorId;
        private String text;
    }

    public DoctorController(DoctorService doctorService, DoctorRepository doctorRepository, PatientRepository patientRepository, ProductRepository productRepository) {
        this.doctorService = doctorService;
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
        this.productRepository = productRepository;
    }

    @GetMapping("/products/search")
    public List<Product> searchProducts(@RequestParam String query) {
        return productRepository.findByNameContainingIgnoreCase(query);
    }

    @PutMapping("/patients/{id}/note")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR')")
    public ResponseEntity<String> updateNote(
            @PathVariable Integer id,
            @RequestParam String note
    ) {
        Optional<Patient> optionalPatient = patientRepository.findById(id);
        if (optionalPatient.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Пацієнта не знайдено");
        }

        Patient patient = optionalPatient.get();
        patient.setNotes(note);
        patientRepository.save(patient);

        return ResponseEntity.ok("Нотатку оновлено");
    }


    // Получить всех пациентов врача
    @GetMapping("/patients")
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR')")
    public ResponseEntity<List<PatientResponse>> getPatients(@RequestParam Integer userId) {
        Optional<Doctor> doctorOpt = doctorRepository.findByUserId(userId);
        if (doctorOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Doctor doctor = doctorOpt.get();
        List<Patient> ownPatients = patientRepository.findByDoctorId(doctor.getId());

        List<PatientResponse> result = ownPatients.stream()
                .map(patient -> new PatientResponse(
                        patient.getId(),
                        patient.getUser().getFullName(),
                        patient.getGender(),
                        patient.getUser().getEmail(),
                        patient.getNotes() // <- тут
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(result);
    }



    // Получить одного пациента врача
    @GetMapping("/{doctorId}/patients/{patientId}")
    public Patient getPatientById(@PathVariable Integer doctorId, @PathVariable Integer patientId) {
        return doctorService.getPatient(doctorId, patientId);
    }

    // Добавить измерение состояния кожи
    @PostMapping("/patients/measurements")
    public void addMeasurements(@RequestBody AddMeasurementRequest request){
        doctorService.addMeasurement(
                request.getPatientName(),
                request.getDeviceId(),
                request.getSkinType(),
                request.getMoistureLevel(),
                request.getTemperature(),
                request.getComments()
        );
    }

    // Создать рекомендацию для пациента
    @PostMapping("/patients/{id}/recommendations")
    @PreAuthorize("hasAnyRole('DOCTOR', 'ADMIN')")
    public void addRecommendations(
            @RequestParam Integer doctorId,
            @RequestParam Integer productId, // ⬅️ додано!
            @PathVariable Integer id,
            @RequestParam String text) {
        doctorService.createRecommendation(doctorId, id, productId, text);
    }

    // Получить все записи к врачу
    @GetMapping("/appointments")
    public List<Appointment> getList (@RequestParam Integer doctorId){
        return doctorService.getAppointments(doctorId);
    }

    // Назначить продукт пациенту
    @PostMapping("/patients/{patientId}/assign-product")


    // Получить все отзывы о враче
    @GetMapping("/feedbacks")
    public List<Feedback> getFeedbacks(@RequestParam Integer doctorId) {
        return doctorService.getFeedbacks(doctorId);
    }

    // Получить всех докторов
    @GetMapping("/all")
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        try {
            List<Doctor> doctors = doctorService.getAllDoctors();
            return ResponseEntity.ok(doctors);
        } catch (Exception e) {
            // Логируем ошибку
            System.err.println("Error getting all doctors: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Пошук лікарів за ім'ям
    @GetMapping("/search")
    public ResponseEntity<List<Doctor>> searchDoctorsByName(@RequestParam("name") String name) {
        try {
            List<Doctor> doctors = doctorService.searchDoctorsByName(name);
            return ResponseEntity.ok(doctors);
        } catch (Exception e) {
            System.err.println("Error searching doctors by name: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Пошук лікарів за спеціалізації
    @GetMapping("/specialization/{specialization}")
    public ResponseEntity<List<Doctor>> getDoctorsBySpecialization(@PathVariable String specialization) {
        try {
            List<Doctor> doctors = doctorService.getDoctorsBySpecialization(specialization);
            return ResponseEntity.ok(doctors);
        } catch (Exception e) {
            System.err.println("Error getting doctors by specialization: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Пфолучить доктора по ID
    @GetMapping("/{id}")
    public ResponseEntity<Doctor> getDoctorById(@PathVariable Integer id) {
        try {
            Doctor doctor = doctorService.getDoctorById(id);
            return ResponseEntity.ok(doctor);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            System.err.println("Error getting doctor by ID: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Простой тестовый эндпоинт для проверки
    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return ResponseEntity.ok("Doctors controller is working!");
    }
}
