package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.Product;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.skinora.skinorabackend.service.ProductService;

import java.util.List;

@RestController
@RequestMapping("/api/public")
public class PublicProductController {

    private final ProductService productService;

    public PublicProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProductsPublic() {
        List<Product> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }
}
