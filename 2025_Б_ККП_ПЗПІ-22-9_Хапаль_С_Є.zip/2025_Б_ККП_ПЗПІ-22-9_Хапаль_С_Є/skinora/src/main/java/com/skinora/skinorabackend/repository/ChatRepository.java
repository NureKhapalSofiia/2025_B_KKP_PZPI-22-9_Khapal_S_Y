package com.skinora.skinorabackend.repository;

import com.skinora.skinorabackend.entity.Chat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ChatRepository extends JpaRepository<Chat, Integer> {

    Optional<Chat> findById(Integer id);

    List<Chat> findByParticipant1_Id(Integer patientId);

    Optional<Chat> findByParticipant1_IdAndParticipant2_Id(Integer patientId, Integer doctorId);

    List<Chat> findAllByParticipant2_Id(Integer doctorId);

    void deleteAllByParticipant2_Id(Integer doctorId);

    @Query("SELECT c FROM Chat c " +
            "JOIN FETCH c.participant1 p1 " +
            "JOIN FETCH c.participant2 p2 " +
            "JOIN FETCH p1.user " +
            "JOIN FETCH p2.user " +
            "WHERE p1.id = :patientId")
    List<Chat> findByPatientIdWithUsers(@Param("patientId") Integer patientId);
}