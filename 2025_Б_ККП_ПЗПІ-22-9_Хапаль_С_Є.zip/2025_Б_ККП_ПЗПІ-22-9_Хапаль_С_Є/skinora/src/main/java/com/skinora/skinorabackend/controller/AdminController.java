package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.*;
import com.skinora.skinorabackend.repository.*;
import com.skinora.skinorabackend.service.AdminService;
import com.skinora.skinorabackend.service.DoctorService;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;
    private final AdminRepository adminRepository;
    private final DoctorRepository doctorRepository;
    private final ChatRepository chatRepository;
    private final PatientRepository patientRepository;
    private final MessageRepository chatMessageRepository;
    private final MeasurementRepository measurementRepository;
    private final RecommendationRepository recommendationRepository;
    private final UsedProductRepository usedProductRepository;
    private final UsingProductRepository usingProductRepository;
    private final UserRepository userRepository;

    private final PrescribedProductRepository prescribedProductRepository;
    private final FeedbackRepository feedbackRepository;
    private final AppointmentRepository appointmentRepository;

    public AdminController(UserRepository userRepository, AdminService adminService, AdminRepository adminRepository, DoctorRepository doctorRepository, ChatRepository chatRepository, PatientRepository patientRepository, MessageRepository chatMessageRepository, MeasurementRepository measurementRepository, PrescribedProductRepository prescribedProductRepository, RecommendationRepository recommendationRepository, UsedProductRepository usedProductRepository, UsingProductRepository usingProductRepository, FeedbackRepository feedbackRepository, AppointmentRepository appointmentRepository) {
        this.adminService = adminService;
        this.adminRepository = adminRepository;
        this.doctorRepository = doctorRepository;
        this.chatRepository = chatRepository;
        this.patientRepository = patientRepository;
        this.chatMessageRepository = chatMessageRepository;
        this.measurementRepository = measurementRepository;
        this.prescribedProductRepository = prescribedProductRepository;
        this.recommendationRepository = recommendationRepository;
        this.usedProductRepository = usedProductRepository;
        this.usingProductRepository = usingProductRepository;
        this.feedbackRepository = feedbackRepository;
        this.appointmentRepository = appointmentRepository;
        this.userRepository = userRepository;

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AddPoductRequest{
        private Integer adminId;
        private String name;
        private String brand;
        private String description;
        private Boolean isCertified;
        private String category;
    }

    //Додати продукт
    @PostMapping("/product")
    public void addProduct(@RequestBody AddPoductRequest request) {
        Admin admin = adminRepository.findByUser_Id(request.getAdminId())
                .orElseThrow(() -> new RuntimeException("Admin not found by user id"));


        adminService.addProduct(
        request.getName(),
        request.getBrand(),
        request.getDescription(),
        request.getIsCertified(),
        admin,
        request.getCategory()
        );
    }

    // Призначити лікаря пацієнту
    @PostMapping("/doctor/{doctorId}/patient/{patientId}")
    public void setDoctor(@PathVariable Integer doctorId, @PathVariable Integer patientId) {
        adminService.assignDoctorToPatient(doctorId, patientId);
    }

    //Редагувати продукт
    @PatchMapping("/{productId}")
    public Product updateProduct(@PathVariable Integer productId, @RequestBody Product updatedProductData) {
        return adminService.updateProduct(productId, updatedProductData);
    }

    //Видалити продукт
    @DeleteMapping("/{productId}")
    public void deleteProduct(@PathVariable Integer productId) {
        adminService.deleteProduct(productId);
    }

    //Отримати всіх користувачів
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return adminService.getAllUsers();
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return adminService.getAllProducts();
    }

    @GetMapping("/product/{id}")
    public Product getProductById(@PathVariable Integer id) {
        return adminService.getProductById(id);
    }

    @DeleteMapping("/patient/{id}")
    @Transactional
    public ResponseEntity<Void> deletePatientById(@PathVariable Integer id) {
        Patient patient = patientRepository.findById(id).orElse(null);
        if (patient == null) return ResponseEntity.notFound().build();

        // 1. Видаляємо пов’язані записи вручну
        measurementRepository.deleteAllByPatientId(id);
        recommendationRepository.deleteAllByPatientId(id);
        usedProductRepository.deleteAllByPatientId(id);
        usingProductRepository.deleteAllByPatientId(id);

        // 2. Видаляємо пацієнта
        patientRepository.deleteById(id);

        // 3. Видаляємо також обліковий запис user
        if (patient.getUser() != null) {
            userRepository.deleteById(patient.getUser().getId());
        }

        return ResponseEntity.noContent().build();
    }



    //Отримати загальну статистику системи
    @GetMapping("/statistics")
    public Map<String, Object> getSystemStatistics() {
        return adminService.getSystemStatistics();
    }

    // Видалити лікаря
    @Transactional
    @DeleteMapping("/doctor/{id}")
    public void deleteDoctor(@PathVariable Integer id) {
        // Знайти всі чати, де лікар є participant2
        List<Chat> chats = chatRepository.findAllByParticipant2_Id(id);
        appointmentRepository.deleteByDoctorId(id);

        prescribedProductRepository.clearDoctor(id);
        recommendationRepository.clearDoctor(id);
        feedbackRepository.clearDoctor(id);

        for (Chat chat : chats) {
            // Видалити повідомлення по chat.id
            chatMessageRepository.deleteAllByChatId(chat.getId());
            // Видалити сам чат
            chatRepository.deleteById(chat.getId());
        }

        List<Patient> patients = patientRepository.findAll();
        for (Patient patient : patients) {
            if (patient.getDoctor() != null && patient.getDoctor().getId() == (id)) {
                patient.setDoctor(null);
                patientRepository.save(patient);
            }
        }

        // Видалити лікаря
        doctorRepository.deleteById(id);
    }

    @GetMapping("/patients")
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @GetMapping("/measurements/patient/{patientId}")
    public List<Measurement> getMeasurementsByPatient(@PathVariable Integer patientId) {
        return measurementRepository.findByPatientId(patientId);
    }

    @GetMapping("/recommendation/patient/{patientId}")
    public List<Recommendation> getPrescribedProducts(@PathVariable Integer patientId) {
        return  recommendationRepository.findByPatientId(patientId);
    }

    @GetMapping("/used-products/patient/{patientId}")
    public List<UsedProduct> getUsedProducts(@PathVariable Integer patientId) {
        return usedProductRepository.findByPatientId(patientId);
    }

    @GetMapping("/using-products/patient/{patientId}")
    public List<UsingProduct> getUsingProducts(@PathVariable Integer patientId) {
        return usingProductRepository.findByPatientId(patientId);
    }



    // Отримати лікаря за ID
    @GetMapping("/doctor/{id}")
    public Doctor getDoctor(@PathVariable Integer id) {
        return doctorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Лікаря не знайдено з id: " + id));
    }

    // Оновити лікаря
    @PatchMapping("/doctor/{id}")
    public Doctor updateDoctor(@PathVariable Integer id, @RequestBody Doctor updatedDoctor) {
        Doctor existingDoctor = doctorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Лікаря не знайдено з id: " + id));

        if (updatedDoctor.getExpirienceYears() != null) {
            existingDoctor.setExpirienceYears(updatedDoctor.getExpirienceYears());
        }
        if (updatedDoctor.getBio() != null) {
            existingDoctor.setBio(updatedDoctor.getBio());
        }

        return doctorRepository.save(existingDoctor);
    }

}
