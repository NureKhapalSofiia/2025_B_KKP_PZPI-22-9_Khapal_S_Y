package com.skinora.skinorabackend.repository;

import com.skinora.skinorabackend.entity.Doctor;
import com.skinora.skinorabackend.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer> {

    Optional<Patient> findByUserEmail(String email);
    List<Patient> findByDoctorId(Integer DoctorId);
    @Query("SELECT p FROM Patient p WHERE LOWER(p.user.fullName) = LOWER(:name)")
    Optional<Patient> findByName(@Param("name") String name);
    Optional<Patient> findByUserId(Integer userId);
    Optional<Patient> findByDoctor_IdAndId(Integer doctorId, Integer id);
    @Query("SELECT p FROM Patient p WHERE p.doctor.id = :doctorId AND p.id = :patientId")
    Optional<Patient> findByDoctorIdAndId(@Param("doctorId") Integer doctorId, @Param("patientId") Integer patientId);
    Optional<Patient> findByIdAndDoctor_Id(Long patientId, Long doctorId);
}
