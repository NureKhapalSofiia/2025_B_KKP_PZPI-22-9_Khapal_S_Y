package com.skinora.skinorabackend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name="appointments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.EAGER)  // EAGER для правильной сериализации JSON
    @JoinColumn(name="patient_id", nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.EAGER)  // EAGER для правильной сериализации JSON
    @JoinColumn(name="doctor_id", nullable = false)
    private Doctor doctor;

    @Column(name="datetime", nullable = false)
    private LocalDateTime datetime;

    @Column(nullable = true)  // ИСПРАВЛЕНО: notes может быть пустым
    private String notes;

    @Column(nullable = false)
    private String status; // наприклад: "PENDING", "CONFIRMED", "CANCELLED"
}