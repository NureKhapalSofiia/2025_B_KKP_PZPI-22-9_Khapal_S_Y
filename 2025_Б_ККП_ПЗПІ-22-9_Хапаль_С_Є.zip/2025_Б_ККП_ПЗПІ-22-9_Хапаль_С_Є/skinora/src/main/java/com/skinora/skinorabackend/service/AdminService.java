package com.skinora.skinorabackend.service;

import com.skinora.skinorabackend.entity.*;
import com.skinora.skinorabackend.repository.*;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AdminService {

    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final AppointmentRepository appointmentRepository;
    private final UsedProductRepository usedProductRepository;
    private final UsingProductRepository usingProductRepository;
    private final FavoriteProductRepository favoriteProductRepository;
    private final RecommendationRepository recommendationRepository;
    private final PrescribedProductRepository prescribedProductRepository;

    public AdminService(DoctorRepository doctorRepository, PatientRepository patientRepository, ProductRepository productRepository, UserRepository userRepository, AppointmentRepository appointmentRepository, UsedProductRepository usedProductRepository, UsingProductRepository usingProductRepository, FavoriteProductRepository favoriteProductRepository, RecommendationRepository recommendationRepository, PrescribedProductRepository prescribedProductRepository) {
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.appointmentRepository = appointmentRepository;
        this.usedProductRepository = usedProductRepository;
        this.usingProductRepository = usingProductRepository;
        this.favoriteProductRepository = favoriteProductRepository;
        this.recommendationRepository = recommendationRepository;
        this.prescribedProductRepository = prescribedProductRepository;
    }

    // Призначити лікаря пацієнту
    public void assignDoctorToPatient(Integer doctorId, Integer patientId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + doctorId));

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + patientId));

        // Призначення лікаря пацієнту напряму (через поле doctor в Patient)
        patient.setDoctor(doctor);

        patientRepository.save(patient);
    }


    //Додати продукт
    public void addProduct(String name, String brand, String description, Boolean isCertified, Admin createdBy, String category) {
        Product product = new Product();

        product.setName(name);
        product.setBrand(brand);
        product.setDescription(description);
        product.setCertified(isCertified);
        product.setCreatedBy(createdBy);
        product.setCreatedAt(LocalDateTime.now());
        product.setUpdatedAt(LocalDateTime.now());
        product.setCategory(category);

        productRepository.save(product);
    }

    //Oновити
    @Transactional
    public Product updateProduct(Integer productId, Product updatedProductData) {
        Product existingProduct = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));

        if (updatedProductData.getName() != null) {
            existingProduct.setName(updatedProductData.getName());
        }
        if (updatedProductData.getBrand() != null) {
            existingProduct.setBrand(updatedProductData.getBrand());
        }
        if (updatedProductData.getDescription() != null) {
            existingProduct.setDescription(updatedProductData.getDescription());
        }
        if (updatedProductData.getCategory() != null) {
            existingProduct.setCategory(updatedProductData.getCategory());
        }
        if (updatedProductData.getCreatedBy() != null) {
            existingProduct.setCreatedBy(updatedProductData.getCreatedBy());
        }

        existingProduct.setUpdatedAt(LocalDateTime.now());

        return productRepository.save(existingProduct);
    }

    //Видалити продукт
    public void deleteProduct(Integer productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found with id: " + productId));

        // Видалення використаних продуктів
        List<UsedProduct> usedProducts = usedProductRepository.findAll();
        usedProducts.stream()
                .filter(up -> product.equals(up.getProduct()))
                .forEach(usedProductRepository::delete);

        // Видалення тих, що зараз використовуються
        List<UsingProduct> usingProducts = usingProductRepository.findAll();
        usingProducts.stream()
                .filter(up -> product.equals(up.getProduct()))
                .forEach(usingProductRepository::delete);

        // Улюблені
        List<FavoriteProduct> favoriteProducts = favoriteProductRepository.findAll();
        favoriteProducts.stream()
                .filter(fp -> product.equals(fp.getProduct()))
                .forEach(favoriteProductRepository::delete);

        // Рекомендовані
        List<Recommendation> recommendations = recommendationRepository.findAll();
        recommendations.stream()
                .filter(r -> product.equals(r.getProduct()))
                .forEach(recommendationRepository::delete);

        // Призначені
        List<PrescribedProduct> prescribedProducts = prescribedProductRepository.findAll();
        prescribedProducts.stream()
                .filter(pp -> product.equals(pp.getProduct()))
                .forEach(prescribedProductRepository::delete);

        // Нарешті — сам продукт
        productRepository.delete(product);
    }



    //Отримати всіх користувачів
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Integer productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Продукт не знайдено: " + productId));
    }

    //Отримати загальну статистику системи
    public Map<String, Object> getSystemStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalUsers", userRepository.count());
        stats.put("totalDoctors", doctorRepository.count());
        stats.put("totalPatients", patientRepository.count());
        stats.put("totalProducts", productRepository.count());
        stats.put("totalAppointments", appointmentRepository.count());
        return stats;
    }



}
