package com.skinora.skinorabackend.controller;

public class ListController {
}
