package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.*;
import com.skinora.skinorabackend.repository.DoctorRepository;
import com.skinora.skinorabackend.repository.PatientRepository;
import com.skinora.skinorabackend.service.PatientService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/api/patient")
public class PatientController {

    private final PatientService patientService;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'DOCTOR')")
    public ResponseEntity<List<Patient>> getPatients(Authentication authentication) {
        User user = (User) authentication.getPrincipal();

        if (user.getRole().getName().equals("ADMIN")) {
            return ResponseEntity.ok(patientRepository.findAll());
        }

        // Якщо роль DOCTOR — витягуємо тільки своїх пацієнтів
        Optional<Doctor> doctorOpt = doctorRepository.findByUserId(user.getId());
        if (doctorOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Doctor doctor = doctorOpt.get();
        List<Patient> ownPatients = patientRepository.findByDoctorId(doctor.getId());
        return ResponseEntity.ok(ownPatients);
    }


    @GetMapping("/{id}")
    public Patient getPatientById(@PathVariable Integer id){
        return patientService.getPatientById(id);
    }

    @GetMapping("/{id}/measurement")
    public List<Measurement> getSkinMeasurement(@PathVariable Integer id){
        return patientService.getSkinMeasurements(id);
    }

    @GetMapping("/{id}/recommendations")
    public List<Recommendation> getPersonalizedRecommendations(@PathVariable Integer id){
        return patientService.getPersonalizedRecommendations(id);
    }

    @GetMapping("/{id}/used-products")
    public List<UsedProduct> getUsedProducts(@PathVariable Integer id){
        return patientService.getUsedProducts(id);
    }

    @PostMapping("/{id}/used-products")
    public void addUsedProduct(@PathVariable Integer id, @RequestBody UsedProduct usedProduct){
        patientService.addProductToUsed(id, usedProduct.getId());
    }

    @PutMapping("/{id}/notes")
    public ResponseEntity<?> updateNotes(
            @PathVariable Long id,
            @RequestParam Long doctorId, // або отримуй із токена
            @RequestBody String notes
    ) {
        patientService.updateNotes(doctorId, id, notes);
        return ResponseEntity.ok("Нотатки оновлено");
    }
}
