package com.skinora.app.data.model

import com.google.gson.annotations.SerializedName

// Модель ответа при логине
data class AuthResponse(
    @SerializedName("token")
    val token: String,
    @SerializedName("user")
    val user: User? = null
)

// Модель ответа при регистрации (если нужна)
data class UserResponse(
    @SerializedName("user")
    val user: User,
    @SerializedName("message")
    val message: String? = null
)

// Модель для роли пользователя
data class RoleResponse(
    @SerializedName("role")
    val role: String,
    @SerializedName("roleId")
    val roleId: Int
)

// Запросы
data class LoginRequest(
    @SerializedName("email")
    val email: String,
    @SerializedName("password")
    val password: String
)

data class RegisterRequest(
    @SerializedName("name")
    val name: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("roleName")
    val roleName: String
)