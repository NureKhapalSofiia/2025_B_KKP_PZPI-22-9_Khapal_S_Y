package com.skinora.app.presentation.chat

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.ChatRepository
import com.skinora.app.data.repository.DoctorRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DoctorSearchState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val searchQuery: String = "",
    val doctors: List<DoctorSearchResult> = emptyList(),
    val isCreatingChat: Boolean = false,
    val patientId: Int? = null,
    val currentUserEmail: String = ""
)

@HiltViewModel
class DoctorSearchViewModel @Inject constructor(
    private val doctorRepository: DoctorRepository,
    private val chatRepository: ChatRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(DoctorSearchState())
    val uiState: StateFlow<DoctorSearchState> = _uiState.asStateFlow()

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userEmail = preferencesManager.getUserEmail().first()
                val userId = preferencesManager.getUserId().first()

                Log.d("DoctorSearchViewModel", "Current user email: $userEmail")
                Log.d("DoctorSearchViewModel", "Current user ID: $userId")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(
                    patientId = userId,
                    currentUserEmail = userEmail
                )

                Log.d("DoctorSearchViewModel", "Set patientId: $userId for user: $userEmail")

                // Загружаем докторов после получения ID пациента
                loadAllDoctors()

            } catch (e: Exception) {
                Log.e("DoctorSearchViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження користувача: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        if (query.isBlank()) {
            loadAllDoctors()
        } else {
            searchDoctors(query)
        }
    }

    private fun searchDoctors(query: String) {
        Log.d("DoctorSearchViewModel", "Searching doctors with query: $query")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = doctorRepository.searchDoctorsByName(query)) {
                is Resource.Success -> {
                    Log.d("DoctorSearchViewModel", "Doctors found: ${result.data?.size ?: 0} items")
                    val doctors = result.data ?: emptyList()

                    _uiState.value = _uiState.value.copy(
                        doctors = doctors,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("DoctorSearchViewModel", "Error searching doctors: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        doctors = emptyList(),
                        isLoading = false,
                        error = "Помилка пошуку лікарів: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    private fun loadAllDoctors() {
        Log.d("DoctorSearchViewModel", "Loading all doctors")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = doctorRepository.getAllDoctors()) {
                is Resource.Success -> {
                    Log.d("DoctorSearchViewModel", "All doctors loaded: ${result.data?.size ?: 0} items")
                    val doctors = result.data ?: emptyList()

                    _uiState.value = _uiState.value.copy(
                        doctors = doctors,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("DoctorSearchViewModel", "Error loading doctors: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        doctors = emptyList(),
                        isLoading = false,
                        error = "Помилка завантаження лікарів: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun createChatWithDoctor(doctor: DoctorSearchResult, onChatCreated: (Chat) -> Unit) {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо створити чат: невірний ID користувача"
            )
            return
        }

        Log.d("DoctorSearchViewModel", "Creating or getting chat between patient $patientId and doctor ${doctor.id}")

        _uiState.value = _uiState.value.copy(isCreatingChat = true, error = null)

        viewModelScope.launch {
            // ИСПРАВЛЕНО: используем getOrCreateChat вместо getChatByPatientAndDoctor
            when (val result = chatRepository.getOrCreateChat(patientId, doctor.id)) {
                is Resource.Success -> {
                    Log.d("DoctorSearchViewModel", "Chat created/found successfully: ${result.data}")
                    _uiState.value = _uiState.value.copy(isCreatingChat = false)
                    onChatCreated(result.data!!)
                }
                is Resource.Error -> {
                    Log.e("DoctorSearchViewModel", "Error creating/getting chat: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        isCreatingChat = false,
                        error = "Помилка створення чату: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}