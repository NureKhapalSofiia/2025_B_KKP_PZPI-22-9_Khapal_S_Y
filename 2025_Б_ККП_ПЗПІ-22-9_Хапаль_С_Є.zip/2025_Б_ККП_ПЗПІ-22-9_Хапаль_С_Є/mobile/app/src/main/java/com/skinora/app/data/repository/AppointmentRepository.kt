package com.skinora.app.data.repository

import com.skinora.app.data.api.AppointmentApi
import com.skinora.app.data.model.*
import com.skinora.app.utils.Resource
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppointmentRepository @Inject constructor(
    private val appointmentApi: AppointmentApi
) {

    suspend fun getAppointmentsByPatient(patientId: Int): Resource<List<Appointment>> {
        return try {
            val response = appointmentApi.getAppointmentsByPatient(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get appointments: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getAppointmentsByDoctor(doctorId: Int): Resource<List<Appointment>> {
        return try {
            val response = appointmentApi.getAppointmentsByDoctor(doctorId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get appointments: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun createAppointment(
        patientId: Int,
        doctorId: Int,
        datetime: String,
        notes: String
    ): Resource<Appointment> {
        return try {
            val request = CreateAppointmentRequest(
                patient = PatientReference(patientId),
                doctor = DoctorReference(doctorId),
                datetime = datetime,
                notes = notes,
                status = "PENDING"
            )

            val response = appointmentApi.createAppointment(request)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Failed to create appointment")
            } else {
                Resource.Error("Failed to create appointment: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun cancelAppointment(appointmentId: Int): Resource<Unit> {
        return try {
            val response = appointmentApi.cancelAppointment(appointmentId)
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error("Failed to cancel appointment: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun confirmAppointment(appointmentId: Int): Resource<Unit> {
        return try {
            val response = appointmentApi.confirmAppointment(appointmentId)
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error("Failed to confirm appointment: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }
}