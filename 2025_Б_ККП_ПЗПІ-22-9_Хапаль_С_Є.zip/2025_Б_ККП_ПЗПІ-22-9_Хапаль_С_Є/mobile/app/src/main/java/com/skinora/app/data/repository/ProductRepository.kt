package com.skinora.app.data.repository

import com.skinora.app.data.api.ProductApi
import com.skinora.app.data.model.*
import com.skinora.app.utils.Resource
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Path
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProductRepository @Inject constructor(
    private val productApi: ProductApi
) {


    suspend fun getAllProducts(): Resource<List<Product>> {
        return try {
            val response = productApi.getAllProducts()
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get products: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getProductById(productId: Int): Resource<Product> {
        return try {
            val response = productApi.getProductById(productId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Product not found")
            } else {
                Resource.Error("Failed to get product: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun searchProducts(name: String): Resource<List<Product>> {
        return try {
            val response = productApi.searchProducts(name)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to search products: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getFavoriteProducts(patientId: Int): Resource<List<Product>> {
        return try {
            val response = productApi.getFavoriteProducts(patientId)
            if (response.isSuccessful) {
                val favoriteList = response.body() ?: emptyList()
                val productList = favoriteList.mapNotNull { it.product }  // ✅ Витягуємо продукти
                Resource.Success(productList)
            } else {
                Resource.Error("Failed to get favorite products: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }


    suspend fun addToFavorites(patientId: Int, productId: Int): Resource<Unit> {
        return try {
            val response = productApi.addToFavorites(patientId, productId)
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error("Failed to add to favorites: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun removeFromFavorites(patientId: Int, productId: Int): Resource<Unit> {
        return try {
            val response = productApi.removeFromFavorites(patientId, productId)
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error("Failed to remove from favorites: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // МЕТОДЫ ДЛЯ USING PRODUCTS

    suspend fun getUsingProducts(patientId: Int): Resource<List<UsingProduct>> {
        return try {
            val response = productApi.getUsingProducts(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get using products: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun addUsingProduct(patientId: Int, productId: Int): Resource<UsingProduct> {
        return try {
            val response = productApi.addUsingProduct(patientId, productId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Failed to add using product")
            } else {
                Resource.Error("Failed to add using product: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // ИСПРАВЛЕНО: Теперь возвращает UsedProduct
    suspend fun stopUsingProduct(patientId: Int, productId: Int): Resource<UsedProduct> {
        return try {
            val response = productApi.stopUsingProduct(patientId, productId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Failed to stop using product")
            } else {
                Resource.Error("Failed to stop using product: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // МЕТОДЫ ДЛЯ USED PRODUCTS

    suspend fun getUsedProducts(patientId: Int): Resource<List<UsedProduct>> {
        return try {
            val response = productApi.getUsedProducts(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get used products: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getFeedbackForProduct(productId: Int, patientId: Int): Resource<ProductFeedback> {
        return try {
            val response = productApi.getFeedbackForProduct(productId, patientId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Feedback not found")
            } else {
                Resource.Error("Failed to get feedback: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun updateSkinReactionAndStatus(
        usedProductId: Int,
        status: String
    ): Boolean {
        return try {
            val request = SkinReactionUpdateRequest(
                usedProductId = usedProductId,
                status = status
            )
            val response = productApi.updateSkinReactionStatus(request)
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }





    suspend fun getPrescribedProductDetails(productId: Int, patientId: Int): Resource<PrescribedProduct> {
        return try {
            val response = productApi.getPrescribedProductDetails(productId, patientId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Prescribed product details not found")
            } else {
                Resource.Error("Failed to get prescribed product details: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }
}