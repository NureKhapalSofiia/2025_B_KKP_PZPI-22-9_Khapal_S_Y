package com.skinora.app.presentation.doctor.products

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.data.model.Product
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun AssignProductScreen(
    onBackClick: () -> Unit,
    onProductAssigned: () -> Unit,
    viewModel: AssignProductViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var patientId by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }

    // Обработка успешного назначения продукта
    LaunchedEffect(uiState.isProductAssigned) {
        if (uiState.isProductAssigned) {
            onProductAssigned()
        }
    }

    // Загрузка продуктов при первом открытии
    LaunchedEffect(Unit) {
        viewModel.loadProducts()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White,
                        PurpleGradientEnd.copy(alpha = 0.3f)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Заголовок с кнопкой назад
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Text(
                        text = "←",
                        fontSize = 24.sp,
                        color = Color(0xFF2D1B69)
                    )
                }

                Text(
                    text = "Призначити продукт",
                    fontSize = 20.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69),
                    modifier = Modifier.weight(1f)
                )
            }

            // Форма ввода
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 8.dp
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Інформація про призначення",
                        fontSize = 18.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D1B69)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // ID пациента
                    OutlinedTextField(
                        value = patientId,
                        onValueChange = { patientId = it },
                        label = {
                            Text(
                                "ID пацієнта",
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number
                        ),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Поиск продуктов
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            viewModel.searchProducts(it)
                        },
                        label = {
                            Text(
                                "Пошук продуктів",
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Список продуктов
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 8.dp
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Доступні продукти",
                        fontSize = 18.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D1B69)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (uiState.isLoading) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = PurpleGradientStart
                            )
                        }
                    } else if (uiState.products.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Продукти не знайдено",
                                fontSize = 16.sp,
                                fontFamily = KleeOneFamily,
                                color = Color(0xFF6B7280)
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(uiState.products) { product ->
                                ProductItem(
                                    product = product,
                                    isSelected = uiState.selectedProduct?.id == product.id,
                                    onProductClick = { viewModel.selectProduct(product) }
                                )
                            }
                        }
                    }
                }
            }

            // Кнопка назначения
            Button(
                onClick = {
                    val patientIdInt = patientId.toIntOrNull()
                    val selectedProduct = uiState.selectedProduct
                    if (patientIdInt != null && selectedProduct != null) {
                        viewModel.assignProduct(patientIdInt, selectedProduct.id)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 16.dp),
                enabled = !uiState.isLoading &&
                        patientId.isNotBlank() &&
                        uiState.selectedProduct != null,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PurpleGradientStart
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (uiState.isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White
                    )
                } else {
                    Text(
                        text = "Призначити продукт",
                        fontSize = 16.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Показ ошибок
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }

        // Показ успеха
        if (uiState.isProductAssigned) {
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF4CAF50)
                )
            ) {
                Text(
                    text = "Продукт успішно призначено!",
                    modifier = Modifier.padding(16.dp),
                    color = Color.White,
                    fontFamily = KleeOneFamily
                )
            }
        }
    }
}

@Composable
private fun ProductItem(
    product: Product,
    isSelected: Boolean,
    onProductClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onProductClick,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                PurpleGradientStart.copy(alpha = 0.1f)
            else
                Color(0xFFF8F9FA)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = product.name,
                fontSize = 16.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = product.brand,
                fontSize = 14.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Medium,
                color = PurpleGradientStart
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = product.description,
                fontSize = 12.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6B7280),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = product.category,
                    fontSize = 10.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF9CA3AF)
                )

                if (product.isCertified) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF4CAF50).copy(alpha = 0.1f)
                        ),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Сертифіковано",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 8.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF4CAF50)
                        )
                    }
                }
            }
        }
    }
}