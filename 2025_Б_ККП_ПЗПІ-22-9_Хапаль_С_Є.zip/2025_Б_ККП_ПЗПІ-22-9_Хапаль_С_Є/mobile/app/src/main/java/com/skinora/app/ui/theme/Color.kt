package com.skinora.app.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Skinora brand colors
val SkinoraPrimary = Color(0xFF8B7CF6)
val SkinoraSecondary = Color(0xFFBB86FC)
val SkinoraBackground = Color(0xFFF3F0FF)
val SkinoraOnPrimary = Color(0xFFFFFFFF)
val SkinoraSurface = Color(0xFFFFFFFF)
val SkinoraOnSurface = Color(0xFF2D1B69)