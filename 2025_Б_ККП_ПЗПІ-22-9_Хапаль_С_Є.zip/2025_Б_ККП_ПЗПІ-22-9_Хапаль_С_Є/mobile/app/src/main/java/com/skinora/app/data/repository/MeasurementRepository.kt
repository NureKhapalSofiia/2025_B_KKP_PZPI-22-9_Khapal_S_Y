package com.skinora.app.data.repository

import com.skinora.app.data.api.MeasurementApi
import com.skinora.app.data.model.Measurement
import javax.inject.Inject
import com.skinora.app.data.model.MeasurementDto


class MeasurementRepository @Inject constructor(
    private val api: MeasurementApi
) {
    suspend fun fetchLatestMeasurement(patientId: Int): Measurement? {
        return try {
            val response = api.getLatestMeasurement(patientId)
            if (response.isSuccessful && response.body() != null) {
                response.body()
            } else {
                null
            }
        } catch (e: Exception) {
            // Щоб не падало через JSON parse на порожній body
            null
        }
    }

    suspend fun getMeasurements(patientId: Int): List<MeasurementDto> {
        return api.getMeasurementsByPatient(patientId)
    }

    suspend fun getMeasurementById(id: Int): MeasurementDto {
        return api.getMeasurementById(id)
    }

}
