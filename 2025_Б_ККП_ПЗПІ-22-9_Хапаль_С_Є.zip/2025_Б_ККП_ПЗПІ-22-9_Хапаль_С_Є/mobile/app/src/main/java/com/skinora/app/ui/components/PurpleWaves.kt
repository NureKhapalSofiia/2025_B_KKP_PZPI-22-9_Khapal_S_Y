package com.skinora.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path

@Composable
fun PurpleWaves(
    modifier: Modifier = Modifier,
    backWaveColor: Color = Color(0xFFD3CBFF),
    frontWaveColor: Color = Color(0xFFC5BAFF)
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        // Задняя волна
        val backWave = Path().apply {
            moveTo(0f, size.height * 0.58f)
            quadraticBezierTo(
                size.width * 0.375f, size.height * 0.58f,
                size.width * 0.52f, size.height * 0.72f
            )
            quadraticBezierTo(
                size.width * 0.76f, size.height * 0.98f,
                size.width, size.height * 0.75f
            )
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(backWave, color = backWaveColor)

        // Передняя волна
        val frontWave = Path().apply {
            moveTo(0f, size.height * 0.63f)
            quadraticBezierTo(
                size.width * 0.38f, size.height * 0.63f,
                size.width * 0.58f, size.height * 0.80f
            )
            quadraticBezierTo(
                size.width * 0.78f, size.height * 0.96f,
                size.width, size.height * 0.82f
            )
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(frontWave, color = frontWaveColor)
    }
}

@Composable
fun TopPurpleWaves(
    modifier: Modifier = Modifier,
    backWaveColor: Color = Color(0xFFD3CBFF),
    frontWaveColor: Color = Color(0xFFC5BAFF)
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        // Задняя волна (сверху)
        val backWave = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width, size.height * 0.42f)
            quadraticBezierTo(
                size.width * 0.76f, size.height * 0.02f,
                size.width * 0.52f, size.height * 0.28f
            )
            quadraticBezierTo(
                size.width * 0.375f, size.height * 0.42f,
                0f, size.height * 0.42f
            )
            close()
        }
        drawPath(backWave, color = backWaveColor)

        // Передняя волна (сверху)
        val frontWave = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width, size.height * 0.37f)
            quadraticBezierTo(
                size.width * 0.78f, size.height * 0.04f,
                size.width * 0.58f, size.height * 0.20f
            )
            quadraticBezierTo(
                size.width * 0.38f, size.height * 0.37f,
                0f, size.height * 0.37f
            )
            close()
        }
        drawPath(frontWave, color = frontWaveColor)
    }
}