package com.skinora.app.presentation.welcome

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.skinora.app.ui.components.PurpleWaves

// Временно используем системные шрифты
val KleeOneFamily = FontFamily.Default

// Цвета из дизайна
val PurpleGradientStart = Color(0xFFD3CBFF)
val PurpleGradientEnd = Color(0xFFC5BAFF)
val LightPurple = Color(0xFFF3F0FF)

@Composable
fun WelcomeScreen(
    onSignInClick: () -> Unit,
    onSignUpClick: () -> Unit
) {
    Box( modifier = Modifier
        .fillMaxSize()
    ) {
        // 1) Градієнтний фон від світло-блакитного до білого
        Box(
            Modifier
                .matchParentSize()
                .background(
                    brush = Brush.verticalGradient(
                        colorStops = arrayOf(
                            0.0f to Color(0xFFC4D9FF),
                            0.35f to Color(0xFFE8F9FF),
                            1.0f to Color(0xFFFBFBFB)
                        )
                    )
                )
        ) {
        // Красивые волны
        PurpleWaves(
            modifier = Modifier.fillMaxSize(),
            backWaveColor = PurpleGradientStart.copy(alpha = 0.6f),
            frontWaveColor = PurpleGradientEnd.copy(alpha = 0.8f)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(100.dp))

            // Заголовок
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding( bottom = 115.dp),
                verticalArrangement = Arrangement.Bottom
            )  {
                Text(
                    text = "Welcome",
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Увійдіть у свій акаунт",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Black.copy(alpha = 0.9f),
                    modifier = Modifier.clickable { onSignInClick() }
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Кнопки
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 24.dp, bottom = 115.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    text = "Welcome",
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Увійдіть у свій акаунт",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Black.copy(alpha = 0.9f),
                    modifier = Modifier.clickable { onSignInClick() }
                )
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .width(56.dp)
                        .height(4.dp)
                        .background(
                            color = Color.White,
                            shape = RoundedCornerShape(2.dp)
                        )
                )
            }}
    }
}}