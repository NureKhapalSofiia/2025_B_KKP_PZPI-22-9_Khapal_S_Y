package com.skinora.app.data.api

import com.skinora.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface PatientApi {

    @GET("patient/{id}")
    suspend fun getPatientById(@Path("id") patientId: Int): Response<Patient>

    @GET("patient/{id}/measurement")
    suspend fun getPatientMeasurements(@Path("id") patientId: Int): Response<List<Measurement>>

    @GET("recommendations/patient/{patientId}")
    suspend fun getPatientRecommendations(@Path("patientId") patientId: Int): Response<List<Recommendation>>

    @GET("patient/{id}/used-products")
    suspend fun getPatientUsedProducts(@Path("id") patientId: Int): Response<List<UsedProduct>>

    @GET("measurements/patient/{patientId}")
    suspend fun getMeasurementsByPatient(@Path("patientId") patientId: Int): Response<List<Measurement>>

    @GET("recommendations/patient/{patientId}")
    suspend fun getRecommendationsByPatient(@Path("patientId") patientId: Int): Response<List<Recommendation>>
}