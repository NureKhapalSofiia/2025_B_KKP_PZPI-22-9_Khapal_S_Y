package com.skinora.app.presentation.doctor.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun DoctorHomeScreen(
    onCreateRecommendationClick: () -> Unit = {},
    onAssignProductClick: () -> Unit = {},
    viewModel: DoctorHomeViewModel = hiltViewModel()
) {
    val homeState by viewModel.homeState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White,
                        PurpleGradientEnd.copy(alpha = 0.1f)
                    )
                )
            )
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(24.dp))

                // Заголовок
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Text(
                        text = "Вітаємо, ${homeState.currentDoctorName}!",
                        fontSize = 24.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D1B69)
                    )

                    Text(
                        text = "Панель управління лікаря",
                        fontSize = 16.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF6B7280)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))

                // Статистика
                DoctorStatisticsCard(
                    totalPatients = homeState.totalPatients,
                    todayAppointments = homeState.todayAppointments,
                    unreadMessages = homeState.unreadMessages
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Основные действия
                DoctorActionsCard(
                    onCreateRecommendationClick = onCreateRecommendationClick,
                    onAssignProductClick = onAssignProductClick
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Последние записи
                RecentAppointmentsCard(
                    appointments = homeState.recentAppointments
                )
            }
        }

        // Индикатор загрузки
        if (homeState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = PurpleGradientStart
                )
            }
        }

        // Показ ошибок
        homeState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}

@Composable
private fun DoctorStatisticsCard(
    totalPatients: Int,
    todayAppointments: Int,
    unreadMessages: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Статистика",
                fontSize = 18.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatisticItem(
                    value = totalPatients.toString(),
                    label = "Пацієнтів",
                    color = PurpleGradientStart
                )

                StatisticItem(
                    value = todayAppointments.toString(),
                    label = "Записів сьогодні",
                    color = Color(0xFF4CAF50)
                )

                StatisticItem(
                    value = unreadMessages.toString(),
                    label = "Нових повідомлень",
                    color = Color(0xFFFF6B6B)
                )
            }
        }
    }
}

@Composable
private fun StatisticItem(
    value: String,
    label: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontSize = 24.sp,
            fontFamily = KleeOneFamily,
            fontWeight = FontWeight.Bold,
            color = color
        )

        Text(
            text = label,
            fontSize = 12.sp,
            fontFamily = KleeOneFamily,
            fontWeight = FontWeight.Normal,
            color = Color(0xFF6B7280)
        )
    }
}

@Composable
private fun DoctorActionsCard(
    onCreateRecommendationClick: () -> Unit,
    onAssignProductClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Дії",
                fontSize = 18.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Кнопка создания рекомендации
            Button(
                onClick = onCreateRecommendationClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PurpleGradientStart
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = "Створити рекомендацію для пацієнта",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Кнопка назначения продукта
            OutlinedButton(
                onClick = onAssignProductClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = PurpleGradientStart
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = "Призначити продукт пацієнту",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun RecentAppointmentsCard(
    appointments: List<DoctorAppointment>
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Найближчі записи",
                fontSize = 18.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69)
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (appointments.isEmpty()) {
                Text(
                    text = "Немає найближчих записів",
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280)
                )
            } else {
                appointments.take(3).forEach { appointment ->
                    AppointmentItem(appointment = appointment)
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun AppointmentItem(
    appointment: DoctorAppointment
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = appointment.patientName,
                fontSize = 14.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF2D1B69)
            )

            Text(
                text = appointment.time,
                fontSize = 12.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6B7280)
            )
        }

        Card(
            colors = CardDefaults.cardColors(
                containerColor = when (appointment.status) {
                    "CONFIRMED" -> Color(0xFF4CAF50).copy(alpha = 0.1f)
                    "PENDING" -> Color(0xFFFFB800).copy(alpha = 0.1f)
                    else -> Color(0xFFFF6B6B).copy(alpha = 0.1f)
                }
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = when (appointment.status) {
                    "CONFIRMED" -> "Підтверджено"
                    "PENDING" -> "Очікує"
                    else -> "Скасовано"
                },
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                fontSize = 10.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Medium,
                color = when (appointment.status) {
                    "CONFIRMED" -> Color(0xFF4CAF50)
                    "PENDING" -> Color(0xFFFFB800)
                    else -> Color(0xFFFF6B6B)
                }
            )
        }
    }
}

// Модель данных для записи в интерфейсе доктора
data class DoctorAppointment(
    val id: Int,
    val patientName: String,
    val time: String,
    val status: String
)