package com.skinora.app.presentation.chat

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Transparent
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.R
import com.skinora.app.data.model.Chat
import com.skinora.app.data.model.Message
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun ChatDetailScreen(
    chat: Chat,
    onBackClick: () -> Unit = {},
    viewModel: ChatDetailViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    // Автоматически прокручиваем к последнему сообщению
    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    // Инициализируем чат при первом запуске
    LaunchedEffect(chat.id) {
        viewModel.setChatInfo(chat)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(
                colors = listOf(Color(0xFFE4EDFD), Color.White),
                startY = 0f,
                endY = Float.POSITIVE_INFINITY
            ))
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Text("←", fontSize = 24.sp, color = PurpleGradientStart)
                }

                // Doctor avatar
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(PurpleGradientStart.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.doctor),
                        contentDescription = "Doctor avatar",
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = chat.participant2.user?.fullName ?: "Невідомий лікар",
                        fontSize = 16.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Black
                    )

                    Text(
                        text = chat.participant2.specialization ?: "Спеціалізація невідома",
                        fontSize = 12.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF6B7280)
                    )
                }


                IconButton(
                    onClick = { viewModel.showAppointmentDialog() },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(PurpleGradientStart.copy(alpha = 0.1f))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.pending),
                        contentDescription = "Appointment icon",
                        modifier = Modifier.size(24.dp)
                            .size(25.dp) // трохи менше, щоб гарно вмістити
                            .clip(CircleShape)
                    )
                }

            }
        }

        // Messages
        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PurpleGradientStart)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(uiState.messages) { message ->
                    MessageItem(
                        message = message,
                        isCurrentUser = message.senderId == uiState.currentUserId
                    )
                }
            }
        }

        // Message input
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFFAFCFF)
            ),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),


                verticalAlignment = Alignment.Bottom
            ) {
                OutlinedTextField(
                    value = uiState.messageText,
                    onValueChange = { viewModel.updateMessageText(it) },

                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 56.dp, max = 120.dp).border(3.dp, PurpleGradientStart, RoundedCornerShape(24.dp))
                        .clip(RoundedCornerShape(24.dp)),

                    placeholder = {
                        Text(
                            text = "Введіть повідомлення...",
                            fontFamily = KleeOneFamily,
                            color = Color(0xFF6B7280)
                        )
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurpleGradientStart,
                        unfocusedBorderColor = PurpleGradientStart,
                        cursorColor = PurpleGradientStart,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black,
                        focusedContainerColor = Color(0xFFFAFCFF),   // 🟦 встановлюємо фон
                        unfocusedContainerColor = Color(0xFFFAFCFF)// 🟣 і так
                    )
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Send button
                IconButton(
                    onClick = { viewModel.sendMessage() },
                    enabled = uiState.messageText.trim().isNotEmpty() && !uiState.isSending,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            if (uiState.messageText.trim().isNotEmpty()) PurpleGradientStart
                            else Color(0xFFE5E7EB)
                        )
                ) {
                    if (uiState.isSending) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.send),
                            contentDescription = "Send message",
                            modifier = Modifier.size(56.dp)
                        )
                    }
                }

            }
        }

        // Error display
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }

    // ДИАЛОГ ДЛЯ СОЗДАНИЯ ВСТРЕЧИ
    if (uiState.showAppointmentDialog) {
        AppointmentDialog(
            doctorName = chat.participant2.user?.fullName ?: "Невідомий лікар",
            onDismiss = { viewModel.hideAppointmentDialog() },
            onConfirm = { datetime, notes ->
                viewModel.createAppointment(datetime, notes)
            }
        )
    }

    // Индикатор создания встречи
    if (uiState.isCreatingAppointment) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color.White.copy(alpha = 0.9f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = PurpleGradientStart
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Створення зустрічі...",
                        fontFamily = KleeOneFamily,
                        color = Color(0xFF374151)
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageItem(
    message: Message,
    isCurrentUser: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isCurrentUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isCurrentUser) {
            Spacer(modifier = Modifier.width(8.dp))
        }

        Card(
            modifier = Modifier.widthIn(max = 280.dp),
            shape = if (isCurrentUser) {
                RoundedCornerShape(topStart = 20.dp, topEnd = 60.dp, bottomEnd = 60.dp, bottomStart = 20.dp)
            } else {
                RoundedCornerShape(topStart = 60.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 60.dp)
            },
            colors = CardDefaults.cardColors(
                containerColor = if (isCurrentUser) Color.White else Color.White
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = message.message,
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = if (isCurrentUser) Color.Black else Color(0xFF2D1B69),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Image(
                    painter = painterResource(id = R.drawable.profil), // заміни на R.drawable.penguin
                    contentDescription = "Avatar",
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                )
            }
        }

        if (isCurrentUser) {
            Spacer(modifier = Modifier.width(8.dp))
        }
    }
}

private fun formatMessageTime(timestamp: String?): String {
    return try {
        if (timestamp.isNullOrBlank()) return "Зараз"

        // Обрабатываем несколько форматов:
        // "2025-06-06T09:00:00" (ISO format)
        // "2025-06-06 09:00:00" (SQL timestamp format)
        // Также может приходить просто время "09:00:00"

        Log.d("ChatDetailScreen", "Formatting timestamp: $timestamp")

        val cleanTime = timestamp.replace("T", " ").split(" ")
        if (cleanTime.size >= 2) {
            // Есть дата и время
            val timePart = cleanTime[1].split(":")
            if (timePart.size >= 2) {
                "${timePart[0]}:${timePart[1]}"
            } else {
                "Зараз"
            }
        } else {
            // Только время без даты или другой формат
            val timePart = timestamp.split(":")
            if (timePart.size >= 2) {
                "${timePart[0]}:${timePart[1]}"
            } else {
                "Зараз"
            }
        }
    } catch (e: Exception) {
        Log.e("ChatDetailScreen", "Error formatting time: $timestamp", e)
        "Зараз"
    }
}