package com.skinora.app.presentation.usedproducts

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.ProductRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.data.repository.PatientRepository
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class UsedProductsState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val usedProducts: List<UsedProduct> = emptyList(),
    val selectedProduct: UsedProduct? = null,
    val productFeedback: ProductFeedback? = null,
    val prescribedProductDetails: PrescribedProduct? = null,
    val showProductDetails: Boolean = false,
    val patientId: Int? = null,
    val favoriteProducts: List<Product> = emptyList(),
)


@HiltViewModel
class UsedProductsViewModel @Inject constructor(
    private val productRepository: ProductRepository,
    private val preferencesManager: PreferencesManager,
    private val patientRepository: PatientRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(UsedProductsState())
    val uiState: StateFlow<UsedProductsState> = _uiState.asStateFlow()
    val repository: ProductRepository
        get() = productRepository

    init {
        loadCurrentUser()
    }
    private var favoritesProducts: List<FavoriteProduct> = emptyList()

    fun addToFavorites(product: Product) {
        val patientId = _uiState.value.patientId
        val productId = product.id ?: return


        val alreadyUsed = _uiState.value.favoriteProducts.any {
            it.name.equals(product.name, ignoreCase = true) &&
                    it.brand.equals(product.brand, ignoreCase = true)
        }

        if (alreadyUsed) {
            _uiState.update {
                it.copy(error = "Цей продукт вже використовується")
            }
            return
        }

        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(error = "ID пацієнта не знайдено")
            return
        }

        viewModelScope.launch {
            when (val result = productRepository.addToFavorites(patientId, product.id)) {
                is Resource.Success -> {
                    Log.d("UsedProductsViewModel", "Продукт додано в улюблені: ${product.name}")
                }
                is Resource.Error -> {
                    Log.e("UsedProductsViewModel", "Помилка додавання в улюблені: ${result.message}")
                    _uiState.value = _uiState.value.copy(error = "Помилка: ${result.message}")
                }
                is Resource.Loading -> {}
            }
        }
    }


    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()
                val userEmail = preferencesManager.getUserEmail().first()

                Log.d("UsedProductsViewModel", "Current user ID: $userId, email: $userEmail")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(patientId = userId)

                // Загружаем продукты после получения ID пациента
                loadUsedProducts()
                loadFavoriteProducts()


            } catch (e: Exception) {
                Log.e("UsedProductsViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження користувача: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    fun loadFavoriteProducts() {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити рекомендації: невірний ID користувача"
            )
            return
        }

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = productRepository.getFavoriteProducts(patientId)) {
                is Resource.Success -> {
                    Log.d("UsedProductsViewModel", "Favorite products loaded: ${result.data?.size ?: 0} items")

                    val products = result.data ?: emptyList()

                    _uiState.value = _uiState.value.copy(
                        favoriteProducts = products,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("UsedProductsViewModel", "Error loading favorite products: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        favoriteProducts = emptyList(),
                        isLoading = false,
                        error = "Помилка завантаження рекомендацій: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun loadUsedProducts() {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити використані продукти: невірний ID користувача"
            )
            return
        }

        Log.d("UsedProductsViewModel", "Loading used products for patient: $patientId")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = productRepository.getUsedProducts(patientId)) {
                is Resource.Success -> {
                    Log.d("UsedProductsViewModel", "Used products loaded: ${result.data?.size ?: 0} items")
                    val products = result.data ?: emptyList()
                    _uiState.value = _uiState.value.copy(
                        usedProducts = products,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("UsedProductsViewModel", "Error loading used products: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        usedProducts = emptyList(),
                        isLoading = false,
                        error = "Помилка завантаження використаних продуктів: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun showProductDetails(product: UsedProduct) {
        Log.d("UsedProductsViewModel", "Showing details for product: ${product.product.name}")
        _uiState.value = _uiState.value.copy(
            selectedProduct = product,
            showProductDetails = true
        )

        // Загружаем feedback и prescribed details
        loadProductFeedback(product.product.id)
        loadPrescribedProductDetails(product.product.id)
    }

    fun hideProductDetails() {
        _uiState.value = _uiState.value.copy(
            selectedProduct = null,
            showProductDetails = false,
            productFeedback = null,
            prescribedProductDetails = null
        )
    }

    private fun loadProductFeedback(productId: Int) {
        val patientId = _uiState.value.patientId ?: return

        viewModelScope.launch {
            when (val result = productRepository.getFeedbackForProduct(productId, patientId)) {
                is Resource.Success -> {
                    Log.d("UsedProductsViewModel", "Feedback loaded for product: $productId")
                    _uiState.value = _uiState.value.copy(productFeedback = result.data)
                }
                is Resource.Error -> {
                    Log.e("UsedProductsViewModel", "Error loading feedback: ${result.message}")
                    _uiState.value = _uiState.value.copy(productFeedback = null)
                }
                is Resource.Loading -> {}
            }
        }
    }

    private fun loadPrescribedProductDetails(productId: Int) {
        val patientId = _uiState.value.patientId ?: return

        viewModelScope.launch {
            when (val result = productRepository.getPrescribedProductDetails(productId, patientId)) {
                is Resource.Success -> {
                    Log.d("UsedProductsViewModel", "Prescribed details loaded for product: $productId")
                    _uiState.value = _uiState.value.copy(prescribedProductDetails = result.data)
                }
                is Resource.Error -> {
                    Log.e("UsedProductsViewModel", "Error loading prescribed details: ${result.message}")
                    _uiState.value = _uiState.value.copy(prescribedProductDetails = null)
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun updateSkinReactionStatus(usedProductId: Int, status: String) {
        viewModelScope.launch {
            try {
                val success = productRepository.updateSkinReactionAndStatus(
                    usedProductId = usedProductId,
                    status = status
                )

                if (success) {
                    loadUsedProducts()
                    hideProductDetails()
                } else {
                    _uiState.value = _uiState.value.copy(error = "Помилка оновлення статусу")
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(error = "Помилка: ${e.message}")
            }
        }
    }



    fun refreshData() {
        loadUsedProducts()
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}