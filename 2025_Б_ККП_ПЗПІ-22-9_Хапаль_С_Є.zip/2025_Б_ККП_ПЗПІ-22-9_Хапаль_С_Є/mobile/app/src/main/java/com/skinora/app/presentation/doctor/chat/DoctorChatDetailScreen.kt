package com.skinora.app.presentation.doctor.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.data.model.Chat
import com.skinora.app.data.model.Message
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun DoctorChatDetailScreen(
    chat: Chat,
    onBackClick: () -> Unit,
    viewModel: DoctorChatDetailViewModel = hiltViewModel()
) {
    val chatState by viewModel.chatState.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val keyboardController = LocalSoftwareKeyboardController.current
    var messageText by remember { mutableStateOf("") }

    // Загрузка сообщений при открытии чата
    LaunchedEffect(chat.id) {
        viewModel.loadMessages(chat.id)
    }

    // Прокрутка к последнему сообщению при появлении новых
    LaunchedEffect(chatState.messages.size) {
        if (chatState.messages.isNotEmpty()) {
            listState.animateScrollToItem(chatState.messages.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White,
                        PurpleGradientEnd.copy(alpha = 0.1f)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Заголовок чата
            DoctorChatHeader(
                chat = chat,
                onBackClick = onBackClick
            )

            // Список сообщений
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (chatState.isLoading) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = PurpleGradientStart
                            )
                        }
                    }
                }

                items(chatState.messages) { message ->
                    DoctorMessageBubble(
                        message = message,
                        isFromDoctor = message.senderId == viewModel.getDoctorId(),
                        patientName = chat.participant1.user.fullName
                    )
                }

                if (chatState.messages.isEmpty() && !chatState.isLoading) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Почніть розмову з пацієнтом",
                                fontSize = 16.sp,
                                fontFamily = KleeOneFamily,
                                color = Color(0xFF6B7280),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Поле ввода сообщения
            DoctorMessageInput(
                messageText = messageText,
                onMessageTextChange = { messageText = it },
                onSendMessage = {
                    if (messageText.isNotBlank()) {
                        viewModel.sendMessage(chat.id, messageText)
                        messageText = ""
                        keyboardController?.hide()
                    }
                },
                isLoading = chatState.isSending
            )
        }

        // Показ ошибок
        chatState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}

@Composable
private fun DoctorChatHeader(
    chat: Chat,
    onBackClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Text(
                    text = "←",
                    fontSize = 24.sp,
                    color = Color(0xFF2D1B69)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Аватар пациента
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(PurpleGradientStart.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = getPatientInitials(chat.participant1.user.fullName),
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = PurpleGradientStart
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о пациенте
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = chat.participant1.user.fullName,
                    fontSize = 18.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69)
                )

                Text(
                    text = "Пацієнт",
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280)
                )
            }

            // Статус онлайн
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF4CAF50))
            )
        }
    }
}

@Composable
private fun DoctorMessageBubble(
    message: Message,
    isFromDoctor: Boolean,
    patientName: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isFromDoctor) Arrangement.End else Arrangement.Start
    ) {
        if (!isFromDoctor) {
            // Аватар пациента
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(PurpleGradientStart.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = getPatientInitials(patientName),
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = PurpleGradientStart
                )
            }

            Spacer(modifier = Modifier.width(8.dp))
        }

        Card(
            modifier = Modifier.widthIn(max = 280.dp),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isFromDoctor) 16.dp else 4.dp,
                bottomEnd = if (isFromDoctor) 4.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isFromDoctor)
                    PurpleGradientStart
                else
                    Color.White
            ),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 2.dp
            )
        ) {
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                Text(
                    text = message.message,
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = if (isFromDoctor) Color.White else Color(0xFF2D1B69)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = formatMessageTime(message.sentAt ?: ""),
                    fontSize = 10.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = if (isFromDoctor)
                        Color.White.copy(alpha = 0.7f)
                    else
                        Color(0xFF9CA3AF),
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (isFromDoctor) {
            Spacer(modifier = Modifier.width(8.dp))

            // Аватар доктора
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF4CAF50).copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Л",
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF4CAF50)
                )
            }
        }
    }
}

@Composable
private fun DoctorMessageInput(
    messageText: String,
    onMessageTextChange: (String) -> Unit,
    onSendMessage: () -> Unit,
    isLoading: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedTextField(
                value = messageText,
                onValueChange = onMessageTextChange,
                placeholder = {
                    Text(
                        "Напишіть повідомлення пацієнту...",
                        fontFamily = KleeOneFamily,
                        color = Color(0xFF9CA3AF)
                    )
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PurpleGradientStart,
                    unfocusedBorderColor = Color(0xFFE5E7EB)
                ),
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(
                    onSend = { onSendMessage() }
                ),
                maxLines = 3
            )

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onSendMessage,
                enabled = messageText.isNotBlank() && !isLoading,
                modifier = Modifier.size(48.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PurpleGradientStart
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White
                    )
                } else {
                    Text(
                        text = "→",
                        fontSize = 18.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

private fun getPatientInitials(fullName: String): String {
    return fullName.split(" ")
        .take(2)
        .mapNotNull { it.firstOrNull()?.uppercaseChar() }
        .joinToString("")
        .ifEmpty { "П" }
}

private fun formatMessageTime(dateTimeString: String): String {
    return try {
        if (dateTimeString.isBlank()) return ""

        val dateTime = java.time.LocalDateTime.parse(dateTimeString)
        val formatter = java.time.format.DateTimeFormatter.ofPattern("HH:mm")
        dateTime.format(formatter)
    } catch (e: Exception) {
        ""
    }
}