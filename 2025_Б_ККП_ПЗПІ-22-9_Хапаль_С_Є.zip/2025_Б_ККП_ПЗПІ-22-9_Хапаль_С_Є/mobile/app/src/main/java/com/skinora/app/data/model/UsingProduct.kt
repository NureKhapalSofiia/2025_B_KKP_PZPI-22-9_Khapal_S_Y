package com.skinora.app.data.model

import com.google.gson.annotations.SerializedName

// Модель для продукта, который сейчас используется (только активные)
data class UsingProduct(
    val id: Long,
    val patient: Patient,
    val product: Product,
    @SerializedName("startedAt")
    val startedAt: String // "2024-12-01T00:00:00"
    // УБРАНО: stoppedAt - так как в using_products только активные продукты
)

// Запрос для добавления продукта в "Используется"
data class AddUsingProductRequest(
    val patientId: Int,
    val productId: Int
)

// Запрос для остановки использования продукта
data class StopUsingProductRequest(
    val patientId: Int,
    val productId: Int
)