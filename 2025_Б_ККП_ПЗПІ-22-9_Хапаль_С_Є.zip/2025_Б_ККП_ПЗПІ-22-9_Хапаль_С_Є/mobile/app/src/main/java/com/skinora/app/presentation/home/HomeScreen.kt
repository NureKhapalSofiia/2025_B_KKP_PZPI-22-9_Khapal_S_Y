package com.skinora.app.presentation.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.R
import com.skinora.app.data.model.UsingProduct
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import com.skinora.app.ui.components.*

@Composable
fun HomeScreen(
    onUsingProductsClick: () -> Unit = {},
    onUsedProductsClick: () -> Unit = {},
    onAnalysisClick: () -> Unit = {},
    onRecommendationsClick: () -> Unit = {},
    onFavoriteClick: () -> Unit = {},
    viewModel: HomeViewModel = hiltViewModel()
) {
    val homeState by viewModel.homeState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(
                colors = listOf(Color(0xFFE4EDFD), Color.White),
                startY = 0f,
                endY = Float.POSITIVE_INFINITY
            ))
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(24.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    SkinStatusCard(
                        latestMeasurement = homeState.latestMeasurement
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Используемые продукты - одна карточка со списком
                UsingProductsCard(
                    products = homeState.usingProducts,
                    onClick = onUsingProductsClick
                )
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))

                // Использованные продукты
                homeState.usedProducts.take(1).forEach { usedProduct ->
                    UsedProductCard(
                        product = usedProduct,
                        onClick = onUsedProductsClick
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))

                // Анализы
                AnalysisCard(
                    onClick = onAnalysisClick
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Рекомендации
                RecommendationsCard(
                    onClick = onRecommendationsClick
                )
            }
            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Рекомендации
                FavoriteCard(
                    onClick = onFavoriteClick
                )
            }
        }

        // Индикатор загрузки
        if (homeState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = PurpleGradientStart
                )
            }
        }

        // Показ ошибок
        homeState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }

        // Кнопка обновления (вместо pull-to-refresh)
        FloatingActionButton(
            onClick = { viewModel.refreshData() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = PurpleGradientStart,
            contentColor = Color.White
        ) {
            Text("↻", fontSize = 20.dp.value.toInt().sp)
        }
    }
}
