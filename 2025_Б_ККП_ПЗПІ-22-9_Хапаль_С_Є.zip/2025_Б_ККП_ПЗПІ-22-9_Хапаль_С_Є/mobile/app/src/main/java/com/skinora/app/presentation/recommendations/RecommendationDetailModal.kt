package com.skinora.app.presentation.recommendations

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.skinora.app.data.model.Recommendation
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import androidx.compose.foundation.Canvas



@Composable
fun RecommendationDetailModal(
    recommendation: Recommendation,
    onDismiss: () -> Unit
) {
    val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

    Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(900.dp)
                .background(Color.Black.copy(alpha = 0.3f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.BottomCenter
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val backWaveColor = Color(0xFFD3CBFF)
                val frontWaveColor = Color(0xFFC5BAFF)
                // Задняя волна
                val backWave = Path().apply {
                    moveTo(0f, size.height * 0.28f)
                    quadraticBezierTo(
                        size.width * 0.375f, size.height * 0.28f,
                        size.width * 0.59f, size.height * 0.42f
                    )
                    quadraticBezierTo(
                        size.width * 0.86f, size.height * 0.53f,
                        size.width, size.height * 0.40f
                    )
                    lineTo(size.width, size.height)
                    lineTo(0f, size.height)
                    close()
                }
                drawPath(backWave, color = backWaveColor)

                // Передняя волна
                val frontWave = Path().apply {
                    moveTo(0f, size.height * 0.33f)
                    quadraticBezierTo(
                        size.width * 0.38f, size.height * 0.33f,
                        size.width * 0.58f, size.height * 0.47f
                    )
                    quadraticBezierTo(
                        size.width * 0.85f, size.height * 0.58f,
                        size.width, size.height * 0.45f
                    )
                    lineTo(size.width, size.height)
                    lineTo(0f, size.height)
                    close()
                }
                drawPath(frontWave, color = frontWaveColor)
            }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.Start
                ) {
                    Spacer(modifier = Modifier.height(300.dp))

                        Text(
                            text = recommendation.product?.name ?: "Назва продукту відсутня",
                            fontFamily = kleeOne,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.Black,
                            maxLines = 2,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth(0.55f)
                        )


                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Spacer(modifier = Modifier.height(40.dp))


                        // Опис продукту
                        Text(
                            text = recommendation.product?.description ?: "Опис продукту відсутній",
                            fontSize = 16.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.Normal,
                            maxLines = 2,
                            color = Color.Black,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        // Дата створення
                        Text(
                            text = "Дата створення:   "+ formatDetailedDate(recommendation.createdAt),
                            fontSize = 14.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.Normal,
                            color = Color.Black,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        // Рекомендація
                        Text(
                            text = "Рекомендація:",
                            fontSize = 16.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Black,
                            modifier = Modifier.padding(bottom = 3.dp)
                        )
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = PurpleGradientEnd.copy(alpha = 0.1f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = recommendation.text ?: "Рекомендація відсутня",
                                fontSize = 16.sp,
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.Normal,
                                color = Color.Black,
                                modifier = Modifier.padding(16.dp),
                                lineHeight = 24.sp
                            )
                        }


                    }}
                }
            }


private fun formatDetailedDate(dateString: String?): String {
    return try {
        if (dateString.isNullOrBlank()) return "Невідомо"

        // Обрабатываем формат "2024-12-01T10:00:00"
        val cleanDate = dateString.replace("T", " ").split(" ")
        if (cleanDate.size >= 2) {
            val datePart = cleanDate[0].split("-")
            val timePart = cleanDate[1].split(":")
            if (datePart.size >= 3 && timePart.size >= 2) {
                "${datePart[2]}.${datePart[1]}.${datePart[0]} о ${timePart[0]}:${timePart[1]}"
            } else {
                dateString
            }
        } else {
            dateString
        }
    } catch (e: Exception) {
        dateString ?: "Невідомо"
    }
}