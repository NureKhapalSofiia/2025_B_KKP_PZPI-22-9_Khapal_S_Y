package com.skinora.app.presentation.usedproducts

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.skinora.app.data.model.*
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import com.skinora.app.data.repository.ProductRepository

@Composable
fun UsedProductDetailModal(
    viewModel: UsedProductsViewModel,
    product: UsedProduct,
    feedback: ProductFeedback?,
    prescribedDetails: PrescribedProduct?,
    onDismiss: () -> Unit,
    repository: ProductRepository,
    onEditClick: (String) -> Unit
) {
    val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

    var statusText by remember { mutableStateOf(product.status ?: "") }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val animationProgress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 500),
        label = "animationProgress"
    )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(900.dp)
                .background(Color.Black.copy(alpha = 0.3f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.BottomCenter
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val backWaveColor = Color(0xFFD3CBFF)
                val frontWaveColor = Color(0xFFC5BAFF)
                // Задняя волна
                val backWave = Path().apply {
                    moveTo(0f, size.height * 0.28f)
                    quadraticBezierTo(
                        size.width * 0.375f, size.height * 0.28f,
                        size.width * 0.59f, size.height * 0.42f
                    )
                    quadraticBezierTo(
                        size.width * 0.86f, size.height * 0.53f,
                        size.width, size.height * 0.40f
                    )
                    lineTo(size.width, size.height)
                    lineTo(0f, size.height)
                    close()
                }
                drawPath(backWave, color = backWaveColor)

                // Передняя волна
                val frontWave = Path().apply {
                    moveTo(0f, size.height * 0.33f)
                    quadraticBezierTo(
                        size.width * 0.38f, size.height * 0.33f,
                        size.width * 0.58f, size.height * 0.47f
                    )
                    quadraticBezierTo(
                        size.width * 0.85f, size.height * 0.58f,
                        size.width, size.height * 0.45f
                    )
                    lineTo(size.width, size.height)
                    lineTo(0f, size.height)
                    close()
                }
                drawPath(frontWave, color = frontWaveColor)
            }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.Start
                ) {
                    Spacer(modifier = Modifier.height(300.dp))

                        Text(
                            text = product.product.name ?: "Невідомий продукт",
                            fontFamily = kleeOne,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.Black,
                            maxLines = 2,
                            overflow = TextOverflow.Clip,
                            modifier = Modifier
                                .fillMaxWidth(0.55f)
                        )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Spacer(modifier = Modifier.height(40.dp))

                        Text(
                            text = "Дата початку використання:",
                            fontSize = 15.sp,
                            color = Color.Black
                        )


                        // Безопасное получение даты начала
                        val startDate = prescribedDetails?.startDate?.takeIf { it.isNotBlank() }
                            ?: product.startedAt?.takeIf { it.isNotBlank() }
                            ?: "Невідомо"

                        Text(
                            text = formatDate(startDate),
                            fontSize = 15.sp,
                            color = Color.Black,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        Text(
                            text = "Дата закінчення використання",
                            fontSize = 15.sp,
                            color = Color.Black
                        )

                        // Безопасное получение даты окончания
                        val endDate = prescribedDetails?.endDate?.takeIf { it.isNotBlank() }
                            ?: product.stoppedAt?.takeIf { it.isNotBlank() }
                            ?: "Активно"
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = formatDate(endDate),
                            fontSize = 15.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF2D1B69),
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        var skinReactionText by remember { mutableStateOf("") }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .padding(bottom = 16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = PurpleGradientEnd.copy(alpha = 0.1f)
                            ),
                            shape = RoundedCornerShape(50.dp)
                        ) {
                            Text(
                                text = feedback?.comment?.takeIf { it.isNotBlank() } ?: "Відгук не залишено",
                                fontSize = 14.sp,
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.Normal,
                                color = Color(0xFF2D1B69),
                                modifier = Modifier.padding(16.dp)
                            )

                        }



                        OutlinedTextField(
                            value = statusText,
                            onValueChange = { statusText = it },
                            label = { Text("Реакція на продукт") },
                            placeholder = { Text("Що відчуваєте при використанні...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(50)

                        )

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val success = repository.updateSkinReactionAndStatus(
                                        usedProductId = product.id, // <- обов'язково ID із таблиці used_products
                                        status = statusText
                                    )
                                    if (success) {
                                        Toast.makeText(context, "Оновлено успішно", Toast.LENGTH_SHORT).show()
                                        onDismiss()
                                    } else {
                                        Toast.makeText(context, "Помилка при оновленні", Toast.LENGTH_SHORT).show()
                                    }
                                }

                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PurpleGradientStart),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Text(
                                text = "Змінити",
                                fontSize = 16.sp,
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }

                    }
                }
            }
        }


private fun formatDate(dateString: String?): String {
    return try {
        // Проверяем на null и пустую строку
        if (dateString.isNullOrBlank()) return "Невідомо"
        if (dateString == "Активно") return dateString

        // Обрабатываем формат "2024-12-01" или "2024-12-01T10:00:00"
        val cleanDate = dateString.replace("T", " ").split(" ")[0]
        val parts = cleanDate.split("-")
        if (parts.size >= 3) {
            "${parts[2]}.${parts[1]}.${parts[0]}"
        } else {
            dateString
        }
    } catch (e: Exception) {
        dateString ?: "Невідомо"
    }
}