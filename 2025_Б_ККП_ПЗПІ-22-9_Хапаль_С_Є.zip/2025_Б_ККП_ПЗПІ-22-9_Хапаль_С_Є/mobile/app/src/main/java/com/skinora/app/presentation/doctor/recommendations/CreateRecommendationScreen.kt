package com.skinora.app.presentation.doctor.recommendations

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun CreateRecommendationScreen(
    onBackClick: () -> Unit,
    onRecommendationCreated: () -> Unit,
    viewModel: CreateRecommendationViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var patientId by remember { mutableStateOf("") }
    var recommendationText by remember { mutableStateOf("") }

    // Обработка успешного создания рекомендации
    LaunchedEffect(uiState.isRecommendationCreated) {
        if (uiState.isRecommendationCreated) {
            onRecommendationCreated()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White,
                        PurpleGradientEnd.copy(alpha = 0.3f)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Заголовок с кнопкой назад
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Text(
                        text = "←",
                        fontSize = 24.sp,
                        color = Color(0xFF2D1B69)
                    )
                }

                Text(
                    text = "Створити рекомендацію",
                    fontSize = 20.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Форма создания рекомендации
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                elevation = CardDefaults.cardElevation(
                    defaultElevation = 8.dp
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Інформація про рекомендацію",
                        fontSize = 18.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D1B69)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // ID пациента
                    OutlinedTextField(
                        value = patientId,
                        onValueChange = { patientId = it },
                        label = {
                            Text(
                                "ID пацієнта",
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number
                        ),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Текст рекомендации
                    OutlinedTextField(
                        value = recommendationText,
                        onValueChange = { recommendationText = it },
                        label = {
                            Text(
                                "Текст рекомендації",
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        maxLines = 5,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Кнопка создания
                    Button(
                        onClick = {
                            val patientIdInt = patientId.toIntOrNull()
                            if (patientIdInt != null && recommendationText.isNotBlank()) {
                                viewModel.createRecommendation(patientIdInt, recommendationText)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        enabled = !uiState.isLoading &&
                                patientId.isNotBlank() &&
                                recommendationText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PurpleGradientStart
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        if (uiState.isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White
                            )
                        } else {
                            Text(
                                text = "Створити рекомендацію",
                                fontSize = 16.sp,
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Инструкции
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = PurpleGradientEnd.copy(alpha = 0.1f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Інструкції:",
                        fontSize = 14.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D1B69)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "• Введіть ID пацієнта, для якого створюється рекомендація\n" +
                                "• Напишіть детальну рекомендацію щодо догляду за шкірою\n" +
                                "• Вкажіть конкретні продукти або процедури\n" +
                                "• Рекомендація буде відправлена пацієнту автоматично",
                        fontSize = 12.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF6B7280)
                    )
                }
            }
        }

        // Показ ошибок
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }

        // Показ успеха
        if (uiState.isRecommendationCreated) {
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF4CAF50)
                )
            ) {
                Text(
                    text = "Рекомендацію успішно створено!",
                    modifier = Modifier.padding(16.dp),
                    color = Color.White,
                    fontFamily = KleeOneFamily
                )
            }
        }
    }
}