package com.skinora.app.data.api

import com.skinora.app.data.model.*
import retrofit2.Response
import retrofit2.http.*
import com.skinora.app.data.model.MeasurementDto
import retrofit2.http.GET
import retrofit2.http.Path

interface MeasurementApi {
    @GET("measurements/patient/{patientId}/latest")
    suspend fun getLatestMeasurement(@Path("patientId") patientId: Int): Response<Measurement>

    @GET("measurements/patient/{patientId}")
    suspend fun getMeasurementsByPatient(@Path("patientId") patientId: Int): List<MeasurementDto>

    @GET("measurements/{measurementId}")
    suspend fun getMeasurementById(@Path("measurementId") measurementId: Int): MeasurementDto
}