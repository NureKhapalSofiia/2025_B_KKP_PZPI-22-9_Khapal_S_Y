package com.skinora.app.data.api

import com.skinora.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface ChatApi {

    @GET("chats/patient/{patientId}")
    suspend fun getChatsByPatient(@Path("patientId") patientId: Int): Response<List<Chat>>

    @GET("chats/patient/{patientId}/doctor/{doctorId}")
    suspend fun getChatByPatientAndDoctor(
        @Path("patientId") patientId: Int,
        @Path("doctorId") doctorId: Int
    ): Response<Chat>

    @GET("chats/{chatId}/messages")
    suspend fun getMessagesByChat(@Path("chatId") chatId: Int): Response<List<Message>>

    @POST("chats/{chatId}/messages")
    suspend fun sendMessage(
        @Path("chatId") chatId: Int,
        @Body message: SendMessageRequest
    ): Response<Message>

    @POST("chats/create")
    suspend fun createChat(
        @Query("patientId") patientId: Int,
        @Query("doctorId") doctorId: Int
    ): Response<Chat>
}

interface DoctorApi {

    @GET("doctor/search")
    suspend fun searchDoctorsByName(@Query("name") name: String): Response<List<DoctorSearchResult>>

    @GET("doctor/all")
    suspend fun getAllDoctors(): Response<List<DoctorSearchResult>>
}