package com.skinora.app.presentation.doctor.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.data.model.Chat
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun DoctorChatScreen(
    onChatClick: (Chat) -> Unit,
    viewModel: DoctorChatViewModel = hiltViewModel()
) {
    val chatState by viewModel.chatState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.loadChats()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White,
                        PurpleGradientEnd.copy(alpha = 0.1f)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Заголовок
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Чати з пацієнтами",
                    fontSize = 24.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69)
                )

                Text(
                    text = "Спілкування з вашими пацієнтами",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280)
                )
            }

            // Список чатов
            when {
                chatState.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = PurpleGradientStart
                        )
                    }
                }

                chatState.chats.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Поки що немає чатів",
                                fontSize = 18.sp,
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF6B7280)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Чати з'являться, коли пацієнти почнуть спілкування",
                                fontSize = 14.sp,
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.Normal,
                                color = Color(0xFF9CA3AF)
                            )
                        }
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(chatState.chats) { chat ->
                            DoctorChatItem(
                                chat = chat,
                                onClick = { onChatClick(chat) }
                            )
                        }
                    }
                }
            }
        }

        // Показ ошибок
        chatState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}

@Composable
private fun DoctorChatItem(
    chat: Chat,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Аватар пациента
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(PurpleGradientStart.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = getPatientInitials(chat.participant1.user.fullName),
                    fontSize = 18.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = PurpleGradientStart
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о чате
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = chat.participant1.user.fullName,
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Пацієнт • ${chat.participant1.gender}",
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280)
                )

                // Показываем заметки если есть
                if (chat.participant1.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = chat.participant1.notes,
                        fontSize = 11.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF9CA3AF),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Индикатор статуса
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF4CAF50).copy(alpha = 0.1f)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "Активний",
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontSize = 10.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF4CAF50)
                )
            }
        }
    }
}

private fun getPatientInitials(fullName: String): String {
    return fullName.split(" ")
        .take(2)
        .mapNotNull { it.firstOrNull()?.uppercaseChar() }
        .joinToString("")
        .ifEmpty { "П" }
}