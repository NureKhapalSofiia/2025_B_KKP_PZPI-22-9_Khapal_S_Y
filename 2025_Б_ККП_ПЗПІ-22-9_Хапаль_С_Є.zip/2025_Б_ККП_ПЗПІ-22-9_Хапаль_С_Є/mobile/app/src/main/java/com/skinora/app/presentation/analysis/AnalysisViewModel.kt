package com.skinora.app.presentation.analysis

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.MeasurementDto
import com.skinora.app.data.repository.MeasurementRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AnalysisViewModel @Inject constructor(
    private val repository: MeasurementRepository
) : ViewModel() {

    private val _measurements = MutableStateFlow<List<MeasurementDto>>(emptyList())
    val measurements = _measurements.asStateFlow()

    fun loadMeasurements(patientId: Int) {
        viewModelScope.launch {
            try {
                _measurements.value = repository.getMeasurements(patientId)
            } catch (e: Exception) {
                Log.e("AnalysisVM", "Error loading measurements", e)
            }
        }
    }
}
