package com.skinora.app.di

import com.skinora.app.BuildConfig
import com.skinora.app.data.api.AuthApi
import com.skinora.app.data.api.PatientApi
import com.skinora.app.data.api.ProductApi
import com.skinora.app.data.api.ChatApi
import com.skinora.app.data.api.DoctorApi
import com.skinora.app.data.api.AppointmentApi
import com.skinora.app.data.api.MeasurementApi
import com.skinora.app.data.api.UserApi
import com.skinora.app.data.model.Patient
import com.skinora.app.data.model.Product
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.data.repository.AppointmentRepository
import com.skinora.app.data.repository.DoctorRepository  // ДОБАВЛЕНО
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideLoggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
    }

    @Provides
    @Singleton
    fun provideAuthInterceptor(preferencesManager: PreferencesManager): Interceptor {
        return Interceptor { chain ->
            val request = chain.request()
            val token = runBlocking { preferencesManager.getToken().first() }

            val newRequest = if (token.isNotEmpty() && !request.url.encodedPath.contains("/auth/")) {
                request.newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .build()
            } else {
                request
            }

            chain.proceed(newRequest)
        }
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(
        loggingInterceptor: HttpLoggingInterceptor,
        authInterceptor: Interceptor
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideAuthApi(retrofit: Retrofit): AuthApi {
        return retrofit.create(AuthApi::class.java)
    }

    @Provides
    @Singleton
    fun provideProductApi(retrofit: Retrofit): ProductApi {
        return retrofit.create(ProductApi::class.java)
    }

    @Provides
    @Singleton
    fun providePatientApi(retrofit: Retrofit): PatientApi {
        return retrofit.create(PatientApi::class.java)
    }

    @Provides
    @Singleton
    fun provideChatApi(retrofit: Retrofit): ChatApi {
        return retrofit.create(ChatApi::class.java)
    }

    @Provides
    @Singleton
    fun provideDoctorApi(retrofit: Retrofit): DoctorApi {
        return retrofit.create(DoctorApi::class.java)
    }

    @Provides
    @Singleton
    fun provideAppointmentApi(retrofit: Retrofit): AppointmentApi {
        return retrofit.create(AppointmentApi::class.java)
    }

    @Provides
    @Singleton
    fun provideUserApi(retrofit: Retrofit): UserApi {
        return retrofit.create(UserApi::class.java)
    }

    // REPOSITORIES

    @Provides
    @Singleton
    fun provideAppointmentRepository(
        appointmentApi: AppointmentApi
    ): AppointmentRepository {
        return AppointmentRepository(appointmentApi)
    }

    // ДОБАВЛЕНО: DoctorRepository
    @Provides
    @Singleton
    fun provideDoctorRepository(
        doctorApi: DoctorApi
    ): DoctorRepository {
        return DoctorRepository(doctorApi)
    }

    @Module
    @InstallIn(SingletonComponent::class)
    object ProfileModule {

        // Если нужен отдельный API для операций с профилем
        @Provides
        @Singleton
        fun provideProfileApi(retrofit: Retrofit): ProfileApi {
            return retrofit.create(ProfileApi::class.java)
        }
    }

    @Provides
    @Singleton
    fun provideMeasurementApi(retrofit: Retrofit): MeasurementApi {
        return retrofit.create(MeasurementApi::class.java)
    }


    // Пример ProfileApi.kt (если нужен отдельный API):
    interface ProfileApi {

        @PUT("patients/{id}")
        suspend fun updatePatient(
            @Path("id") patientId: Int,
            @Body patient: UpdatePatientRequest
        ): Response<Patient>

        @GET("patients/{id}/favorites")
        suspend fun getFavoriteProducts(@Path("id") patientId: Int): Response<List<Product>>

        @POST("patients/{id}/favorites")
        suspend fun addToFavorites(
            @Path("id") patientId: Int,
            @Body request: AddToFavoritesRequest
        ): Response<Unit>

        @DELETE("patients/{id}/favorites/{productId}")
        suspend fun removeFromFavorites(
            @Path("id") patientId: Int,
            @Path("productId") productId: Int
        ): Response<Unit>
    }

    data class UpdatePatientRequest(
        val fullName: String,
        val gender: String,
        val birthDate: String,
        val notes: String
    )

    data class AddToFavoritesRequest(
        val productId: Int
    )
}