package com.skinora.app.data.model

import com.google.gson.annotations.SerializedName

data class TokenResponse(
    val token: String
)

data class User(
    val id: Int,
    val email: String,
    val passwordHash: String,  // Точно как на сервере
    val fullName: String,      // Точно как на сервере
    val avatarUrl: String?,    // Точно как на сервере
    val role: Role,
    @SerializedName("active")  // Сервер возвращает "active", а не "isActive"
    val isActive: Boolean,
    val createdAt: String,     // Сервер возвращает строку
    val updatedAt: String      // Сервер возвращает строку
)

data class Role(
    val id: Int,
    val name: String
)