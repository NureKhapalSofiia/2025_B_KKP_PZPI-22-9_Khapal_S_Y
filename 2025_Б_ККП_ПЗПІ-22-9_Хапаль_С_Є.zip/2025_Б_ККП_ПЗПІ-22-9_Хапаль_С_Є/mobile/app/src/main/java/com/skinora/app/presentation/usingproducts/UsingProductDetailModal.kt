package com.skinora.app.presentation.usingproducts

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.skinora.app.data.model.UsingProduct


@Composable
fun UsingProductDetailModal(
    product: UsingProduct,
    isStoppingProduct: Boolean,
    onDismiss: () -> Unit,
    onStopProduct: () -> Unit
) {
    val animationProgress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 500)
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(900.dp)
            .background(Color.Black.copy(alpha = 0.3f))
            .clickable { onDismiss() }
    ) {
        val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

        Canvas(modifier = Modifier.fillMaxSize()) {
            val backWaveColor = Color(0xFFD3CBFF)
            val frontWaveColor = Color(0xFFC5BAFF)
            // Задняя волна
            val backWave = Path().apply {
                moveTo(0f, size.height * 0.28f)
                quadraticBezierTo(
                    size.width * 0.375f, size.height * 0.28f,
                    size.width * 0.59f, size.height * 0.42f
                )
                quadraticBezierTo(
                    size.width * 0.86f, size.height * 0.53f,
                    size.width, size.height * 0.40f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(backWave, color = backWaveColor)

            // Передняя волна
            val frontWave = Path().apply {
                moveTo(0f, size.height * 0.33f)
                quadraticBezierTo(
                    size.width * 0.38f, size.height * 0.33f,
                    size.width * 0.58f, size.height * 0.47f
                )
                quadraticBezierTo(
                    size.width * 0.85f, size.height * 0.58f,
                    size.width, size.height * 0.45f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(frontWave, color = frontWaveColor)
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            Spacer(modifier = Modifier.height(300.dp))

            Text(
                text = product.product.name ?: "Невідомий продукт",
                fontFamily = kleeOne,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.Black,
                maxLines = 2,
                overflow = TextOverflow.Clip,
                modifier = Modifier
                    .fillMaxWidth(0.55f)
            )


            Spacer(modifier = Modifier.height(60.dp))


                Text(
                    text = "Опис: ${product.product.description}",
                    fontSize = 15.sp,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))



                Text(
                    text = "Бренд: ${product.product.brand}",
                    fontSize = 15.sp,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))


                Text(
                    text = "Категорія: ${product.product.category}",
                    fontSize = 15.sp,
                    color = Color.Black,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))


            // Дата початку
            Text(
                text = "Дата початку використання: ${formatDate(product.startedAt)}",
                fontSize = 15.sp,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Кнопка "Припинити використання"
            Button(
                onClick = onStopProduct,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                enabled = !isStoppingProduct,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFEF4444)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                if (isStoppingProduct) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Припиняємо...",
                        fontSize = 15.sp,
                        fontFamily = kleeOne,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                } else {
                    Text(
                        text = "Припинити",
                        fontSize = 15.sp,
                        letterSpacing = (-1).sp,
                        fontFamily = kleeOne,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                }
            }
        }
    }

}

private fun formatDate(dateString: String?): String {
    return try {
        // Проверяем на null и пустую строку
        if (dateString.isNullOrBlank()) return "Невідомо"

        // Обрабатываем формат "2024-12-01" или "2024-12-01T10:00:00"
        val cleanDate = dateString.replace("T", " ").split(" ")[0]
        val parts = cleanDate.split("-")
        if (parts.size >= 3) {
            "${parts[2]}.${parts[1]}.${parts[0]}"
        } else {
            dateString
        }
    } catch (e: Exception) {
        dateString ?: "Невідомо"
    }
}