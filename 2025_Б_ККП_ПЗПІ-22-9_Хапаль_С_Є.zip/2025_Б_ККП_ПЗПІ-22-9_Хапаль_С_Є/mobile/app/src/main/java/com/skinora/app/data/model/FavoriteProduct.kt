package com.skinora.app.data.model

import com.google.gson.annotations.SerializedName

data class FavoriteProduct(
    @SerializedName("id") val id: Long,
    @SerializedName("patient") val patient: Patient,
    @SerializedName("product") val product: Product,
    @SerializedName("addedAt") val addedAt: String
)