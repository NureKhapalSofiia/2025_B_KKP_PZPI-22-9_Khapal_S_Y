package com.skinora.app.presentation.profile

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.R
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import com.skinora.app.ui.components.TopPurpleWaves
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.dp

@Composable
fun ProfileScreen(
    onLogout: () -> Unit,
    onEditProfile: () -> Unit = {},
    onFavoriteProducts: () -> Unit = {},
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Обработка успешного обновления профиля
    LaunchedEffect(uiState.profileUpdateSuccess) {
        if (uiState.profileUpdateSuccess) {
            // Обновляем данные профиля после успешного изменения
            viewModel.refreshProfile()
            viewModel.clearUpdateSuccess()
        }
    }

    // Обновляем профиль при первом запуске экрана
    LaunchedEffect(Unit) {
        viewModel.refreshProfile()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFE4EDFD), Color.White), // фіолетово-білий
                    startY = 0f,
                    endY = Float.POSITIVE_INFINITY
                )
            )

    ) {
        WaveTopBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(70.dp))

            Image(
                painter = painterResource(id = R.drawable.profil), // заміни на свій ресурс
                contentDescription = "Avatar",
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE0DFFF))
            )
                ProfileCard(
                    userName = uiState.currentUserName,
                    userEmail = uiState.currentUserEmail,
                    patientData = uiState.patient,
                    analysisCount = uiState.analysisCount,
                    productsCount = uiState.productsCount,
                    recommendationsCount = uiState.recommendationsCount,
                    isLoading = uiState.isLoading
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Меню настроек
                ProfileMenuItem(
                    icon = R.drawable.profil,
                    title = "Редагувати профіль",
                    onClick = onEditProfile
                )

                Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.SpaceBetween // розмістити верх і низ
            ) {
                Column {                OutlinedButton(
                    onClick = { viewModel.refreshProfile() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    enabled = !uiState.isLoading,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = PurpleGradientStart
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = PurpleGradientStart,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = if (uiState.isLoading) "Оновлення..." else "Оновити дані",
                        fontSize = 14.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Medium
                    )

                }
                }
                Spacer(modifier = Modifier.height(12.dp))

                // Кнопка выхода
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                        Button(
                            onClick = {
                                viewModel.logout()
                                onLogout()
                            },
                            modifier = Modifier
                                .fillMaxWidth(0.8f) // 80% ширини, по центру
                                .height(56.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFEF4444)
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = "Вийти з акаунту",
                                fontSize = 16.sp,
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(32.dp)) // невеликий відступ знизу
                    }}
        }


        // Показ ошибок
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                        fontFamily = KleeOneFamily
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK", fontFamily = KleeOneFamily)
                    }
                }
            }
        }

        // Показ успешного обновления
        if (uiState.profileUpdateSuccess) {
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF10B981)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Профіль успішно оновлено!",
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                        fontFamily = KleeOneFamily
                    )

                    TextButton(
                        onClick = { viewModel.clearUpdateSuccess() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK", fontFamily = KleeOneFamily)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileCard(
    userName: String,
    userEmail: String,
    patientData: com.skinora.app.data.model.Patient?,
    analysisCount: Int,
    productsCount: Int,
    recommendationsCount: Int,
    isLoading: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp // без тени
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Имя пользователя
            Text(
                text = when {
                    isLoading -> "Завантаження..."
                    userName.isNotEmpty() -> userName
                    patientData?.user?.fullName?.isNotEmpty() == true -> patientData.user.fullName
                    userEmail.isNotEmpty() -> userEmail.substringBefore("@")
                    else -> "Користувач"
                },
                fontSize = 20.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69)
            )

            Text(
                text = userEmail.ifEmpty { "example@email.com" },
                fontSize = 14.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6B7280)
            )

            // Показываем дополнительную информацию о пациенте если есть
            patientData?.let { patient ->
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    if (!patient.gender.isNullOrEmpty()) {
                        InfoChip(text = patient.gender)
                    }
                    if (!patient.birthDate.isNullOrEmpty()) {
                        InfoChip(text = "Вік: ${calculateAge(patient.birthDate)}")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Статистика
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StatCard(
                    title = "Аналізи",
                    count = if (isLoading) "..." else analysisCount.toString()
                )
                StatCard(
                    title = "Продукти",
                    count = if (isLoading) "..." else productsCount.toString()
                )
                StatCard(
                    title = "Рекомендації",
                    count = if (isLoading) "..." else recommendationsCount.toString()
                )
            }
        }
    }
}

@Composable
private fun InfoChip(text: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = PurpleGradientStart.copy(alpha = 0.1f)
        )
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            fontSize = 11.sp,
            fontFamily = KleeOneFamily,
            color = PurpleGradientStart
        )
    }
}

private fun calculateAge(birthDate: String?): String {
    if (birthDate.isNullOrEmpty()) return "?"
    return try {
        val year = birthDate.substring(0, 4).toInt()
        val currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        (currentYear - year).toString()
    } catch (e: Exception) {
        "?"
    }
}

@Composable
private fun StatCard(
    title: String,
    count: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = count,
            fontSize = 24.sp,
            fontFamily = KleeOneFamily,
            fontWeight = FontWeight.Bold,
            color = PurpleGradientStart
        )

        Text(
            text = title,
            fontSize = 12.sp,
            fontFamily = KleeOneFamily,
            fontWeight = FontWeight.Normal,
            color = Color(0xFF6B7280)
        )
    }
}

@Composable
private fun ProfileMenuItem(
    icon: Int,
    title: String,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
                .clip(RoundedCornerShape(50))
                .background(Color.White)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = icon),
                contentDescription = null,
                modifier = Modifier.size(40.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun WaveTopBackground(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxWidth().height(550.dp)) {
        val path = Path().apply {
            moveTo(0f, size.height * 0.55f)
            quadraticBezierTo(
                size.width * 0.24f, size.height * 0.75f,
                size.width * 0.48f, size.height * 0.60f
            )
            quadraticBezierTo(
                size.width * 0.75f, size.height * 0.45f,
                size.width, size.height * 0.58f
            )
            lineTo(size.width, 0f)
            lineTo(0f, 0f)
            close()
        }

        drawPath(path = path, color = Color.White)
    }
}