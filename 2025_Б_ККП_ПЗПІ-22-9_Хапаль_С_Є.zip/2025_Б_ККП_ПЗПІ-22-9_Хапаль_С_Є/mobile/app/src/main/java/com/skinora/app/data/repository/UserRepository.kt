package com.skinora.app.data.repository

import com.skinora.app.data.api.UserApi
import com.skinora.app.data.model.User
import com.skinora.app.utils.Resource
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepository @Inject constructor(
    private val userApi: UserApi
) {

    suspend fun getUserById(userId: Int): Resource<User> {
        return try {
            val response = userApi.getUserById(userId)
            if (response.isSuccessful) {
                response.body()?.let { user ->
                    Resource.Success(user)
                } ?: Resource.Error("Empty response")
            } else {
                Resource.Error("Failed to get user: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun updateUserProfile(user: User): Resource<User> {
        return try {
            val response = userApi.updateUserProfile(user)
            if (response.isSuccessful) {
                response.body()?.let { updatedUser ->
                    Resource.Success(updatedUser)
                } ?: Resource.Error("Empty response")
            } else {
                Resource.Error("Failed to update user: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun deleteUser(userId: Int): Resource<Unit> {
        return try {
            val response = userApi.deleteUserById(userId)
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error("Failed to delete user: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun changePassword(userId: Int, oldPassword: String, newPassword: String): Resource<User> {
        return try {
            val response = userApi.changePassword(userId, oldPassword, newPassword)
            if (response.isSuccessful) {
                response.body()?.let { updatedUser ->
                    Resource.Success(updatedUser)
                } ?: Resource.Error("Empty response")
            } else {
                Resource.Error("Failed to change password: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }
}