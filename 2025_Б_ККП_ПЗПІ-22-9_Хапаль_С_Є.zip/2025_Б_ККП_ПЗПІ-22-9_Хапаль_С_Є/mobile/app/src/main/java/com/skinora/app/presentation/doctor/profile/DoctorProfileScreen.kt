package com.skinora.app.presentation.doctor.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun DoctorProfileScreen(
    onLogout: () -> Unit,
    viewModel: DoctorProfileViewModel = hiltViewModel()
) {
    val profileState by viewModel.profileState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White,
                        PurpleGradientEnd.copy(alpha = 0.1f)
                    )
                )
            )
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(24.dp))

                // Профиль доктора
                DoctorProfileCard(
                    doctorName = profileState.doctorName,
                    specialization = profileState.specialization,
                    experience = profileState.experienceYears,
                    bio = profileState.bio
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Статистика работы
                DoctorStatsCard(
                    totalPatients = profileState.totalPatients,
                    totalRecommendations = profileState.totalRecommendations,
                    totalConsultations = profileState.totalConsultations
                )
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Настройки и действия
                DoctorSettingsCard(
                    onLogout = onLogout
                )
            }
        }

        // Индикатор загрузки
        if (profileState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = PurpleGradientStart
                )
            }
        }

        // Показ ошибок
        profileState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}

@Composable
private fun DoctorProfileCard(
    doctorName: String,
    specialization: String,
    experience: Int,
    bio: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Аватар доктора
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(PurpleGradientStart, PurpleGradientEnd)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = getDoctorInitials(doctorName),
                    fontSize = 32.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Имя доктора
            Text(
                text = doctorName,
                fontSize = 24.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Специализация
            Text(
                text = specialization,
                fontSize = 16.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Medium,
                color = PurpleGradientStart
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Опыт работы
            Text(
                text = "Досвід роботи: $experience років",
                fontSize = 14.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6B7280)
            )

            if (bio.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))

                // Биография
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = PurpleGradientEnd.copy(alpha = 0.1f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = bio,
                        fontSize = 14.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF6B7280),
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun DoctorStatsCard(
    totalPatients: Int,
    totalRecommendations: Int,
    totalConsultations: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Статистика роботи",
                fontSize = 18.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                DoctorStatItem(
                    value = totalPatients.toString(),
                    label = "Пацієнтів",
                    color = PurpleGradientStart
                )

                DoctorStatItem(
                    value = totalRecommendations.toString(),
                    label = "Рекомендацій",
                    color = Color(0xFF4CAF50)
                )

                DoctorStatItem(
                    value = totalConsultations.toString(),
                    label = "Консультацій",
                    color = Color(0xFFFF6B6B)
                )
            }
        }
    }
}

@Composable
private fun DoctorStatItem(
    value: String,
    label: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontSize = 32.sp,
            fontFamily = KleeOneFamily,
            fontWeight = FontWeight.Bold,
            color = color
        )

        Text(
            text = label,
            fontSize = 12.sp,
            fontFamily = KleeOneFamily,
            fontWeight = FontWeight.Normal,
            color = Color(0xFF6B7280)
        )
    }
}

@Composable
private fun DoctorSettingsCard(
    onLogout: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Налаштування",
                fontSize = 18.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF2D1B69)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Кнопка редактирования профиля
            OutlinedButton(
                onClick = { /* TODO: Implement edit profile */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = PurpleGradientStart
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Редагувати профіль",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Кнопка управления пациентами
            OutlinedButton(
                onClick = { /* TODO: Implement manage patients */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFF4CAF50)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Управління пацієнтами",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Кнопка выхода
            Button(
                onClick = onLogout,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFEF4444)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Вийти з акаунту",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}

private fun getDoctorInitials(fullName: String): String {
    return fullName.split(" ")
        .take(2)
        .mapNotNull { it.firstOrNull()?.uppercaseChar() }
        .joinToString("")
        .ifEmpty { "Л" }
}