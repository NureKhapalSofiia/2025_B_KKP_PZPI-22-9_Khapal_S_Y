package com.skinora.app.presentation.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import com.skinora.app.ui.components.PurpleWaves
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.skinora.app.R



@Composable
fun SignInScreen(
    onSignUpClick: () -> Unit,
    onSignInSuccess: () -> Unit,
    viewModel: AuthViewModel = hiltViewModel()
) {

    val authState by viewModel.authState.collectAsStateWithLifecycle()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val kleeOne = FontFamily(Font(R.font.klee_one_regular))
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val scope = rememberCoroutineScope()

    // Обработка успешного входа
    LaunchedEffect(authState.isLoggedIn) {
        if (authState.isLoggedIn) {
            onSignInSuccess()
        }
    }

    // Показ ошибок
    authState.error?.let { error ->
        LaunchedEffect(error) {
            // Здесь можно показать Snackbar или Toast
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(screenHeight * 0.9f)
    ) {
        // ЗАДНІЙ фоновий прямокутник нижче хвиль
        Box(
            modifier = Modifier
                .matchParentSize()
                .padding(top = 500.dp)
                .background(Color(0xFFC5BAFF))
        )

        // Хвилі
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(500.dp)
                .align(Alignment.TopCenter)
        ) {
            val back = Path().apply {
                moveTo(0f, size.height * 0.25f)
                quadraticBezierTo(
                    size.width * 0.375f, size.height * 0.25f,
                    size.width * 0.52f, size.height * 0.49f
                )
                quadraticBezierTo(
                    size.width * 0.76f, size.height * 0.85f,
                    size.width, size.height * 0.54f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(back, color = Color(0xFFD3CBFF))

            val front = Path().apply {
                moveTo(0f, size.height * 0.30f)
                quadraticBezierTo(
                    size.width * 0.38f, size.height * 0.30f,
                    size.width * 0.56f, size.height * 0.57f
                )
                quadraticBezierTo(
                    size.width * 0.78f, size.height * 0.85f,
                    size.width, size.height * 0.63f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(front, color = Color(0xFFC5BAFF))
        }

                Text(
                    text = "Sign in",
                    fontFamily = kleeOne,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.Black,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 24.dp, top = screenHeight * 0.25f)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "увійти у свій акаунт",
                    color = Color.Black,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 24.dp, top = screenHeight * 0.30f)
                )

            // Форма входа

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 400.dp, start = 24.dp, end = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Email поле
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = {
                            Text(
                                "Адреса електронної пошти",
                                fontSize = 18.sp,
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email
                        ),
                        shape = RoundedCornerShape(32.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xFFFBFBFB),
                            focusedContainerColor = Color(0xFFFBFBFB),
                            disabledContainerColor = Color(0xFFFBFBFB),
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        )
                    )

                    // Password поле
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = {
                            Text(
                                "Пароль",
                                fontSize = 18.sp,
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp),
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),
                        shape = RoundedCornerShape(32.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xFFFBFBFB),
                            focusedContainerColor = Color(0xFFFBFBFB),
                            disabledContainerColor = Color(0xFFFBFBFB),
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Кнопка Sign In
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        val context = LocalContext.current
                        val scope = rememberCoroutineScope()

                        Button(
                        onClick = {
                            if (email.isNotBlank() && password.isNotBlank()) {
                                viewModel.login(email, password)
                            }
                        },
                        enabled = !authState.isLoading,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFBFBFB),
                            contentColor = Color.Black,
                        )
                        ){
                        if (authState.isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White
                            )
                        } else {
                            Text(
                                text = "Sign in",
                                fontSize = 18.sp,
                                fontFamily = kleeOne
                            )
                        }
                    }
                        OutlinedButton(
                            onClick = onSignUpClick,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(58.dp)
                                .weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFFFBFBFB),
                                contentColor = Color.Black
                            ),
                            border = BorderStroke(1.dp, Color.Transparent)
                        ) {
                            Text(
                                text = "Sign up",
                                fontSize = 18.sp,
                                fontFamily = kleeOne
                            )
                        }
                }
            }
        }

        // Показ ошибок
        authState.error?.let { error ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 3.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Text(
                    text = error,
                    modifier = Modifier.padding(16.dp),
                    color = Color.White,
                    fontFamily = KleeOneFamily
                )
            }
        }
    }
