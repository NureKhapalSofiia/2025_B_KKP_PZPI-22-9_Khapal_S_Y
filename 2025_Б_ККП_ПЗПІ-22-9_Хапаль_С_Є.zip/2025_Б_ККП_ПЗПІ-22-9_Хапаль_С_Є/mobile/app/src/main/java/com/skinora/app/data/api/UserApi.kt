package com.skinora.app.data.api

import com.skinora.app.data.model.User
import retrofit2.Response
import retrofit2.http.*

interface UserApi {

    @GET("users/{id}")
    suspend fun getUserById(@Path("id") userId: Int): Response<User>

    @PUT("users/update")
    suspend fun updateUserProfile(@Body user: User): Response<User>

    @DELETE("users/{id}")
    suspend fun deleteUserById(@Path("id") userId: Int): Response<Unit>

    @PATCH("users/{id}/change-password")
    suspend fun changePassword(
        @Path("id") userId: Int,
        @Query("oldPassword") oldPassword: String,
        @Query("newPassword") newPassword: String
    ): Response<User>
}