package com.skinora.app.data.repository

import com.skinora.app.data.api.AuthApi
import com.skinora.app.data.model.*
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val authApi: AuthApi,
    private val preferencesManager: PreferencesManager
) {

    suspend fun register(
        name: String,
        email: String,
        password: String,
        role: String
    ): Resource<UserResponse> {
        return try {
            val response = authApi.register(
                RegisterRequest(name, email, password, role)
            )

            if (response.isSuccessful) {
                response.body()?.let { userResponse ->
                    Resource.Success(userResponse)
                } ?: Resource.Error("Empty response")
            } else {
                Resource.Error("Registration failed: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun login(email: String, password: String): Resource<AuthResponse> {
        return try {
            val response = authApi.login(LoginRequest(email, password))
            if (response.isSuccessful) {
                val authResponse = response.body()!!

                // Сохраняем токен
                preferencesManager.saveToken(authResponse.token)

                // Сохраняем email пользователя
                preferencesManager.saveUserEmail(email)

                // ИСПРАВЛЕНО: Обязательно сохраняем ID пользователя или возвращаем ошибку
                if (authResponse.user?.id != null) {
                    preferencesManager.saveUserId(authResponse.user.id)
                    // Также сохраняем имя пользователя если есть
                    authResponse.user.fullName?.let { name ->
                        preferencesManager.saveUserName(name)
                    }
                } else {
                    // Если нет ID пользователя в ответе - это ошибка
                    return Resource.Error("User ID not provided in response")
                }

                Resource.Success(authResponse)
            } else {
                Resource.Error("Login failed: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getUserRole(email: String): Resource<RoleResponse> {
        return try {
            val response = authApi.getUserRole(email)

            if (response.isSuccessful) {
                response.body()?.let { roleResponse ->
                    Resource.Success(roleResponse)
                } ?: Resource.Error("Empty response")
            } else {
                Resource.Error("Failed to get role: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun logout() {
        preferencesManager.clearUserData()
    }

    suspend fun isLoggedIn(): Boolean {
        val token = preferencesManager.getToken().first()
        val userId = preferencesManager.getUserId().first()
        // Пользователь залогинен только если есть и токен, и валидный ID
        return token.isNotEmpty() && userId > 0
    }

    fun getToken(): Flow<String> = preferencesManager.getToken()

    fun getUserEmail(): Flow<String> = preferencesManager.getUserEmail()

    fun getUserId(): Flow<Int> = preferencesManager.getUserId()

    fun getUserName(): Flow<String> = preferencesManager.getUserName()

    suspend fun getCurrentUserId(): Int {
        return preferencesManager.getUserId().first()
    }
}