package com.skinora.app.presentation.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.PurpleGradientStart
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

@Composable
fun AppointmentDialog(
    doctorName: String,
    onDismiss: () -> Unit,
    onConfirm: (datetime: String, notes: String) -> Unit
) {
    var selectedDate by remember { mutableStateOf("") }
    var selectedTime by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Предустановленные варианты времени
    val timeSlots = listOf(
        "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
        "14:00", "14:30", "15:00", "15:30", "16:00", "16:30"
    )

    // Следующие 7 дней
    val dateOptions = remember {
        (1..7).map { dayOffset ->
            val date = LocalDateTime.now().plusDays(dayOffset.toLong())
            date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) to
                    date.format(DateTimeFormatter.ofPattern("dd MMM", Locale("uk")))
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(1.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Заголовок
                Text(
                    text = "Запропонувати зустріч",
                    fontSize = 20.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Black
                )

                Text(
                    text = "з $doctorName",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Выбор даты
                Text(
                    text = "Оберіть дату:",
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF374151),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    items(dateOptions) { (isoDate, displayDate) ->
                        Card(
                            modifier = Modifier
                                .width(70.dp),
                            shape = RoundedCornerShape(50.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedDate == isoDate)
                                    PurpleGradientStart else Color.White
                            ),
                            onClick = { selectedDate = isoDate }
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(70.dp)
                                    .height(40.dp)
                                    .border(
                                        width = 2.dp,
                                        color = PurpleGradientStart, // Сіра рамка
                                        shape = RoundedCornerShape(50.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = displayDate,
                                    fontSize = 12.sp,
                                    fontFamily = KleeOneFamily,
                                    color = if (selectedDate == isoDate)
                                        Color.White else Color(0xFF374151)
                                )
                            }
                        }
                    }
                }

                // Выбор времени
                Text(
                    text = "Оберіть час:",
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF374151),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    items(timeSlots) { time ->
                        Card(
                            modifier = Modifier
                                .width(70.dp),
                            shape = RoundedCornerShape(50.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedTime == time)
                                    PurpleGradientStart else Color.White
                            ),
                            onClick = { selectedTime = time }
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(70.dp)
                                    .height(40.dp)
                                    .border(
                                        width = 2.dp,
                                        color = PurpleGradientStart,
                                        shape = RoundedCornerShape(50.dp)
                                        ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = time,
                                    fontSize = 12.sp,
                                    fontFamily = KleeOneFamily,
                                    color = if (selectedTime == time)
                                        Color.White else Color(0xFF374151)
                                )
                            }
                        }
                    }
                }

                // Примечания
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    placeholder = {
                        Text(
                            text = "Додаткові нотатки (необов'язково)",
                            fontFamily = KleeOneFamily,
                            color = Color(0xFF6B7280)
                        )
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurpleGradientStart,
                        unfocusedBorderColor = Color(0xFFE5E7EB)
                    ),
                    maxLines = 3
                )
                val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))
                // Кнопки
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF6B7280)
                        )
                    ) {
                        Text(
                            text = "Скасувати",
                            fontFamily = kleeOne,
                            letterSpacing = (-5).sp
                        )
                    }


                    Button(
                        onClick = {
                            if (selectedDate.isNotEmpty() && selectedTime.isNotEmpty()) {
                                val datetime = "${selectedDate}T${selectedTime}:00"
                                onConfirm(datetime, notes)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = selectedDate.isNotEmpty() && selectedTime.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PurpleGradientStart
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            maxLines = 1,
                            text = "Підтвердити",
                            fontFamily = kleeOne,
                            letterSpacing = (-5).sp,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}