package com.skinora.app.presentation.chat

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.R
import com.skinora.app.data.model.Appointment
import com.skinora.app.data.model.Chat
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import com.skinora.app.ui.components.TopPurpleWaves


@Composable
private fun ChatCard(
    chat: Chat,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        ),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Аватар врача
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(PurpleGradientStart.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.doctor),
                    contentDescription = "Doctor avatar",
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о чате
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = chat.participant2.user?.fullName ?: "Невідомий лікар",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Black
                )

                Text(
                    text = chat.participant2.specialization ?: "Спеціалізація невідома",
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Натисніть для перегляду повідомлень",
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF374151)
                )
            }
        }
    }
}
@Composable
fun ChatScreen(
    onChatClick: (Chat) -> Unit = {},
    onFindDoctorClick: () -> Unit = {},
    viewModel: ChatListViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val kleeOne = FontFamily(Font(R.font.klee_one_regular))


    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(
                colors = listOf(Color(0xFFE4EDFD), Color.White),
                startY = 0f,
                endY = Float.POSITIVE_INFINITY
            ))
    ) {

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 100.dp)
        ) {
            item {
                // Заголовок с кнопкой обновления
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Мої записи",
                        fontSize = 24.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Black
                    )

                    IconButton(onClick = { viewModel.refreshData() }) {
                        Text("↻", fontSize = 20.sp, color = PurpleGradientStart)
                    }
                }
            }

            // СЕКЦИЯ ВСТРЕЧ
            item {
                AppointmentsSection(
                    appointments = uiState.appointments,
                    isLoading = uiState.isLoadingAppointments,
                    onCancelAppointment = { appointmentId ->
                        viewModel.cancelAppointment(appointmentId)
                    }
                )

                Spacer(modifier = Modifier.height(24.dp))
            }

            item {
                // Заголовок чатов
                Text(
                    text = "Чати з лікарями",
                    fontSize = 20.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69),
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            if (uiState.isLoading) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = PurpleGradientStart)
                    }
                }
            } else {
                items(uiState.chats) { chat ->
                    ChatCard(
                        chat = chat,
                        onClick = { onChatClick(chat) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))

                // Кнопка найти нового врача
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Button(
                        onClick = onFindDoctorClick,
                        colors = ButtonDefaults.buttonColors(containerColor = PurpleGradientStart),
                        shape = RoundedCornerShape(50), // овальна форма
                        modifier = Modifier
                            .wrapContentWidth()
                            .padding(horizontal = 24.dp)
                    ) {
                        Text(
                            text = "Знайти    нового   л і каря",
                            fontSize = 16.sp,
                            fontFamily = kleeOne,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            letterSpacing = (-5).sp
                        )
                    }
                }
            }
        }

        // Error display
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}
private fun formatAppointmentDateTime(datetime: String): String {
    return try {
        // Преобразуем "2025-06-07T14:30:00" в читабельный формат
        val parts = datetime.split("T")
        if (parts.size == 2) {
            val datePart = parts[0] // "2025-06-07"
            val timePart = parts[1].substring(0, 5) // "14:30"

            // Конвертируем дату в более читабельный формат
            val dateComponents = datePart.split("-")
            if (dateComponents.size == 3) {
                val day = dateComponents[2]
                val month = when (dateComponents[1]) {
                    "01" -> "січ"
                    "02" -> "лют"
                    "03" -> "бер"
                    "04" -> "квіт"
                    "05" -> "трав"
                    "06" -> "черв"
                    "07" -> "лип"
                    "08" -> "серп"
                    "09" -> "вер"
                    "10" -> "жовт"
                    "11" -> "лист"
                    "12" -> "груд"
                    else -> dateComponents[1]
                }
                "$day $month о $timePart"
            } else {
                "$datePart о $timePart"
            }
        } else {
            datetime
        }
    } catch (e: Exception) {
        datetime
    }
}

@Composable
fun ThreeDotsIcon(
    modifier: Modifier = Modifier,
    color: Color = PurpleGradientStart,
    size: Dp = 20.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val radius = size.toPx() * 0.1f
        val centerX = size.toPx() / 2
        val spacing = size.toPx() / 4

        drawCircle(color, radius, center = Offset(centerX, spacing))
        drawCircle(color, radius, center = Offset(centerX, size.toPx() / 2))
        drawCircle(color, radius, center = Offset(centerX, size.toPx() - spacing))
    }
}


@Composable
fun AppointmentCard(
    appointment: Appointment,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Иконка встречи
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        when (appointment.status.uppercase()) {
                            "CONFIRMED" -> Color(0xFF10B981).copy(alpha = 0.1f)
                            "PENDING" -> PurpleGradientStart.copy(alpha = 0.1f)
                            else -> Color(0xFFFFFFFF)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                val iconRes = when (appointment.status.uppercase()) {
                    "CONFIRMED" -> R.drawable.confirmed
                    "PENDING" -> R.drawable.pending
                    else -> R.drawable.other
                }

                Image(
                    painter = painterResource(id = iconRes),
                    contentDescription = null,
                    modifier = Modifier
                        .size(25.dp) // трохи менше, щоб гарно вмістити
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о встрече
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = appointment.doctor.user?.fullName ?: "Невідомий лікар",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = appointment.doctor.specialization ?: "Спеціалізація невідома",
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = formatAppointmentDateTime(appointment.datetime),
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium,
                    color = Color.Black
                )

                // Статус
                Text(
                    text = when (appointment.status.uppercase()) {
                        "CONFIRMED" -> "Підтверджено"
                        "PENDING" -> "Очікує підтвердження"
                        "CANCELLED" -> "Скасовано"
                        else -> appointment.status
                    },
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = when (appointment.status.uppercase()) {
                        "CONFIRMED" -> Color.Black
                        "PENDING" -> Color.Black
                        "CANCELLED" -> Color.Black
                        else -> Color.Black
                    }
                )
            }

            // Кнопка отмены (только для PENDING и CONFIRMED)
            if (appointment.status.uppercase() in listOf("PENDING", "CONFIRMED")) {
                var showDialog by remember { mutableStateOf(false) }

                IconButton(
                    onClick = { showDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    ThreeDotsIcon()
                }

                if (showDialog) {
                    AlertDialog(
                        onDismissRequest = { showDialog = false },
                        title = {
                            Text(
                                text = "Скасування зустрічі",
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp
                            )
                        },
                        text = {
                            Text(
                                text = "Дійсно бажаєте скасувати зустріч?",
                                fontFamily = KleeOneFamily,
                                fontSize = 16.sp
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                showDialog = false
                                onCancel()
                            }) {
                                Text("Так", color = PurpleGradientStart)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showDialog = false }) {
                                Text("Ні", color = PurpleGradientStart)
                            }
                        }
                    )
                }
            }

        }
    }
}

@Composable
private fun AppointmentsSection(
    appointments: List<Appointment>,
    isLoading: Boolean,
    onCancelAppointment: (Int) -> Unit
) {


        if (isLoading) {
            // Индикатор загрузки
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = PurpleGradientStart,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        } else if (appointments.isEmpty()) {
            // Пустое состояние
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = PurpleGradientStart.copy(alpha = 0.05f)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        text = "Немає запланованих зустрічей",
                        fontSize = 16.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Medium,
                        color = Color.Black
                    )

                    Text(
                        text = "Запропонуйте зустріч лікарю в чаті",
                        fontSize = 14.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color.Black,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            // Список встреч
            appointments.forEach { appointment ->
                AppointmentCard(
                    appointment = appointment,
                    onCancel = { onCancelAppointment(appointment.id) }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }


