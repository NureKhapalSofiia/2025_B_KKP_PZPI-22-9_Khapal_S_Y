package com.skinora.app.presentation.profile

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.Product
import com.skinora.app.data.repository.ProductRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FavoriteProductsState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val favoriteProducts: List<Product> = emptyList(),
    val currentUserId: Int? = null,
    val isRemovingFromFavorites: Boolean = false
)

@HiltViewModel
class FavoriteProductsViewModel @Inject constructor(
    private val productRepository: ProductRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(FavoriteProductsState())
    val uiState: StateFlow<FavoriteProductsState> = _uiState.asStateFlow()

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()
                val userEmail = preferencesManager.getUserEmail().first()

                Log.d("FavoriteProductsViewModel", "Current user ID: $userId, email: $userEmail")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(currentUserId = userId)

                // Загружаем избранные продукты
                loadFavoriteProducts()

            } catch (e: Exception) {
                Log.e("FavoriteProductsViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження користувача: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    fun selectProduct(product: Product) {
        _selectedProduct.value = product
    }


    private fun loadFavoriteProducts() {
        val userId = _uiState.value.currentUserId
        if (userId == null || userId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити улюблені продукти: невірний ID користувача"
            )
            return
        }

        Log.d("FavoriteProductsViewModel", "Loading favorite products for user: $userId")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = productRepository.getFavoriteProducts(userId)) {
                is Resource.Success -> {
                    Log.d("FavoriteProductsViewModel", "Favorite products loaded: ${result.data?.size ?: 0} items")
                    val products = result.data ?: emptyList()

                    _uiState.value = _uiState.value.copy(
                        favoriteProducts = products,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("FavoriteProductsViewModel", "Error loading favorite products: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        favoriteProducts = emptyList(),
                        isLoading = false,
                        error = "Помилка завантаження улюблених продуктів: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun removeFromFavorites(productId: Int) {
        val userId = _uiState.value.currentUserId
        if (userId == null || userId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо видалити з улюблених: невірний ID користувача"
            )
            return
        }

        Log.d("FavoriteProductsViewModel", "Removing product from favorites: $productId")

        _uiState.value = _uiState.value.copy(isRemovingFromFavorites = true)

        viewModelScope.launch {
            try {
                when (val result = productRepository.removeFromFavorites(userId, productId)) {
                    is Resource.Success -> {
                        Log.d("FavoriteProductsViewModel", "Product removed from favorites successfully")

                        // Обновляем локальный список
                        val currentFavorites = _uiState.value.favoriteProducts
                        val updatedFavorites = currentFavorites.filter { it.id != productId }

                        _uiState.value = _uiState.value.copy(
                            favoriteProducts = updatedFavorites,
                            isRemovingFromFavorites = false
                        )
                    }
                    is Resource.Error -> {
                        Log.e("FavoriteProductsViewModel", "Error removing from favorites: ${result.message}")
                        _uiState.value = _uiState.value.copy(
                            isRemovingFromFavorites = false,
                            error = "Помилка видалення з улюблених: ${result.message}"
                        )
                    }
                    is Resource.Loading -> {}
                }

            } catch (e: Exception) {
                Log.e("FavoriteProductsViewModel", "Error removing from favorites: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isRemovingFromFavorites = false,
                    error = "Помилка видалення з улюблених: ${e.message}"
                )
            }
        }
    }

    fun addToFavorites(productId: Int) {
        val userId = _uiState.value.currentUserId
        if (userId == null || userId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо додати до улюблених: невірний ID користувача"
            )
            return
        }

        Log.d("FavoriteProductsViewModel", "Adding product to favorites: $productId")

        viewModelScope.launch {
            try {
                when (val result = productRepository.addToFavorites(userId, productId)) {
                    is Resource.Success -> {
                        Log.d("FavoriteProductsViewModel", "Product added to favorites successfully")
                        // Перезагружаем список избранных
                        loadFavoriteProducts()
                    }
                    is Resource.Error -> {
                        Log.e("FavoriteProductsViewModel", "Error adding to favorites: ${result.message}")
                        _uiState.value = _uiState.value.copy(
                            error = "Помилка додавання до улюблених: ${result.message}"
                        )
                    }
                    is Resource.Loading -> {}
                }

            } catch (e: Exception) {
                Log.e("FavoriteProductsViewModel", "Error adding to favorites: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка додавання до улюблених: ${e.message}"
                )
            }
        }
    }

    fun refreshFavorites() {
        Log.d("FavoriteProductsViewModel", "Refreshing favorite products")
        loadFavoriteProducts()
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}