package com.skinora.app.presentation.home

import android.util.Log
import androidx.lifecycle.ViewModel
import com.skinora.app.data.model.UsingProduct
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.PatientRepository
import com.skinora.app.data.repository.ProductRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.data.repository.MeasurementRepository
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val patient: Patient? = null,
    val latestMeasurement: Measurement? = null,
    val usingProducts: List<UsingProduct> = emptyList(),
    val usedProducts: List<UsedProduct> = emptyList(),
    val recommendations: List<Recommendation> = emptyList(),
    val patientId: Int? = null,
    val currentUserEmail: String = "",
    val currentUserName: String = ""
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val patientRepository: PatientRepository,
    private val productRepository: ProductRepository,
    private val preferencesManager: PreferencesManager,
    private val measurementRepository: MeasurementRepository
) : ViewModel() {

    private val _homeState = MutableStateFlow(HomeState())
    val homeState: StateFlow<HomeState> = _homeState.asStateFlow()

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userEmail = preferencesManager.getUserEmail().first()
                val userId = preferencesManager.getUserId().first()
                val userName = preferencesManager.getUserName().first()

                Log.d("HomeViewModel", "Current user - ID: $userId, email: $userEmail, name: $userName")

                if (userId <= 0) {
                    _homeState.value = _homeState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _homeState.value = _homeState.value.copy(
                    patientId = userId,
                    currentUserEmail = userEmail,
                    currentUserName = userName
                )

                loadHomeData()

            } catch (e: Exception) {
                Log.e("HomeViewModel", "Error loading current user: ${e.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження профілю користувача: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    fun loadHomeData() {
        val patientId = _homeState.value.patientId
        if (patientId == null || patientId <= 0) {
            _homeState.value = _homeState.value.copy(
                error = "Неможливо завантажити дані: невірний ID користувача",
                isLoading = false
            )
            return
        }

        Log.d("HomeViewModel", "Loading data for patient: $patientId")
        _homeState.value = _homeState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            try {
                // Загружаем данные пациента
                loadPatientData(patientId)

                // Загружаем измерения
                loadMeasurements(patientId)

                // Загружаем используемые продукты
                loadUsingProducts(patientId)

                // Загружаем использованные продукты
                loadUsedProducts(patientId)

                // Загружаем рекомендации
                loadRecommendations(patientId)

            } catch (e: Exception) {
                Log.e("HomeViewModel", "Error loading home data: ${e.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження даних: ${e.message}",
                    isLoading = false
                )
            } finally {
                _homeState.value = _homeState.value.copy(isLoading = false)
            }
        }
    }

    private suspend fun loadPatientData(patientId: Int) {
        when (val result = patientRepository.getPatientById(patientId)) {
            is Resource.Success -> {
                Log.d("HomeViewModel", "Patient loaded: ${result.data}")
                _homeState.value = _homeState.value.copy(patient = result.data)
            }
            is Resource.Error -> {
                Log.e("HomeViewModel", "Error loading patient: ${result.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Не вдалося завантажити дані пацієнта: ${result.message}"
                )
            }
            is Resource.Loading -> {}
        }
    }

    private suspend fun loadMeasurements(patientId: Int) {
        try {
            val latest = measurementRepository.fetchLatestMeasurement(patientId)
            if (latest != null) {
                Log.d("HomeViewModel", "Latest measurement loaded: ${latest.skinType}")
                _homeState.value = _homeState.value.copy(latestMeasurement = latest)
            } else {
                Log.w("HomeViewModel", "No measurements found")
                _homeState.value = _homeState.value.copy(
                    latestMeasurement = null
                )
            }
        } catch (e: Exception) {
            Log.e("HomeViewModel", "Error fetching latest measurement: ${e.message}")
            _homeState.value = _homeState.value.copy(
                error = "Помилка отримання останнього аналізу: ${e.message}"
            )
        }
    }


    private suspend fun loadUsingProducts(patientId: Int) {
        when (val result = productRepository.getUsingProducts(patientId)) {
            is Resource.Success -> {
                Log.d("HomeViewModel", "Using products loaded: ${result.data?.size ?: 0} items")
                val products = result.data ?: emptyList()
                _homeState.value = _homeState.value.copy(usingProducts = products)
            }
            is Resource.Error -> {
                Log.e("HomeViewModel", "Error loading using products: ${result.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження продуктів: ${result.message}"
                )
            }
            is Resource.Loading -> {}
        }
    }

    private suspend fun loadUsedProducts(patientId: Int) {
        when (val result = productRepository.getUsedProducts(patientId)) {
            is Resource.Success -> {
                Log.d("HomeViewModel", "Used products loaded: ${result.data?.size ?: 0} items")
                val products = result.data ?: emptyList()
                _homeState.value = _homeState.value.copy(usedProducts = products)
            }
            is Resource.Error -> {
                Log.e("HomeViewModel", "Error loading used products: ${result.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження використаних продуктів: ${result.message}"
                )
            }
            is Resource.Loading -> {}
        }
    }

    private suspend fun loadRecommendations(patientId: Int) {
        when (val result = patientRepository.getPatientRecommendations(patientId)) {
            is Resource.Success -> {
                Log.d("HomeViewModel", "Recommendations loaded: ${result.data?.size ?: 0} items")
                val recommendations = result.data ?: emptyList()
                _homeState.value = _homeState.value.copy(recommendations = recommendations)
            }
            is Resource.Error -> {
                Log.e("HomeViewModel", "Error loading recommendations: ${result.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження рекомендацій: ${result.message}"
                )
            }
            is Resource.Loading -> {}
        }
    }

    fun refreshData() {
        Log.d("HomeViewModel", "Refreshing data...")
        loadHomeData()
    }

    fun clearError() {
        _homeState.value = _homeState.value.copy(error = null)
    }
}