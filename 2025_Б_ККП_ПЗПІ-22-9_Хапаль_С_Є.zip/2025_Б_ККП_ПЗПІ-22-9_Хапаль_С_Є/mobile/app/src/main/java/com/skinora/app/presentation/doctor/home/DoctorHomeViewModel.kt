package com.skinora.app.presentation.doctor.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.repository.AppointmentRepository
import com.skinora.app.data.repository.ChatRepository
import com.skinora.app.data.repository.DoctorRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DoctorHomeState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val currentDoctorName: String = "",
    val doctorId: Int? = null,
    val totalPatients: Int = 0,
    val todayAppointments: Int = 0,
    val unreadMessages: Int = 0,
    val recentAppointments: List<DoctorAppointment> = emptyList()
)

@HiltViewModel
class DoctorHomeViewModel @Inject constructor(
    private val appointmentRepository: AppointmentRepository,
    private val chatRepository: ChatRepository,
    private val doctorRepository: DoctorRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _homeState = MutableStateFlow(DoctorHomeState())
    val homeState: StateFlow<DoctorHomeState> = _homeState.asStateFlow()

    init {
        loadDoctorData()
    }

    private fun loadDoctorData() {
        viewModelScope.launch {
            try {
                val userName = preferencesManager.getUserName().first()
                val userId = preferencesManager.getUserId().first()

                Log.d("DoctorHomeViewModel", "Current user - ID: $userId, name: $userName")

                if (userId <= 0) {
                    _homeState.value = _homeState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _homeState.value = _homeState.value.copy(
                    doctorId = userId,
                    currentDoctorName = userName.ifEmpty { "Доктор" }
                )

                loadDoctorStatistics()

            } catch (e: Exception) {
                Log.e("DoctorHomeViewModel", "Error loading doctor data: ${e.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження даних лікаря: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    private fun loadDoctorStatistics() {
        val doctorId = _homeState.value.doctorId
        if (doctorId == null || doctorId <= 0) {
            _homeState.value = _homeState.value.copy(
                error = "Неможливо завантажити дані: невірний ID лікаря",
                isLoading = false
            )
            return
        }

        Log.d("DoctorHomeViewModel", "Loading statistics for doctor: $doctorId")
        _homeState.value = _homeState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            try {
                // Загружаем записи доктора
                loadAppointments(doctorId)

                // Загружаем чаты для подсчета непрочитанных сообщений
                loadChatStatistics(doctorId)

                // Здесь можно добавить загрузку количества пациентов
                loadPatientsCount(doctorId)

            } catch (e: Exception) {
                Log.e("DoctorHomeViewModel", "Error loading doctor statistics: ${e.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження статистики: ${e.message}",
                    isLoading = false
                )
            } finally {
                _homeState.value = _homeState.value.copy(isLoading = false)
            }
        }
    }

    private suspend fun loadAppointments(doctorId: Int) {
        when (val result = appointmentRepository.getAppointmentsByDoctor(doctorId)) {
            is Resource.Success -> {
                val appointments = result.data ?: emptyList()
                Log.d("DoctorHomeViewModel", "Appointments loaded: ${appointments.size} items")

                // Считаем записи на сегодня
                val today = java.time.LocalDate.now()
                val todayAppointments = appointments.count { appointment ->
                    val appointmentDate = java.time.LocalDateTime.parse(
                        appointment.datetime.toString()
                    ).toLocalDate()
                    appointmentDate == today
                }

                // Преобразуем в модель для UI
                val recentAppointments = appointments.take(5).map { appointment ->
                    DoctorAppointment(
                        id = appointment.id ?: 0,
                        patientName = appointment.patient?.user?.fullName ?: "Невідомий пацієнт",
                        time = formatAppointmentTime(appointment.datetime.toString()),
                        status = appointment.status ?: "PENDING"
                    )
                }

                _homeState.value = _homeState.value.copy(
                    todayAppointments = todayAppointments,
                    recentAppointments = recentAppointments
                )
            }
            is Resource.Error -> {
                Log.e("DoctorHomeViewModel", "Error loading appointments: ${result.message}")
                _homeState.value = _homeState.value.copy(
                    error = "Помилка завантаження записів: ${result.message}"
                )
            }
            is Resource.Loading -> {}
        }
    }

    private suspend fun loadChatStatistics(doctorId: Int) {
        // Для демонстрации устанавливаем случайное количество непрочитанных сообщений
        // В реальной реализации здесь будет загрузка из API
        val unreadMessages = (0..10).random()

        _homeState.value = _homeState.value.copy(
            unreadMessages = unreadMessages
        )

        Log.d("DoctorHomeViewModel", "Unread messages: $unreadMessages")
    }

    private suspend fun loadPatientsCount(doctorId: Int) {
        // Для демонстрации устанавливаем случайное количество пациентов
        // В реальной реализации здесь будет загрузка из API
        val totalPatients = (20..100).random()

        _homeState.value = _homeState.value.copy(
            totalPatients = totalPatients
        )

        Log.d("DoctorHomeViewModel", "Total patients: $totalPatients")
    }

    private fun formatAppointmentTime(dateTimeString: String): String {
        return try {
            val dateTime = java.time.LocalDateTime.parse(dateTimeString)
            val formatter = java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")
            dateTime.format(formatter)
        } catch (e: Exception) {
            Log.e("DoctorHomeViewModel", "Error formatting time: $dateTimeString", e)
            "Невідомо"
        }
    }

    fun refreshData() {
        Log.d("DoctorHomeViewModel", "Refreshing doctor data...")
        loadDoctorStatistics()
    }

    fun clearError() {
        _homeState.value = _homeState.value.copy(error = null)
    }
}