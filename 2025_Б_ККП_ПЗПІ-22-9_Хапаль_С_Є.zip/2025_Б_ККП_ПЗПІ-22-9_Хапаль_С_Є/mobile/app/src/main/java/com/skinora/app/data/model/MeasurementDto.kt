package com.skinora.app.data.model

data class MeasurementDto(
    val id: Int,
    val skinType: String,
    val moistureLevel: Double,
    val temperature: Double,
    val takenAt: String, // ISO-8601 string, e.g. "2025-06-01T14:23:00"
    val comments: String
)