package com.skinora.app.data.model

import com.google.gson.annotations.SerializedName

data class Product(
    val id: Int,
    val name: String,
    val brand: String,
    val description: String,
    // ИСПРАВЛЕНО: сервер возвращает "certified", а не "is_certified"
    @SerializedName("certified")
    val isCertified: Boolean,
    val category: String,
    // ИСПРАВЛЕНО: сервер возвращает "createdAt", а не "created_at"
    val createdAt: String,
    // ИСПРАВЛЕНО: сервер возвращает "updatedAt", а не "updated_at"
    val updatedAt: String
)

data class UsedProduct(
    val id: Int,
    val patient: Patient,
    val product: Product,
    val status: String?,
    // ИСПРАВЛЕНО: сервер возвращает "startedAt", а не "started_at"
    val startedAt: String,
    // ИСПРАВЛЕНО: сервер возвращает "stoppedAt", а не "stopped_at"
    val stoppedAt: String?
)

data class PrescribedProduct(
    val id: Int,
    val product: Product,
    val patient: Patient,
    val doctor: Doctor,
    @SerializedName("start_date")
    val startDate: String,
    @SerializedName("end_date")
    val endDate: String?,
    val notes: String?
)

data class ProductFeedback(
    val id: Int,
    val rating: Int,
    val comment: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("patient_id")
    val patientId: Int,
    @SerializedName("doctor_id")
    val doctorId: Int?,
    @SerializedName("product_id")
    val productId: Int
)

data class Patient(
    val id: Int,
    // ИСПРАВЛЕНО: сервер возвращает "birthDate", а не "date_of_birthday"
    val birthDate: String?,
    val gender: String,
    val notes: String,
    val user: User,
    val doctor: Doctor?
)

data class Doctor(
    val id: Int,
    val specialization: String,
    // ИСПРАВЛЕНО: сервер возвращает "expirienceYears" (с опечаткой), сохраняем как есть
    @SerializedName("expirienceYears")
    val experienceYears: Int,
    val bio: String,
    val user: User
)

data class Measurement(
    val id: Int,
    val patient: Patient,
    // ИСПРАВЛЕНО: сервер возвращает "skinType", а не "skin_type"
    val skinType: String,
    // ИСПРАВЛЕНО: сервер возвращает "moistureLevel", а не "moisture_level"
    val moistureLevel: Double,
    val temperature: Double,
    // ИСПРАВЛЕНО: сервер возвращает "takenAt", а не "taken_at"
    val takenAt: String,
    val comments: String
)

data class Recommendation(
    val id: Int,
    val patient: Patient,
    val doctor: Doctor,
    val product: Product?,
    val text: String,
    @SerializedName("created_at")
    val createdAt: String
)

data class SkinReactionUpdateRequest(
    val usedProductId: Int,
    val status: String
)



