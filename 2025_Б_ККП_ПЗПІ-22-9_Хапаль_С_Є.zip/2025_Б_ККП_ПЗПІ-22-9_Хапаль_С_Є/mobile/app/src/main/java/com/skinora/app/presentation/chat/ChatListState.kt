package com.skinora.app.presentation.chat

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.ChatRepository
import com.skinora.app.data.repository.AppointmentRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatListState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val chats: List<Chat> = emptyList(),
    val appointments: List<Appointment> = emptyList(),
    val isLoadingAppointments: Boolean = false,
    val patientId: Int? = null,
    val currentUserEmail: String = ""
)

@HiltViewModel
class ChatListViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val appointmentRepository: AppointmentRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatListState())
    val uiState: StateFlow<ChatListState> = _uiState.asStateFlow()

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userEmail = preferencesManager.getUserEmail().first()
                val userId = preferencesManager.getUserId().first()

                Log.d("ChatListViewModel", "Current user email: $userEmail")
                Log.d("ChatListViewModel", "Current user ID: $userId")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(
                    patientId = userId,
                    currentUserEmail = userEmail
                )

                Log.d("ChatListViewModel", "Set patientId: $userId for user: $userEmail")

                // Загружаем данные после получения ID пациента
                loadChatsAndAppointments()

            } catch (e: Exception) {
                Log.e("ChatListViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження користувача: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    private fun loadChatsAndAppointments() {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити дані: невірний ID користувача",
                isLoading = false
            )
            return
        }

        Log.d("ChatListViewModel", "Loading chats and appointments for patient: $patientId")

        loadChats()
        loadAppointments()
    }

    fun loadChats() {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити чати: невірний ID користувача"
            )
            return
        }

        Log.d("ChatListViewModel", "Loading chats for patient: $patientId")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = chatRepository.getChatsByPatient(patientId)) {
                is Resource.Success -> {
                    Log.d("ChatListViewModel", "Chats loaded: ${result.data?.size ?: 0} items")
                    val chats = result.data ?: emptyList()
                    _uiState.value = _uiState.value.copy(
                        chats = chats,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("ChatListViewModel", "Error loading chats: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        chats = emptyList(),
                        isLoading = false,
                        error = "Помилка завантаження чатів: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun loadAppointments() {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити зустрічі: невірний ID користувача"
            )
            return
        }

        Log.d("ChatListViewModel", "Loading appointments for patient: $patientId")

        _uiState.value = _uiState.value.copy(isLoadingAppointments = true)

        viewModelScope.launch {
            when (val result = appointmentRepository.getAppointmentsByPatient(patientId)) {
                is Resource.Success -> {
                    Log.d("ChatListViewModel", "Appointments loaded: ${result.data?.size ?: 0} items")
                    val appointments = result.data ?: emptyList()

                    // Фильтруем только будущие встречи со статусом PENDING или CONFIRMED
                    val upcomingAppointments = appointments.filter { appointment ->
                        val status = appointment.status.uppercase()
                        status == "PENDING" || status == "CONFIRMED"
                    }

                    _uiState.value = _uiState.value.copy(
                        appointments = upcomingAppointments,
                        isLoadingAppointments = false
                    )
                }
                is Resource.Error -> {
                    Log.e("ChatListViewModel", "Error loading appointments: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        appointments = emptyList(),
                        isLoadingAppointments = false,
                        error = "Помилка завантаження зустрічей: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun refreshData() {
        loadChatsAndAppointments()
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    fun cancelAppointment(appointmentId: Int) {
        Log.d("ChatListViewModel", "Cancelling appointment: $appointmentId")

        viewModelScope.launch {
            when (val result = appointmentRepository.cancelAppointment(appointmentId)) {
                is Resource.Success -> {
                    Log.d("ChatListViewModel", "Appointment cancelled successfully")
                    // Перезагружаем встречи
                    loadAppointments()
                }
                is Resource.Error -> {
                    Log.e("ChatListViewModel", "Error cancelling appointment: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка скасування зустрічі: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }
}