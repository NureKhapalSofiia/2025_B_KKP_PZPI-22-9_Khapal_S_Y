package com.skinora.app.data.api

import com.skinora.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface ProductApi {

    @GET("products")
    suspend fun getAllProducts(): Response<List<Product>>

    @GET("products/{id}")
    suspend fun getProductById(@Path("id") productId: Int): Response<Product>

    @GET("products/search")
    suspend fun searchProducts(@Query("name") name: String): Response<List<Product>>

    @GET("favorites/patient/{patientId}")
    suspend fun getFavoriteProducts(@Path("patientId") patientId: Int): Response<List<FavoriteProduct>>

    @POST("favorites/add")
    suspend fun addToFavorites(
        @Query("patientId") patientId: Int,
        @Query("productId") productId: Int
    ): Response<Unit>

    @DELETE("favorites/remove")
    suspend fun removeFromFavorites(
        @Query("patientId") patientId: Int,
        @Query("productId") productId: Int
    ): Response<Unit>

    // МЕТОДЫ ДЛЯ USING PRODUCTS

    // Получить продукты, которые сейчас использует пациент
    @GET("using-products/patient/{patientId}")
    suspend fun getUsingProducts(@Path("patientId") patientId: Int): Response<List<UsingProduct>>

    // Добавить продукт в "Используется"
    @POST("using-products/add")
    suspend fun addUsingProduct(
        @Query("patientId") patientId: Int,
        @Query("productId") productId: Int
    ): Response<UsingProduct>

    // ИСПРАВЛЕНО: Завершить использование продукта - теперь возвращает UsedProduct
    @PATCH("using-products/stop")
    suspend fun stopUsingProduct(
        @Query("patientId") patientId: Int,
        @Query("productId") productId: Int
    ): Response<UsedProduct>  // ← ИЗМЕНЕНО: теперь возвращает UsedProduct

    // МЕТОДЫ ДЛЯ USED PRODUCTS

    @GET("used-products/patient/{patientId}")
    suspend fun getUsedProducts(@Path("patientId") patientId: Int): Response<List<UsedProduct>>

    @PUT("used-products/status")
    suspend fun updateSkinReactionStatus(@Body request: SkinReactionUpdateRequest): Response<Unit>



    @GET("product-feedback/{productId}/patient/{patientId}")
    suspend fun getFeedbackForProduct(
        @Path("productId") productId: Int,
        @Path("patientId") patientId: Int
    ): Response<ProductFeedback>

    @GET("prescribed-products/{productId}/patient/{patientId}")
    suspend fun getPrescribedProductDetails(
        @Path("productId") productId: Int,
        @Path("patientId") patientId: Int
    ): Response<PrescribedProduct>
}