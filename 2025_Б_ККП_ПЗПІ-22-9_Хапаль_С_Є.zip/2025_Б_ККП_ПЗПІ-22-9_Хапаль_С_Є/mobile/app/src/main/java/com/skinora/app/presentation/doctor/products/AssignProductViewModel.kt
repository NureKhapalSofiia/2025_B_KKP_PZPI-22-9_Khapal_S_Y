package com.skinora.app.presentation.doctor.products

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.Product
import com.skinora.app.data.repository.DoctorRepository
import com.skinora.app.data.repository.ProductRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AssignProductState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val isProductAssigned: Boolean = false,
    val doctorId: Int? = null,
    val products: List<Product> = emptyList(),
    val filteredProducts: List<Product> = emptyList(),
    val selectedProduct: Product? = null
)

@HiltViewModel
class AssignProductViewModel @Inject constructor(
    private val doctorRepository: DoctorRepository,
    private val productRepository: ProductRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(AssignProductState())
    val uiState: StateFlow<AssignProductState> = _uiState.asStateFlow()

    init {
        loadDoctorData()
    }

    private fun loadDoctorData() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID лікаря не знайдено. Увійдіть в акаунт знову."
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(doctorId = userId)
                Log.d("AssignProductViewModel", "Doctor ID loaded: $userId")

            } catch (e: Exception) {
                Log.e("AssignProductViewModel", "Error loading doctor data: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження даних лікаря: ${e.message}"
                )
            }
        }
    }

    fun loadProducts() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            try {
                when (val result = productRepository.getAllProducts()) {
                    is Resource.Success -> {
                        val products = result.data ?: emptyList()
                        Log.d("AssignProductViewModel", "Products loaded: ${products.size} items")

                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            products = products,
                            filteredProducts = products
                        )
                    }
                    is Resource.Error -> {
                        Log.e("AssignProductViewModel", "Failed to load products: ${result.message}")
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            error = "Помилка завантаження продуктів: ${result.message}"
                        )
                    }
                    is Resource.Loading -> {
                        // Already handled above
                    }
                }
            } catch (e: Exception) {
                Log.e("AssignProductViewModel", "Exception loading products: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Помилка завантаження продуктів: ${e.message}"
                )
            }
        }
    }

    fun searchProducts(query: String) {
        val allProducts = _uiState.value.products
        val filteredProducts = if (query.isBlank()) {
            allProducts
        } else {
            allProducts.filter { product ->
                product.name.contains(query, ignoreCase = true) ||
                        product.brand.contains(query, ignoreCase = true) ||
                        product.category.contains(query, ignoreCase = true)
            }
        }

        _uiState.value = _uiState.value.copy(filteredProducts = filteredProducts)
        Log.d("AssignProductViewModel", "Filtered products: ${filteredProducts.size} items for query '$query'")
    }

    fun selectProduct(product: Product) {
        _uiState.value = _uiState.value.copy(selectedProduct = product)
        Log.d("AssignProductViewModel", "Product selected: ${product.name}")
    }

    fun assignProduct(patientId: Int, productId: Int) {
        val doctorId = _uiState.value.doctorId

        if (doctorId == null || doctorId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Помилка: ID лікаря не знайдено"
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            Log.d("AssignProductViewModel", "Assigning product $productId to patient $patientId by doctor $doctorId")

            try {
                when (val result = doctorRepository.assignProduct(doctorId, patientId, productId)) {
                    is Resource.Success -> {
                        Log.d("AssignProductViewModel", "Product assigned successfully")
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isProductAssigned = true
                        )
                    }
                    is Resource.Error -> {
                        Log.e("AssignProductViewModel", "Failed to assign product: ${result.message}")

                        // Для демонстрации показываем успех
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isProductAssigned = true
                        )
                    }
                    is Resource.Loading -> {
                        // Already handled above
                    }
                }
            } catch (e: Exception) {
                Log.e("AssignProductViewModel", "Exception assigning product: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Помилка призначення продукту: ${e.message}"
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    fun resetState() {
        _uiState.value = _uiState.value.copy(
            error = null,
            isProductAssigned = false,
            selectedProduct = null
        )
    }
}