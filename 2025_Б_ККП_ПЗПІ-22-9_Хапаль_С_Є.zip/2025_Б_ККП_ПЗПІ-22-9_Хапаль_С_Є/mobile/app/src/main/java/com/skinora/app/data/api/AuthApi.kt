package com.skinora.app.data.api

import com.skinora.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface AuthApi {

    @POST("auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<UserResponse>

    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): Response<AuthResponse>  // Используем AuthResponse

    @GET("auth/role")
    suspend fun getUserRole(@Query("email") email: String): Response<RoleResponse>
}