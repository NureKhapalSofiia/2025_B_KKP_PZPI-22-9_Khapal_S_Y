package com.skinora.app.presentation.profile

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.R
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import com.skinora.app.ui.components.TopPurpleWaves

@Composable
fun EditProfileScreen(
    onBackClick: () -> Unit,
    onSaveSuccess: () -> Unit = {},
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Состояния полей формы
    var fullName by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    // Инициализация полей данными пациента
    LaunchedEffect(uiState.patient, uiState.user) {
        // Приоритет: данные пациента -> данные пользователя -> email
        val name = uiState.patient?.user?.fullName
            ?: uiState.user?.fullName
            ?: uiState.currentUserName

        fullName = name
        gender = uiState.patient?.gender ?: ""
        birthDate = uiState.patient?.birthDate ?: ""
        notes = uiState.patient?.notes ?: ""
    }

    // Обработка успешного сохранения
    LaunchedEffect(uiState.profileUpdateSuccess) {
        if (uiState.profileUpdateSuccess) {
            // Обновляем данные профиля
            viewModel.refreshProfile()
            onSaveSuccess()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White
                    )
                )
            )
    ) {
        // Декоративные волны сверху
        TopPurpleWaves(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .align(Alignment.TopCenter),
            backWaveColor = PurpleGradientStart.copy(alpha = 0.4f),
            frontWaveColor = PurpleGradientEnd.copy(alpha = 0.3f)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            Spacer(modifier = Modifier.height(80.dp))

            // Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick) {
                        Text("←", fontSize = 24.sp, color = PurpleGradientStart)
                    }

                    Text(
                        text = "Редагувати профіль",
                        fontSize = 20.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D1B69),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Форма редактирования
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Аватар (пока не редактируемый)
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(PurpleGradientStart.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.user),
                            contentDescription = "User avatar",
                            modifier = Modifier.size(48.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Поле полного имени
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = {
                            Text(
                                "Повне ім'я",
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Поле гендера (выпадающий список)
                    GenderSelector(
                        selectedGender = gender,
                        onGenderSelected = { gender = it }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Поле даты рождения
                    OutlinedTextField(
                        value = birthDate,
                        onValueChange = { birthDate = it },
                        label = {
                            Text(
                                "Дата народження (YYYY-MM-DD)",
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        ),
                        placeholder = {
                            Text(
                                "1995-03-15",
                                fontFamily = KleeOneFamily,
                                color = Color(0xFF9CA3AF)
                            )
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Поле заметок
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = {
                            Text(
                                "Додаткові нотатки",
                                fontFamily = KleeOneFamily
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        ),
                        maxLines = 3,
                        placeholder = {
                            Text(
                                "Проблеми зі шкірою, алергії тощо",
                                fontFamily = KleeOneFamily,
                                color = Color(0xFF9CA3AF)
                            )
                        }
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Кнопки
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Кнопка отмены
                        OutlinedButton(
                            onClick = onBackClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFF6B7280)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Скасувати",
                                fontFamily = KleeOneFamily,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Кнопка сохранения
                        Button(
                            onClick = {
                                if (fullName.isNotBlank()) {
                                    viewModel.updateProfile(
                                        newName = fullName,
                                        newGender = gender,
                                        newBirthDate = birthDate,
                                        newNotes = notes
                                    )
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            enabled = !uiState.isUpdatingProfile && fullName.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PurpleGradientStart
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (uiState.isUpdatingProfile) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = "Зберегти",
                                    fontFamily = KleeOneFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(100.dp)) // Отступ для навигации
        }

        // Показ ошибок
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                        fontFamily = KleeOneFamily
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK", fontFamily = KleeOneFamily)
                    }
                }
            }
        }
    }
}

@Composable
private fun GenderSelector(
    selectedGender: String,
    onGenderSelected: (String) -> Unit
) {
    Column {
        Text(
            text = "Стать",
            fontFamily = KleeOneFamily,
            fontSize = 14.sp,
            color = Color(0xFF6B7280),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FilterChip(
                onClick = { onGenderSelected("Чоловіча") },
                label = {
                    Text(
                        "Чоловіча",
                        fontFamily = KleeOneFamily
                    )
                },
                selected = selectedGender == "Чоловіча",
                modifier = Modifier.weight(1f),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PurpleGradientStart.copy(alpha = 0.2f),
                    selectedLabelColor = PurpleGradientStart
                )
            )

            FilterChip(
                onClick = { onGenderSelected("Жіноча") },
                label = {
                    Text(
                        "Жіноча",
                        fontFamily = KleeOneFamily
                    )
                },
                selected = selectedGender == "Жіноча",
                modifier = Modifier.weight(1f),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PurpleGradientStart.copy(alpha = 0.2f),
                    selectedLabelColor = PurpleGradientStart
                )
            )

            FilterChip(
                onClick = { onGenderSelected("Інше") },
                label = {
                    Text(
                        "Інше",
                        fontFamily = KleeOneFamily
                    )
                },
                selected = selectedGender == "Інше",
                modifier = Modifier.weight(1f),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PurpleGradientStart.copy(alpha = 0.2f),
                    selectedLabelColor = PurpleGradientStart
                )
            )
        }
    }
}