package com.skinora.app.presentation.main

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.skinora.app.presentation.chat.ChatScreen
import com.skinora.app.presentation.chat.ChatDetailScreen
import com.skinora.app.presentation.chat.DoctorSearchScreen
import com.skinora.app.presentation.home.HomeScreen
import com.skinora.app.presentation.profile.ProfileScreen
import com.skinora.app.presentation.profile.EditProfileScreen
import com.skinora.app.presentation.profile.FavoriteProductsScreen
import com.skinora.app.presentation.usedproducts.UsedProductsScreen
import com.skinora.app.presentation.usingproducts.UsingProductsScreen  // ДОБАВЛЕНО
import com.skinora.app.presentation.recommendations.RecommendationsScreen
import com.skinora.app.data.model.Chat
import com.skinora.app.data.model.MeasurementDto
import com.skinora.app.presentation.analysis.AnalysisBottomSheet
import com.skinora.app.ui.components.BottomNavItem
import com.skinora.app.ui.components.SkinoraBottomNavigation
import com.skinora.app.presentation.analysis.PatientAnalysisScreen


// Navigation routes
object Routes {
    const val HOME = "home"
    const val CHAT = "chat"
    const val PROFILE = "profile"
    const val EDIT_PROFILE = "edit_profile"
    const val FAVORITE_PRODUCTS = "favorite_products"
    const val USED_PRODUCTS = "used_products"
    const val USING_PRODUCTS = "using_products"  // ОБНОВЛЕНО
    const val ANALYSIS = "analysis"
    const val ANALYSIS_WITH_ID = "analysis/{patientId}"
    const val RECOMMENDATIONS = "recommendations"
    const val CHAT_DETAIL = "chat_detail"
    const val DOCTOR_SEARCH = "doctor_search"
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun MainScreen(
    onLogout: () -> Unit
) {
    val navController = rememberNavController()
    var currentRoute by remember { mutableStateOf(BottomNavItem.Home.route) }

    Scaffold(
        bottomBar = {
            SkinoraBottomNavigation(
                currentRoute = currentRoute,
                onItemClick = { route ->
                    currentRoute = route
                    navController.navigate(route) {
                        popUpTo(BottomNavItem.Home.route) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = BottomNavItem.Home.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(BottomNavItem.Home.route) {
                HomeScreen(
                    onUsingProductsClick = {
                        navController.navigate(Routes.USING_PRODUCTS)
                    },
                    onUsedProductsClick = {
                        navController.navigate(Routes.USED_PRODUCTS)
                    },
                    onAnalysisClick = {
                        navController.navigate("analysis/707")
                    },
                    onRecommendationsClick = {
                        navController.navigate(Routes.RECOMMENDATIONS)
                    },
                    onFavoriteClick = {
                        navController.navigate(Routes.FAVORITE_PRODUCTS)
                    }
                )
            }

            composable(BottomNavItem.Chat.route) {
                ChatScreen(
                    onChatClick = { chat ->
                        // Передаем ID чата через аргументы
                        navController.navigate("${Routes.CHAT_DETAIL}/${chat.id}")
                    },
                    onFindDoctorClick = {
                        navController.navigate(Routes.DOCTOR_SEARCH)
                    }
                )
            }

            composable(BottomNavItem.Profile.route) {
                ProfileScreen(
                    onLogout = onLogout,
                    onEditProfile = {
                        navController.navigate(Routes.EDIT_PROFILE)
                    },
                    onFavoriteProducts = {
                        navController.navigate(Routes.FAVORITE_PRODUCTS)
                    }
                )
            }

            // НОВЫЕ ЭКРАНЫ ПРОФИЛЯ
            composable(Routes.EDIT_PROFILE) {
                EditProfileScreen(
                    onBackClick = {
                        navController.popBackStack()
                    },
                    onSaveSuccess = {
                        navController.popBackStack()
                    }
                )
            }

            composable(Routes.FAVORITE_PRODUCTS) {
                FavoriteProductsScreen(
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }

            // USING PRODUCTS SCREEN - ОБНОВЛЕНО
            composable(Routes.USING_PRODUCTS) {
                UsingProductsScreen(
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }

            // Used Products Screen
            composable(Routes.USED_PRODUCTS) {
                UsedProductsScreen(
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }

            // Recommendations Screen
            composable(Routes.RECOMMENDATIONS) {
                RecommendationsScreen(
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }

            // Doctor Search Screen
            composable(Routes.DOCTOR_SEARCH) {
                DoctorSearchScreen(
                    onBackClick = {
                        navController.popBackStack()
                    },
                    onChatCreated = { chat ->
                        // После создания чата переходим к чату и удаляем поиск из стека
                        navController.navigate("${Routes.CHAT_DETAIL}/${chat.id}") {
                            popUpTo(Routes.DOCTOR_SEARCH) { inclusive = true }
                        }
                    }
                )
            }

            // Chat Detail Screen with parameter
            composable(
                route = "${Routes.CHAT_DETAIL}/{chatId}",
                arguments = listOf(navArgument("chatId") { type = NavType.IntType })
            ) { backStackEntry ->
                val chatId = backStackEntry.arguments?.getInt("chatId") ?: return@composable

                // Создаем dummy chat для демонстрации
                val dummyChat = createDummyChatById(chatId)

                ChatDetailScreen(
                    chat = dummyChat,
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }

            // Analysis Placeholder Screen
            composable(
                route = Routes.ANALYSIS_WITH_ID,
                arguments = listOf(navArgument("patientId") { type = NavType.IntType })
            ) { backStackEntry ->
                val patientId = backStackEntry.arguments?.getInt("patientId") ?: return@composable

                // Стан для панелі
                var selectedMeasurement by remember { mutableStateOf<MeasurementDto?>(null) }
                val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

                PatientAnalysisScreen(
                    onBackClick = {
                        navController.popBackStack()
                    },
                    patientId = patientId,
                    onAnalysisClick = { measurement ->
                        selectedMeasurement = measurement
                    }
                )

                if (selectedMeasurement != null) {
                    ModalBottomSheet(
                        onDismissRequest = { selectedMeasurement = null },
                        sheetState = sheetState,
                        containerColor = Color.Transparent
                    ) {
                        AnalysisBottomSheet(measurement = selectedMeasurement!!)
                    }
                }
            }


        }
    }
}

@Composable
private fun PlaceholderScreen(
    title: String,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Text("←", fontSize = 24.sp)
            }
            Text(
                text = title,
                fontSize = 20.sp,
                modifier = Modifier.weight(1f)
            )
        }

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Екран '$title' ще розробляється",
                fontSize = 16.sp
            )
        }
    }
}

// Helper functions для создания dummy данных
private fun createDummyPatient(): com.skinora.app.data.model.Patient {
    return com.skinora.app.data.model.Patient(
        id = 1,
        birthDate = "1995-03-15",
        gender = "Чоловіча",
        notes = "Проблеми з сухістю шкіри та подразненням",
        user = com.skinora.app.data.model.User(
            id = 1,
            email = "john@example.com",
            passwordHash = "",
            fullName = "Іван Петренко",
            avatarUrl = null,
            role = com.skinora.app.data.model.Role(3, "patient"),
            isActive = true,
            createdAt = "2024-12-01T00:00:00",
            updatedAt = "2024-12-01T00:00:00"
        ),
        doctor = null
    )
}

private fun createDummyDoctor(doctorId: Int = 1): com.skinora.app.data.model.Doctor {
    val doctorNames = mapOf(
        1 to "Др. Іванова Марія",
        2 to "Др. Петренко Олексій",
        3 to "Др. Коваленко Анна"
    )

    val specializations = mapOf(
        1 to "Дерматолог",
        2 to "Косметолог",
        3 to "Трихолог"
    )

    return com.skinora.app.data.model.Doctor(
        id = doctorId,
        specialization = specializations[doctorId] ?: "Дерматолог",
        experienceYears = 8,
        bio = "Досвідчений ${specializations[doctorId] ?: "лікар"}",
        user = com.skinora.app.data.model.User(
            id = doctorId + 5,
            email = "doctor$doctorId@clinic.com",
            passwordHash = "",
            fullName = doctorNames[doctorId] ?: "Др. Лікар",
            avatarUrl = null,
            role = com.skinora.app.data.model.Role(2, "doctor"),
            isActive = true,
            createdAt = "2024-12-01T00:00:00",
            updatedAt = "2024-12-01T00:00:00"
        )
    )
}

private fun createDummyChatById(chatId: Int): Chat {
    return Chat(
        id = chatId,
        participant1 = createDummyPatient(),
        participant2 = createDummyDoctor(chatId)
    )
}