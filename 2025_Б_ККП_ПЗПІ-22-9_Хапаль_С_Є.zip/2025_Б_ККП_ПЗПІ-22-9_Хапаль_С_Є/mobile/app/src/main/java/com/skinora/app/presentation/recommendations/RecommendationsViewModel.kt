package com.skinora.app.presentation.recommendations

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.PatientRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.data.repository.ProductRepository
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RecommendationsState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val recommendations: List<Recommendation> = emptyList(),
    val selectedRecommendation: Recommendation? = null,
    val showRecommendationDetails: Boolean = false,
    val patientId: Int? = null
)

@HiltViewModel
class RecommendationsViewModel @Inject constructor(
    private val patientRepository: PatientRepository,
    private val preferencesManager: PreferencesManager,
    private val productRepository: ProductRepository

) : ViewModel() {

    private val _uiState = MutableStateFlow(RecommendationsState())
    val uiState: StateFlow<RecommendationsState> = _uiState.asStateFlow()
    private var usingProducts: List<UsingProduct> = emptyList()


    init {
        loadCurrentUser()
    }

    private fun loadUsingProducts() {
        val patientId = _uiState.value.patientId ?: return

        viewModelScope.launch {
            when (val result = productRepository.getUsingProducts(patientId)) {
                is Resource.Success -> {
                    usingProducts = result.data ?: emptyList()
                }
                else -> {
                    usingProducts = emptyList()
                }
            }
        }
    }


    fun markAsUsed(recommendation: Recommendation) {
        val patientId = _uiState.value.patientId ?: return
        val productId = recommendation.product?.id ?: return


        // 🔍 Перевірка: чи продукт уже у використанні
        val alreadyUsed = usingProducts.any { it.product.id == productId }
        if (alreadyUsed) {
            _uiState.update {
                it.copy(error = "Цей продукт вже використовується")
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            val result = productRepository.addUsingProduct(patientId, productId)

            _uiState.update {
                it.copy(
                    isLoading = false,
                    error = if (result is Resource.Error) result.message else null
                )
            }

            if (result is Resource.Success) {
                loadUsingProducts()
                refreshData()
            }
        }
    }



    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()
                val userEmail = preferencesManager.getUserEmail().first()

                Log.d("RecommendationsViewModel", "Current user ID: $userId, email: $userEmail")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(patientId = userId)

                // Загружаем рекомендации после получения ID пациента
                loadRecommendations()
                loadUsingProducts()
            } catch (e: Exception) {
                Log.e("RecommendationsViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження користувача: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    fun loadRecommendations() {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити рекомендації: невірний ID користувача"
            )
            return
        }

        Log.d("RecommendationsViewModel", "Loading recommendations for patient: $patientId")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = patientRepository.getPatientRecommendations(patientId)) {
                is Resource.Success -> {
                    Log.d("RecommendationsViewModel", "Recommendations loaded: ${result.data?.size ?: 0} items")
                    val recommendations = result.data ?: emptyList()
                    _uiState.value = _uiState.value.copy(
                        recommendations = recommendations,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("RecommendationsViewModel", "Error loading recommendations: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        recommendations = emptyList(),
                        isLoading = false,
                        error = "Помилка завантаження рекомендацій: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun showRecommendationDetails(recommendation: Recommendation) {
        Log.d("RecommendationsViewModel", "Showing details for recommendation: ${recommendation.id}")
        _uiState.value = _uiState.value.copy(
            selectedRecommendation = recommendation,
            showRecommendationDetails = true
        )
    }

    fun hideRecommendationDetails() {
        _uiState.value = _uiState.value.copy(
            selectedRecommendation = null,
            showRecommendationDetails = false
        )
    }

    fun refreshData() {
        loadRecommendations()
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}