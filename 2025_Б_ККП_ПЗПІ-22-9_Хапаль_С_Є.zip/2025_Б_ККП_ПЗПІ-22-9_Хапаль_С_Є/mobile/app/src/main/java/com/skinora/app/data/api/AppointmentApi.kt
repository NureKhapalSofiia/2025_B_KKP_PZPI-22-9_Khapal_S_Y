package com.skinora.app.data.api

import com.skinora.app.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface AppointmentApi {

    @GET("appointments/patient/{patientId}")
    suspend fun getAppointmentsByPatient(@Path("patientId") patientId: Int): Response<List<Appointment>>

    @GET("appointments/doctor/{doctorId}")
    suspend fun getAppointmentsByDoctor(@Path("doctorId") doctorId: Int): Response<List<Appointment>>

    @POST("appointments")
    suspend fun createAppointment(@Body appointment: CreateAppointmentRequest): Response<Appointment>

    @PATCH("appointments/{appointmentId}/cancel")
    suspend fun cancelAppointment(@Path("appointmentId") appointmentId: Int): Response<Unit>

    @PATCH("appointments/{appointmentId}/confirm")
    suspend fun confirmAppointment(@Path("appointmentId") appointmentId: Int): Response<Unit>
}