package com.skinora.app.presentation.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.data.model.MeasurementDto
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.PurpleGradientStart


@Composable
fun PatientAnalysisScreen(
    onBackClick: () -> Unit = {},
    patientId: Int,
    viewModel: AnalysisViewModel = hiltViewModel(),
    onAnalysisClick: (MeasurementDto) -> Unit
) {
    val measurements by viewModel.measurements.collectAsStateWithLifecycle()

    LaunchedEffect(patientId) {
        viewModel.loadMeasurements(patientId)
    }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Text("←", fontSize = 24.sp, color = PurpleGradientStart)
                }

                Text(
                    text = "Усі аналізи",
                    fontSize = 20.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Black,
                    modifier = Modifier.weight(1f)
                )
                
            }
        }

    Column(
        modifier = Modifier.fillMaxSize()
        .background(Brush.verticalGradient(
        colors = listOf(Color(0xFFE4EDFD), Color.White),
        startY = 0f,
        endY = Float.POSITIVE_INFINITY
    ))) {

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            if (measurements.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 100.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        EmptyFavoritesCard()
                    }
                }
            } else {
                items(measurements) { measurement ->
                    AnalysisCard(
                        date = measurement.takenAt.substringBefore("T"),
                        onClick = { onAnalysisClick(measurement) }
                    )
                }
            }
        }

    }
}}

@Composable
private fun EmptyFavoritesCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = PurpleGradientStart.copy(alpha = 0.05f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Немає минулих аналізів",
                fontSize = 18.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color.Black
            )

            Text(
                text = "Дочекайтесь поки лікар додасть аналізи",
                fontSize = 14.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6B7280),
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
