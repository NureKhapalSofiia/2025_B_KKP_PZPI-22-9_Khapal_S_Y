package com.skinora.app.presentation.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.repository.AuthRepository
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn

data class AuthState(
    val isLoading: Boolean = false,
    val isLoggedIn: Boolean = false,
    val error: String? = null,
    val userEmail: String = "",
    val userId: Int = 0,
    val userRole: String = "", // ДОБАВЛЕНО: роль пользователя
    val isDoctorRole: Boolean = false // ДОБАВЛЕНО: флаг для проверки роли доктора
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _authState = MutableStateFlow(AuthState())
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    init {
        checkLoginStatus()
    }

    private fun checkLoginStatus() {
        viewModelScope.launch {
            try {
                val isLoggedIn = authRepository.isLoggedIn()

                if (isLoggedIn) {
                    // Получаем данные пользователя
                    authRepository.getUserEmail().collect { email ->
                        val userId = authRepository.getCurrentUserId()

                        // ДОБАВЛЕНО: Получаем роль пользователя
                        when (val roleResult = authRepository.getUserRole(email)) {
                            is Resource.Success -> {
                                val userRole = roleResult.data?.role ?: ""
                                val isDoctorRole = userRole.equals("doctor", ignoreCase = true)

                                _authState.value = _authState.value.copy(
                                    isLoggedIn = true,
                                    userEmail = email,
                                    userId = userId,
                                    userRole = userRole,
                                    isDoctorRole = isDoctorRole
                                )
                            }
                            is Resource.Error -> {
                                _authState.value = _authState.value.copy(
                                    isLoggedIn = true,
                                    userEmail = email,
                                    userId = userId,
                                    userRole = "patient", // По умолчанию пациент
                                    isDoctorRole = false
                                )
                            }
                            is Resource.Loading -> {
                                // Ожидаем завершения загрузки роли
                            }
                        }
                    }
                } else {
                    _authState.value = _authState.value.copy(isLoggedIn = false)
                }
            } catch (e: Exception) {
                _authState.value = _authState.value.copy(
                    isLoggedIn = false,
                    error = "Помилка перевірки авторизації: ${e.message}"
                )
            }
        }
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, error = null)

            when (val result = authRepository.login(email, password)) {
                is Resource.Success -> {
                    val userId = authRepository.getCurrentUserId()

                    // ДОБАВЛЕНО: Получаем роль пользователя из ответа
                    val userRole = result.data?.user?.role?.name ?: "patient"
                    val isDoctorRole = userRole.equals("doctor", ignoreCase = true)

                    _authState.value = _authState.value.copy(
                        isLoading = false,
                        isLoggedIn = true,
                        userEmail = email,
                        userId = userId,
                        userRole = userRole,
                        isDoctorRole = isDoctorRole
                    )
                }
                is Resource.Error -> {
                    _authState.value = _authState.value.copy(
                        isLoading = false,
                        error = result.message
                    )
                }
                is Resource.Loading -> {
                    // Already handled above
                }
            }
        }
    }

    fun register(name: String, email: String, password: String, role: String = "patient") {
        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, error = null)

            when (val result = authRepository.register(name, email, password, role)) {
                is Resource.Success -> {
                    // После успешной регистрации автоматически логинимся
                    login(email, password)
                }
                is Resource.Error -> {
                    _authState.value = _authState.value.copy(
                        isLoading = false,
                        error = result.message
                    )
                }
                is Resource.Loading -> {
                    // Already handled above
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            try {
                authRepository.logout()
                _authState.value = AuthState() // Сбрасываем все состояние
            } catch (e: Exception) {
                _authState.value = _authState.value.copy(
                    error = "Помилка при виході: ${e.message}"
                )
            }
        }
    }

    fun clearError() {
        _authState.value = _authState.value.copy(error = null)
    }
}