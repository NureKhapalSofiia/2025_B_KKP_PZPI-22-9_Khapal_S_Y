package com.skinora.app.data.repository

import com.skinora.app.data.api.ChatApi
import com.skinora.app.data.api.DoctorApi
import com.skinora.app.data.model.*
import com.skinora.app.utils.Resource
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val chatApi: ChatApi
) {

    suspend fun getChatsByPatient(patientId: Int): Resource<List<Chat>> {
        return try {
            val response = chatApi.getChatsByPatient(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get chats: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getChatByPatientAndDoctor(patientId: Int, doctorId: Int): Resource<Chat> {
        return try {
            val response = chatApi.getChatByPatientAndDoctor(patientId, doctorId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Chat not found")
            } else {
                Resource.Error("Failed to get chat: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // НОВЫЙ МЕТОД для создания чата
    suspend fun createChat(patientId: Int, doctorId: Int): Resource<Chat> {
        return try {
            val response = chatApi.createChat(patientId, doctorId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Failed to create chat")
            } else {
                Resource.Error("Failed to create chat: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // НОВЫЙ МЕТОД для получения или создания чата
    suspend fun getOrCreateChat(patientId: Int, doctorId: Int): Resource<Chat> {
        // Сначала пытаемся найти существующий чат
        when (val existingChatResult = getChatByPatientAndDoctor(patientId, doctorId)) {
            is Resource.Success -> {
                // Чат уже существует
                return existingChatResult
            }
            is Resource.Error -> {
                // Чат не найден, создаем новый
                return createChat(patientId, doctorId)
            }
            is Resource.Loading -> {
                return Resource.Loading()
            }
        }
    }

    suspend fun getMessagesByChat(chatId: Int): Resource<List<Message>> {
        return try {
            val response = chatApi.getMessagesByChat(chatId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get messages: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun sendMessage(chatId: Int, message: String, senderId: Int): Resource<Message> {
        return try {
            val request = SendMessageRequest(message, senderId)
            val response = chatApi.sendMessage(chatId, request)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Failed to send message")
            } else {
                Resource.Error("Failed to send message: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }
}