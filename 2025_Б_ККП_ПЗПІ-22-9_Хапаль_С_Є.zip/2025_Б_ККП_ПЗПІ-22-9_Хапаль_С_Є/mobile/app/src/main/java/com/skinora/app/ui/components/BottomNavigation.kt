package com.skinora.app.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.skinora.app.R
import com.skinora.app.presentation.welcome.PurpleGradientStart
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.skinora.app.presentation.welcome.PurpleGradientStart

sealed class BottomNavItem(
    val route: String,
    val icon: Int,
    val title: String
) {
    object Home : BottomNavItem("home", R.drawable.home, "Головна")
    object Chat : BottomNavItem("chat", R.drawable.message, "Чати")
    object Profile : BottomNavItem("profile", R.drawable.user, "Профіль")
}

@Composable
fun SkinoraBottomNavigation(
    currentRoute: String,
    onItemClick: (String) -> Unit
) {
    val items = listOf(
        BottomNavItem.Home,
        BottomNavItem.Chat,
        BottomNavItem.Profile
    )

    var waveOffsetX by remember { mutableStateOf(0f) }
    val animatedOffset by animateDpAsState(targetValue = waveOffsetX.dp, label = "wave")

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .background(Color(0xFFD3CBFF))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val itemWidth = width / items.size
            val centerX = animatedOffset.toPx() + itemWidth / 2

            val waveWidth = itemWidth * 1.5f
            val waveHeight = height * 1.3f

            val path = Path().apply {
                moveTo(0f, height)
                lineTo(centerX - waveWidth / 2f, 0f)
                cubicTo(
                    centerX - waveWidth / 4f, height,
                    centerX - waveWidth / 4f, height - waveHeight,
                    centerX, height - waveHeight
                )
                cubicTo(
                    centerX + waveWidth / 4f, height - waveHeight,
                    centerX + waveWidth / 4f, height,
                    centerX + waveWidth / 2f, height
                )
                lineTo(width, 0f)
                lineTo(width, height)
                lineTo(0f, height)
                close()
            }

            drawPath(path = path, color = Color(0xFFD3CBFF), style = Fill)
        }

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { index, item ->
                val isSelected = item.route == currentRoute

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            waveOffsetX = index * (140f)
                            onItemClick(item.route)
                        }
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = item.icon),
                            contentDescription = item.route,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}


