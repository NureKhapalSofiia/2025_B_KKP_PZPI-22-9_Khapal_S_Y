package com.skinora.app.ui.components

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.skinora.app.data.model.Measurement
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.dp

@Composable
fun SkinStatusCard(
    latestMeasurement: Measurement?,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 24.dp)
            .fillMaxWidth(),
                contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .width(360.dp)
                .height(250.dp)
                .padding(vertical = 5.dp)
               , // достатньо, щоб вмістити хвилю
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Хвиля на задньому фоні
                Canvas(
                    modifier = Modifier
                        .padding(top = 40.dp)
                        .fillMaxWidth()
                        .height(140.dp)
                        .align(Alignment.BottomCenter)
                ) {
                    val wavePath = Path().apply {
                        moveTo(0f, size.height * 0.6f)

                        quadraticBezierTo(size.width * 0.08f, size.height * 0.45f, size.width * 0.15f, size.height * 0.6f)
                        quadraticBezierTo(size.width * 0.23f, size.height * 0.8f, size.width * 0.27f, size.height * 0.65f)
                        quadraticBezierTo(size.width * 0.27f, size.height * 0.65f, size.width * 0.30f, size.height * 0.50f)
                        quadraticBezierTo(size.width * 0.40f, size.height * 0.19f, size.width * 0.50f, size.height * 0.70f)
                        quadraticBezierTo(size.width * 0.53f, size.height * 0.9f, size.width * 0.58f, size.height * 0.8f)
                        quadraticBezierTo(size.width * 0.66f, size.height * 0.50f, size.width * 0.71f, size.height * 0.7f)
                        quadraticBezierTo(size.width * 0.75f, size.height * 0.9f, size.width * 0.86f, size.height * 0.65f)
                        quadraticBezierTo(size.width * 0.95f, size.height * 0.4f, size.width * 1.0f, size.height * 0.6f)

                        lineTo(size.width, size.height)
                        lineTo(0f, size.height)
                        close()
                    }
                    val topPath = Path().apply {
                        moveTo(0f, size.height * 0.6f)
                        quadraticBezierTo(size.width * 0.08f, size.height * 0.45f, size.width * 0.15f, size.height * 0.6f)
                        quadraticBezierTo(size.width * 0.23f, size.height * 0.8f, size.width * 0.27f, size.height * 0.65f)
                        quadraticBezierTo(size.width * 0.27f, size.height * 0.65f, size.width * 0.30f, size.height * 0.50f)
                        quadraticBezierTo(size.width * 0.40f, size.height * 0.19f, size.width * 0.50f, size.height * 0.70f)
                        quadraticBezierTo(size.width * 0.53f, size.height * 0.9f, size.width * 0.58f, size.height * 0.8f)
                        quadraticBezierTo(size.width * 0.66f, size.height * 0.50f, size.width * 0.71f, size.height * 0.7f)
                        quadraticBezierTo(size.width * 0.75f, size.height * 0.9f, size.width * 0.86f, size.height * 0.65f)
                        quadraticBezierTo(size.width * 0.95f, size.height * 0.4f, size.width * 1.0f, size.height * 0.6f)
                    }

                    drawPath(
                        path = wavePath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFC5BAFF),
                                Color(0xFFDED8FD),
                                Color(0xFFDED8FD),
                                Color(0xFFEDEAFC),
                                Color(0xFFFBFBFB)
                            )
                        ),
                        style = Fill
                    )

                    drawPath(
                        path = topPath,
                        color = Color(0xFFC5BAFF),
                        style = Stroke(width = 2.dp.toPx())
                    )}

                // Основний контент
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.Start
                ) {
                    if (latestMeasurement != null) {
                        SkinStatusRow(
                            title = "Зволоженість:",
                            value = "${latestMeasurement.moistureLevel.toInt()}%",
                            color = Color(0xFFC5BAFF)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        SkinStatusRow(
                            title = "Проблеми:",
                            value = getSkinProblems(latestMeasurement),
                            color = Color(0xFFC5BAFF)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        SkinStatusRow(
                            title = "Тип шкіри:",
                            value = latestMeasurement.skinType ?: "Невідомо",
                            color = Color(0xFFC5BAFF)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        SkinStatusRow(
                            title = "Останнє оновлення:",
                            value = formatDate(latestMeasurement.takenAt),
                            color = Color(0xFFC5BAFF)
                        )

                        if (latestMeasurement.comments.isNotBlank()) {
                            Spacer(modifier = Modifier.height(12.dp))

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFFF3F0FF)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {

                            }
                        }
                    } else {
                        Text(
                            text = "Немає даних про стан шкіри",
                            fontSize = 16.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF6B7280)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Пройдіть перший аналіз",
                            fontSize = 14.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.Normal,
                            color = Color(0xFF9CA3AF)
                        )
                    }
                }
            }
        }
    }
}



@Composable
private fun SkinStatusRow(
    title: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = title,
                fontSize = 14.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Normal,
                color = Color.Black
            )
        }

        Text(
            text = value,
            fontSize = 14.sp,
            fontFamily = KleeOneFamily,
            fontWeight = FontWeight.Normal,
            color = Color.Black)
    }
}

private fun getSkinProblems(measurement: Measurement): String {
    val problems = mutableListOf<String>()

    // Определяем проблемы на основе измерений
    when {
        measurement.moistureLevel < 25 -> problems.add("Сильна сухість")
        measurement.moistureLevel < 35 -> problems.add("Сухість")
    }

    // ИСПРАВЛЕНО: добавлена null-safety проверка
    val skinType = measurement.skinType
    if (skinType != null) {
        when (skinType.lowercase()) {
            "жирна" -> problems.add("Жирність")
            "суха" -> {
                if (!problems.contains("Сухість") && !problems.contains("Сильна сухість")) {
                    problems.add("Сухість")
                }
            }
            "чутлива" -> problems.add("Підвищена чутливість")
            "комбінована" -> problems.add("Змішаний тип")
            "зріла" -> problems.add("Ознаки старіння")
        }
    }

    // Если проблемы выявлены из комментариев
    val comments = measurement.comments.lowercase()
    if (comments.contains("акне") || comments.contains("прищі")) {
        problems.add("Акне")
    }
    if (comments.contains("подразнення") || comments.contains("запалення")) {
        problems.add("Подразнення")
    }
    if (comments.contains("пігментація") || comments.contains("плями")) {
        problems.add("Пігментація")
    }

    return if (problems.isNotEmpty()) {
        problems.take(2).joinToString(", ") // Показываем максимум 2 проблемы
    } else {
        "Не виявлено"
    }
}



private fun formatDate(dateString: String): String {
    return try {
        // Обрабатываем формат "2024-12-01T10:00:00" или "2024-12-01 10:00:00"
        val cleanDate = dateString.replace("T", " ").split(" ")[0]
        val parts = cleanDate.split("-")
        if (parts.size >= 3) {
            "${parts[2]}.${parts[1]}.${parts[0]}"
        } else {
            "Сьогодні"
        }
    } catch (e: Exception) {
        Log.e("SkinStatusCard", "Error formatting date: $dateString", e)
        "Невідомо"
    }
}