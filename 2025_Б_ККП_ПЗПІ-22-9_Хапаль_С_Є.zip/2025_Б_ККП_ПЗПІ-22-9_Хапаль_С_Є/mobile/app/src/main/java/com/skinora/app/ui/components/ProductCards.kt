package com.skinora.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.skinora.app.R
import com.skinora.app.data.model.UsingProduct
import com.skinora.app.data.model.UsedProduct
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.PurpleGradientStart
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily

@Composable
fun UsingProductsCard(
    products: List<UsingProduct>,
    onClick: () -> Unit = {}
) {
    val kleeOne = FontFamily(Font(R.font.klee_one_regular))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(
            topStart = 60.dp,
            topEnd = 20.dp,
            bottomEnd = 20.dp,
            bottomStart = 60.dp
        ),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Іконка продуктів
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.using),
                    contentDescription = "Using products",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(65.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о продуктах
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "У використанні",
                    fontFamily = kleeOne,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    letterSpacing = (-1.9).sp,
                    color = Color(0xFF2D1B69)
                )

                Text(
                    text = "Засоби, які ви зараз застосовуєте",
                    fontSize = 14.sp,
                    color = Color(0xFF6B7280),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun UsingProductCard(
    product: UsingProduct,
    onClick: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        ),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Иконка продукта
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.using),
                    contentDescription = "Using product",
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о продукте
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "У використанні",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69)
                )

                Text(
                    text = "Засоби які ви зараз застосовуєте",
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                // Показываем название продукта если есть данные
                if (product.id > 0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• ${product.product.name ?: "Невідомий продукт"}",
                        fontSize = 11.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Medium,
                        color = PurpleGradientStart,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun UsedProductCard(
    product: UsedProduct,
    onClick: () -> Unit = {}
) {
    val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(
            topStart = 60.dp,
            topEnd = 20.dp,
            bottomEnd = 20.dp,
            bottomStart = 60.dp
        ),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Иконка продукта
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.used),
                    contentDescription = "Used product",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(65.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о продукте
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "Використовувалися",
                    fontFamily = kleeOne,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    letterSpacing = (-1.9).sp,
                    color = Color(0xFF2D1B69)
                )

                Text(
                    text = "Раніше використані засоби",
                    fontSize = 14.sp,
                    color = Color(0xFF6B7280),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun AnalysisCard(
    onClick: () -> Unit = {}
) {
    val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(
            topStart = 60.dp,
            topEnd = 20.dp,
            bottomEnd = 20.dp,
            bottomStart = 60.dp
        ),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Иконка анализа
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.analysis),
                    contentDescription = "Analysis",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(65.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Информация об анализах
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "Усі аналізи",
                    fontFamily = kleeOne,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    letterSpacing = (-1.9).sp,
                    color = Color(0xFF2D1B69)
                )

                Text(
                    text = "Перелік усіх аналізів з відгуком лікаря",
                    fontSize = 14.sp,
                    color = Color(0xFF6B7280),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}



@Composable
fun RecommendationsCard(
    onClick: () -> Unit = {}
) {
    val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(
            topStart = 60.dp,
            topEnd = 20.dp,
            bottomEnd = 20.dp,
            bottomStart = 60.dp
        ),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Іконка продуктів
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.recommendation),
                    contentDescription = "Using products",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(65.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = "Рекомендації",
                fontFamily = kleeOne,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                letterSpacing = (-1.9).sp,
                color = Color(0xFF2D1B69)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Перелік усіх рекомендацій лікаря щодо засобів",
                fontSize = 14.sp,
                color = Color(0xFF6B7280),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}}

@Composable
fun FavoriteCard(
    onClick: () -> Unit = {}
) {
    val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(
            topStart = 60.dp,
            topEnd = 20.dp,
            bottomEnd = 20.dp,
            bottomStart = 60.dp
        ),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Іконка продуктів
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.favorite_icon),
                    contentDescription = "Using products",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(65.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "Улюблені",
                    fontFamily = kleeOne,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    letterSpacing = (-1.9).sp,
                    color = Color(0xFF2D1B69)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Перелік продуктів, що вам сподобалися",
                    fontSize = 14.sp,
                    color = Color(0xFF6B7280),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }}