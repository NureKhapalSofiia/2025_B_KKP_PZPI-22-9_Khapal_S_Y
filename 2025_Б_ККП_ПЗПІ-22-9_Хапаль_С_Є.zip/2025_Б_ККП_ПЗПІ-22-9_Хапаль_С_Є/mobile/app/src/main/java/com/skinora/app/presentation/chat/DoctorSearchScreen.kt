package com.skinora.app.presentation.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.data.model.Chat
import com.skinora.app.data.model.DoctorSearchResult
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart

@Composable
fun DoctorSearchScreen(
    onBackClick: () -> Unit = {},
    onChatCreated: (Chat) -> Unit = {},
    viewModel: DoctorSearchViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        LightPurple,
                        Color.White,
                        PurpleGradientEnd.copy(alpha = 0.1f)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBackClick) {
                            Text("←", fontSize = 24.sp, color = PurpleGradientStart)
                        }

                        Text(
                            text = "Пошук лікарів",
                            fontSize = 20.sp,
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF2D1B69),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Search field
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = { viewModel.updateSearchQuery(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        placeholder = {
                            Text(
                                text = "Введіть ім'я лікаря...",
                                fontFamily = KleeOneFamily,
                                color = Color(0xFF6B7280)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurpleGradientStart,
                            unfocusedBorderColor = Color(0xFFE5E7EB)
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            // Content
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PurpleGradientStart)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (uiState.doctors.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color.White
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (uiState.searchQuery.isBlank())
                                            "Введіть ім'я лікаря для пошуку"
                                        else "Лікарів не знайдено",
                                        fontSize = 16.sp,
                                        fontFamily = KleeOneFamily,
                                        fontWeight = FontWeight.Normal,
                                        color = Color(0xFF6B7280)
                                    )
                                }
                            }
                        }
                    } else {
                        items(uiState.doctors) { doctor ->
                            DoctorItemSimple(
                                doctor = doctor,
                                isCreatingChat = uiState.isCreatingChat,
                                onChatClick = {
                                    viewModel.createChatWithDoctor(doctor) { chat ->
                                        onChatCreated(chat)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // Error display
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}

@Composable
private fun DoctorItemSimple(
    doctor: DoctorSearchResult,
    isCreatingChat: Boolean,
    onChatClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isCreatingChat) {
                onChatClick()
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Doctor avatar
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(PurpleGradientStart.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "👨‍⚕️",
                    fontSize = 28.sp
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Doctor info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = doctor.user?.fullName ?: "Невідомий лікар",
                    fontSize = 16.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF2D1B69),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = doctor.specialization ?: "Спеціалізація невідома",
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Medium,
                    color = PurpleGradientStart,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "Досвід: ${doctor.experienceYears} років",
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280)
                )

                if (!doctor.bio.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = doctor.bio,
                        fontSize = 12.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF374151),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Action button или индикатор загрузки
            if (isCreatingChat) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = PurpleGradientStart,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = "Чат",
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.SemiBold,
                    color = PurpleGradientStart
                )
            }
        }
    }
}