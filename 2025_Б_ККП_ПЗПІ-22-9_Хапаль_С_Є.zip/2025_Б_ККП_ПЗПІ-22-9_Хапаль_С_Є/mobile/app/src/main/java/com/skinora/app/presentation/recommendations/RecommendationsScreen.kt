package com.skinora.app.presentation.recommendations

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.R
import com.skinora.app.data.model.Recommendation
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.BorderStroke


@Composable
fun RecommendationsScreen(
    onBackClick: () -> Unit = {},
    viewModel: RecommendationsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(
                colors = listOf(Color(0xFFE4EDFD), Color.White),
                startY = 0f,
                endY = Float.POSITIVE_INFINITY
            ))
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick) {
                        Text("←", fontSize = 24.sp, color = PurpleGradientStart)
                    }

                    Text(
                        text = "Рекомендації лікаря",
                        fontSize = 20.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Black,
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { viewModel.refreshData() }) {
                        Text("↻", fontSize = 20.sp, color = PurpleGradientStart)
                    }
                }
            }

            // Content
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PurpleGradientStart)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.recommendations) { recommendation ->
                        RecommendationItem(
                            recommendation = recommendation,
                            onClick = { viewModel.showRecommendationDetails(recommendation) },
                            onUseProductClick = { viewModel.markAsUsed(it) }
                        )

                    }
                }
            }
        }

        // Error display
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK")
                    }
                }
            }
        }

        // Recommendation details modal
        if (uiState.showRecommendationDetails && uiState.selectedRecommendation != null) {
            RecommendationDetailModal(
                recommendation = uiState.selectedRecommendation!!,
                onDismiss = { viewModel.hideRecommendationDetails() }
            )
        }
    }
}

@Composable
private fun RecommendationItem(
    recommendation: Recommendation,
    onClick: () -> Unit,
    onUseProductClick: (Recommendation) -> Unit
) {
    var showUseDialog by remember { mutableStateOf(false) }

    val kleeOne = FontFamily(Font(R.font.klee_one_regular))
    val imageRes = when (recommendation.product?.category ?: "cream") {
        "cleanser" -> R.drawable.cleaanser
        "cream" -> R.drawable.cream
        "mask" -> R.drawable.mask
        "pads" -> R.drawable.pads
        "serum" -> R.drawable.serum
        "spf" -> R.drawable.spf
        "toner" -> R.drawable.toner
        else -> R.drawable.cream
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(
                RoundedCornerShape(
                    topStart = 60.dp,
                    topEnd = 20.dp,
                    bottomEnd = 20.dp,
                    bottomStart = 60.dp
                )
            )
            .background(Color.White)
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Doctor avatar/icon
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = null,
                modifier = Modifier.size(60.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Recommendation content
            Column(
                modifier = Modifier.weight(1f)
            ) {
                // Doctor name
                Text(
                    text = recommendation.product?.name ?: "Назва продукту відсутня",
                    fontSize = 16.sp,
                    fontFamily = kleeOne,
                    fontWeight = FontWeight.SemiBold,
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Recommendation text (preview)
                Text(
                    text = recommendation.text ?: "Рекомендація відсутня",
                    fontSize = 14.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )}

                IconButton(onClick = { showUseDialog = true }) {
                    ThreeDotsIcon()
                }
            }}

            if (showUseDialog) {
                AlertDialog(
                    onDismissRequest = { showUseDialog = false },
                    title = {
                        Text(
                            text = "Використати продукт?",
                            fontFamily = KleeOneFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 18.sp
                        )
                    },
                    text = {
                        Text(
                            text = "Бажаєте використовувати продукт?",
                            fontFamily = KleeOneFamily,
                            fontSize = 16.sp
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showUseDialog = false
                                onUseProductClick(recommendation)
                            }
                        ) {
                            Text("Так", color = PurpleGradientStart)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showUseDialog = false }) {
                            Text("Ні", color = PurpleGradientStart)
                        }
                    }
                )
            }

        }



@Composable
fun ThreeDotsIcon(
    modifier: Modifier = Modifier,
    color: Color = PurpleGradientStart,
    size: Dp = 20.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val radius = size.toPx() * 0.1f
        val centerX = size.toPx() / 2
        val spacing = size.toPx() / 4

        drawCircle(color, radius, center = Offset(centerX, spacing))               // верхняя точка
        drawCircle(color, radius, center = Offset(centerX, size.toPx() / 2))       // средняя точка
        drawCircle(color, radius, center = Offset(centerX, size.toPx() - spacing)) // нижняя точка
    }
}
