package com.skinora.app.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.skinora.app.presentation.auth.AuthViewModel
import com.skinora.app.presentation.auth.SignInScreen
import com.skinora.app.presentation.auth.SignUpScreen
import com.skinora.app.presentation.main.MainScreen
import com.skinora.app.presentation.doctor.main.DoctorMainScreen  // НОВЫЙ ЭКРАН ДЛЯ ДОКТОРОВ
import com.skinora.app.presentation.welcome.WelcomeScreen

// Определение маршрутов
sealed class Screen(val route: String) {
    object Welcome : Screen("welcome")
    object SignIn : Screen("sign_in")
    object SignUp : Screen("sign_up")
    object Main : Screen("main")
    object DoctorMain : Screen("doctor_main")
}

@Composable
fun SkinoraNavigation(
    navController: NavHostController = rememberNavController(),
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val authState by authViewModel.authState.collectAsStateWithLifecycle()

    // ОБНОВЛЕНО: Определяем стартовый экран в зависимости от роли
    val startDestination = when {
        !authState.isLoggedIn -> Screen.Welcome.route
        authState.isDoctorRole -> Screen.DoctorMain.route  // Для докторов
        else -> Screen.Main.route  // Для пациентов
    }

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Welcome.route) {
            WelcomeScreen(
                onSignInClick = {
                    navController.navigate(Screen.SignIn.route)
                },
                onSignUpClick = {
                    navController.navigate(Screen.SignUp.route)
                }
            )
        }

        composable(Screen.SignIn.route) {
            SignInScreen(
                onSignUpClick = {
                    navController.navigate(Screen.SignUp.route) {
                        popUpTo(Screen.SignIn.route) { inclusive = true }
                    }
                },
                onSignInSuccess = {
                    // ОБНОВЛЕНО: Направляем на соответствующий экран в зависимости от роли
                    val destination = if (authState.isDoctorRole) {
                        Screen.DoctorMain.route
                    } else {
                        Screen.Main.route
                    }

                    navController.navigate(destination) {
                        popUpTo(Screen.Welcome.route) { inclusive = true }
                    }
                },
                viewModel = authViewModel
            )
        }

        composable(Screen.SignUp.route) {
            SignUpScreen(
                onSignInClick = {
                    navController.navigate(Screen.SignIn.route) {
                        popUpTo(Screen.SignUp.route) { inclusive = true }
                    }
                },
                onSignUpSuccess = {
                    // ОБНОВЛЕНО: Направляем на соответствующий экран в зависимости от роли
                    val destination = if (authState.isDoctorRole) {
                        Screen.DoctorMain.route
                    } else {
                        Screen.Main.route
                    }

                    navController.navigate(destination) {
                        popUpTo(Screen.Welcome.route) { inclusive = true }
                    }
                },
                viewModel = authViewModel
            )
        }

        // Основной экран для пациентов
        composable(Screen.Main.route) {
            MainScreen(
                onLogout = {
                    authViewModel.logout()
                    navController.navigate(Screen.Welcome.route) {
                        popUpTo(Screen.Main.route) { inclusive = true }
                    }
                }
            )
        }

        // НОВЫЙ: Основной экран для докторов
        composable(Screen.DoctorMain.route) {
            DoctorMainScreen(
                onLogout = {
                    authViewModel.logout()
                    navController.navigate(Screen.Welcome.route) {
                        popUpTo(Screen.DoctorMain.route) { inclusive = true }
                    }
                }
            )
        }
    }

    // ДОБАВЛЕНО: Слушаем изменения в роли пользователя для переходов
    LaunchedEffect(authState.isLoggedIn, authState.isDoctorRole) {
        if (authState.isLoggedIn) {
            val currentRoute = navController.currentDestination?.route
            val shouldNavigateToDoctor = authState.isDoctorRole && currentRoute != Screen.DoctorMain.route
            val shouldNavigateToPatient = !authState.isDoctorRole && currentRoute != Screen.Main.route

            if (shouldNavigateToDoctor) {
                navController.navigate(Screen.DoctorMain.route) {
                    popUpTo(Screen.Welcome.route) { inclusive = true }
                }
            } else if (shouldNavigateToPatient) {
                navController.navigate(Screen.Main.route) {
                    popUpTo(Screen.Welcome.route) { inclusive = true }
                }
            }
        }
    }
}