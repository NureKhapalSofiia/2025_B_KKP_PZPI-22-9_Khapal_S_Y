package com.skinora.app.data.repository

import android.os.Build
import androidx.annotation.RequiresApi
import com.skinora.app.data.api.DoctorApi
import com.skinora.app.data.model.*
import com.skinora.app.utils.Resource
import javax.inject.Inject
import javax.inject.Singleton
import java.time.LocalDateTime

@Singleton
class DoctorRepository @Inject constructor(
    private val doctorApi: DoctorApi
) {

    suspend fun getAllDoctors(): Resource<List<DoctorSearchResult>> {
        return try {
            val response = doctorApi.getAllDoctors()
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get doctors: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun searchDoctorsByName(name: String): Resource<List<DoctorSearchResult>> {
        return try {
            val response = doctorApi.searchDoctorsByName(name)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to search doctors: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getDoctorById(doctorId: Int): Resource<DoctorSearchResult> {
        return try {
            // Пока используем метод getAllDoctors и фильтруем
            // В будущем добавить эндпоинт GET /api/doctor/{id}
            val response = doctorApi.getAllDoctors()
            if (response.isSuccessful) {
                val doctors = response.body() ?: emptyList()
                val doctor = doctors.find { it.id == doctorId }
                if (doctor != null) {
                    Resource.Success(doctor)
                } else {
                    Resource.Error("Doctor not found")
                }
            } else {
                Resource.Error("Failed to get doctor: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getDoctorsBySpecialization(specialization: String): Resource<List<DoctorSearchResult>> {
        return try {
            // Для этого метода нужно добавить в DoctorApi эндпоинт GET /api/doctor/specialization/{specialization}
            // Который уже есть в контроллере
            Resource.Error("Method not implemented in API interface yet")
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // Методы для работы с пациентами доктора
    suspend fun getDoctorPatients(doctorId: Int): Resource<List<Patient>> {
        return try {
            // Этот метод есть в контроллере как GET /api/doctor/patients?id={doctorId}
            // Нужно добавить в DoctorApi
            Resource.Error("Method not implemented in API interface yet")
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // Методы для создания рекомендаций
    @RequiresApi(Build.VERSION_CODES.O)
    suspend fun createRecommendation(
        doctorId: Int,
        patientId: Int,
        text: String
    ): Resource<Recommendation> {
        return try {
            // Этот метод есть в контроллере как POST /api/doctor/patients/{id}/recommendations
            // Для демонстрации возвращаем успех
            val dummyRecommendation = Recommendation(
                id = System.currentTimeMillis().toInt(),
                patient = createDummyPatient(patientId),
                doctor = createDummyDoctor(doctorId),
                product = createDummyProduct(),  // Ошибка в серверной модели - product должен быть Doctor
                text = text,
                createdAt = LocalDateTime.now().toString()
            )
            Resource.Success(dummyRecommendation)
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // Методы для назначения продуктов
    suspend fun assignProduct(
        doctorId: Int,
        patientId: Int,
        productId: Int
    ): Resource<Unit> {
        return try {
            // Этот метод есть в контроллере как POST /api/doctor/patients/{patientId}/assign-product
            // Для демонстрации возвращаем успех
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // Получить доктора по ID (для профиля)
    suspend fun getDoctorByUserId(userId: Int): Resource<Doctor> {
        return try {
            // Этот метод нужно добавить в API
            Resource.Error("Method not implemented yet")
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // Вспомогательные методы для создания dummy данных
    private fun createDummyPatient(patientId: Int): Patient {
        return Patient(
            id = patientId,
            birthDate = "1990-01-01",
            gender = "Чоловіча",
            notes = "Пацієнт для демонстрації",
            user = User(
                id = patientId,
                email = "patient$patientId@example.com",
                passwordHash = "",
                fullName = "Пацієнт №$patientId",
                avatarUrl = null,
                role = Role(3, "PATIENT"),
                isActive = true,
                createdAt = "2024-12-01T00:00:00",
                updatedAt = "2024-12-01T00:00:00"
            ),
            doctor = null
        )
    }

    fun createDummyProduct(): Product {
        return Product(
            id = 1,
            name = "Demo Product",
            brand = "Demo Brand",
            category = "cream",
            description = "This is a demo product",
            isCertified = true,
            createdAt = "2024-01-01T00:00:00",
            updatedAt = "2024-01-01T00:00:00"
        )
    }


    private fun createDummyDoctor(doctorId: Int): Doctor {
        return Doctor(
            id = doctorId,
            specialization = "Дерматолог",
            experienceYears = 8,
            bio = "Досвідчений дерматолог",
            user = User(
                id = doctorId + 100,
                email = "doctor$doctorId@clinic.com",
                passwordHash = "",
                fullName = "Др. Лікар №$doctorId",
                avatarUrl = null,
                role = Role(2, "DOCTOR"),
                isActive = true,
                createdAt = "2024-12-01T00:00:00",
                updatedAt = "2024-12-01T00:00:00"
            )
        )
    }
}