package com.skinora.app.presentation.doctor.chat

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.Message
import com.skinora.app.data.repository.ChatRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import javax.inject.Inject

data class DoctorChatDetailState(
    val isLoading: Boolean = false,
    val isSending: Boolean = false,
    val error: String? = null,
    val messages: List<Message> = emptyList(),
    val doctorId: Int? = null
)

@HiltViewModel
class DoctorChatDetailViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _chatState = MutableStateFlow(DoctorChatDetailState())
    val chatState: StateFlow<DoctorChatDetailState> = _chatState.asStateFlow()

    init {
        loadDoctorData()
    }

    private fun loadDoctorData() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()

                if (userId <= 0) {
                    _chatState.value = _chatState.value.copy(
                        error = "Помилка: ID лікаря не знайдено. Увійдіть в акаунт знову."
                    )
                    return@launch
                }

                _chatState.value = _chatState.value.copy(doctorId = userId)
                Log.d("DoctorChatDetailViewModel", "Doctor ID loaded: $userId")

            } catch (e: Exception) {
                Log.e("DoctorChatDetailViewModel", "Error loading doctor data: ${e.message}")
                _chatState.value = _chatState.value.copy(
                    error = "Помилка завантаження даних лікаря: ${e.message}"
                )
            }
        }
    }

    fun loadMessages(chatId: Int) {
        Log.d("DoctorChatDetailViewModel", "Loading messages for chat: $chatId")
        _chatState.value = _chatState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            try {
                when (val result = chatRepository.getMessagesByChat(chatId)) {
                    is Resource.Success -> {
                        val messages = result.data ?: emptyList()
                        Log.d("DoctorChatDetailViewModel", "Messages loaded: ${messages.size} items")

                        _chatState.value = _chatState.value.copy(
                            isLoading = false,
                            messages = messages
                        )
                    }
                    is Resource.Error -> {
                        Log.e("DoctorChatDetailViewModel", "Failed to load messages: ${result.message}")

                        // Для демонстрации создаем dummy сообщения
                        val dummyMessages = createDummyMessages(chatId)
                        _chatState.value = _chatState.value.copy(
                            isLoading = false,
                            messages = dummyMessages
                        )
                    }
                    is Resource.Loading -> {
                        // Already handled above
                    }
                }
            } catch (e: Exception) {
                Log.e("DoctorChatDetailViewModel", "Exception loading messages: ${e.message}")
                _chatState.value = _chatState.value.copy(
                    isLoading = false,
                    error = "Помилка завантаження повідомлень: ${e.message}"
                )
            }
        }
    }

    fun sendMessage(chatId: Int, messageText: String) {
        val doctorId = _chatState.value.doctorId

        if (doctorId == null || doctorId <= 0) {
            _chatState.value = _chatState.value.copy(
                error = "Помилка: ID лікаря не знайдено"
            )
            return
        }

        if (messageText.isBlank()) {
            return
        }

        Log.d("DoctorChatDetailViewModel", "Sending message to chat $chatId from doctor $doctorId")
        _chatState.value = _chatState.value.copy(isSending = true, error = null)

        viewModelScope.launch {
            try {
                when (val result = chatRepository.sendMessage(chatId, messageText, doctorId)) {
                    is Resource.Success -> {
                        val sentMessage = result.data
                        Log.d("DoctorChatDetailViewModel", "Message sent successfully")

                        if (sentMessage != null) {
                            // Добавляем отправленное сообщение в список
                            val updatedMessages = _chatState.value.messages + sentMessage
                            _chatState.value = _chatState.value.copy(
                                isSending = false,
                                messages = updatedMessages
                            )
                        } else {
                            // Создаем локальное сообщение для демонстрации
                            val localMessage = Message(
                                id = System.currentTimeMillis().toInt(),
                                message = messageText,
                                sentAt = LocalDateTime.now().toString(),
                                isRead = false,
                                chatId = chatId,
                                senderId = doctorId
                            )

                            val updatedMessages = _chatState.value.messages + localMessage
                            _chatState.value = _chatState.value.copy(
                                isSending = false,
                                messages = updatedMessages
                            )
                        }
                    }
                    is Resource.Error -> {
                        Log.e("DoctorChatDetailViewModel", "Failed to send message: ${result.message}")

                        // Для демонстрации показываем сообщение как отправленное даже при ошибке API
                        val localMessage = Message(
                            id = System.currentTimeMillis().toInt(),
                            message = messageText,
                            sentAt = LocalDateTime.now().toString(),
                            isRead = false,
                            chatId = chatId,
                            senderId = doctorId
                        )

                        val updatedMessages = _chatState.value.messages + localMessage
                        _chatState.value = _chatState.value.copy(
                            isSending = false,
                            messages = updatedMessages
                        )
                    }
                    is Resource.Loading -> {
                        // Already handled above
                    }
                }
            } catch (e: Exception) {
                Log.e("DoctorChatDetailViewModel", "Exception sending message: ${e.message}")
                _chatState.value = _chatState.value.copy(
                    isSending = false,
                    error = "Помилка відправки повідомлення: ${e.message}"
                )
            }
        }
    }

    private fun createDummyMessages(chatId: Int): List<Message> {
        val doctorId = _chatState.value.doctorId ?: 1
        val patientId = chatId // Используем chatId как patientId для демонстрации

        return listOf(
            Message(
                id = 1,
                message = "Добрий день! Як ви себе почуваєте після останнього візиту?",
                sentAt = LocalDateTime.now().minusHours(2).toString(),
                isRead = true,
                chatId = chatId,
                senderId = doctorId
            ),
            Message(
                id = 2,
                message = "Вітаю! Набагато краще, дякую. Шкіра стала менш сухою після використання рекомендованого крему.",
                sentAt = LocalDateTime.now().minusHours(1).minusMinutes(45).toString(),
                isRead = true,
                chatId = chatId,
                senderId = patientId
            ),
            Message(
                id = 3,
                message = "Це чудово! Продовжуйте використовувати крем двічі на день. Чи є якісь нові симптоми?",
                sentAt = LocalDateTime.now().minusHours(1).minusMinutes(30).toString(),
                isRead = true,
                chatId = chatId,
                senderId = doctorId
            ),
            Message(
                id = 4,
                message = "Іноді з'являється невелике подразнення після використання. Це нормально?",
                sentAt = LocalDateTime.now().minusMinutes(15).toString(),
                isRead = false,
                chatId = chatId,
                senderId = patientId
            )
        )
    }

    fun getDoctorId(): Int {
        return _chatState.value.doctorId ?: 0
    }

    fun clearError() {
        _chatState.value = _chatState.value.copy(error = null)
    }
}