package com.skinora.app.ui.components

import androidx.compose.foundation.layout.size
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.skinora.app.R
import com.skinora.app.presentation.welcome.PurpleGradientStart

sealed class DoctorBottomNavItem(
    val route: String,
    val icon: Int,
    val title: String
) {
    object Home : DoctorBottomNavItem("doctor_home", R.drawable.home, "Головна")
    object Chat : DoctorBottomNavItem("doctor_chat", R.drawable.message, "Чати")
    object Profile : DoctorBottomNavItem("doctor_profile", R.drawable.user, "Профіль")
}

@Composable
fun DoctorBottomNavigation(
    currentRoute: String,
    onItemClick: (String) -> Unit
) {
    val items = listOf(
        DoctorBottomNavItem.Home,
        DoctorBottomNavItem.Chat,
        DoctorBottomNavItem.Profile
    )

    NavigationBar(
        containerColor = Color.White,
        contentColor = PurpleGradientStart
    ) {
        items.forEach { item ->
            NavigationBarItem(
                icon = {
                    Icon(
                        painter = painterResource(id = item.icon),
                        contentDescription = item.title,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        color = if (currentRoute == item.route) PurpleGradientStart else Color.Gray
                    )
                },
                selected = currentRoute == item.route,
                onClick = { onItemClick(item.route) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PurpleGradientStart,
                    unselectedIconColor = Color.Gray,
                    indicatorColor = PurpleGradientStart.copy(alpha = 0.1f)
                )
            )
        }
    }
}