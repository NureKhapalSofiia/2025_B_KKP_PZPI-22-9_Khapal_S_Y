package com.skinora.app.presentation.chat

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.ChatRepository
import com.skinora.app.data.repository.AppointmentRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatDetailState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val chat: Chat? = null,
    val messages: List<Message> = emptyList(),
    val messageText: String = "",
    val isSending: Boolean = false,
    val currentUserId: Int? = null,
    val currentUserEmail: String = "",
    val showAppointmentDialog: Boolean = false,
    val isCreatingAppointment: Boolean = false
)

@HiltViewModel
class ChatDetailViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val appointmentRepository: AppointmentRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatDetailState())
    val uiState: StateFlow<ChatDetailState> = _uiState.asStateFlow()

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userEmail = preferencesManager.getUserEmail().first()
                val userId = preferencesManager.getUserId().first()

                Log.d("ChatDetailViewModel", "Current user email: $userEmail")
                Log.d("ChatDetailViewModel", "Current user ID: $userId")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову."
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(
                    currentUserId = userId,
                    currentUserEmail = userEmail
                )

                Log.d("ChatDetailViewModel", "Set currentUserId: $userId for user: $userEmail")

            } catch (e: Exception) {
                Log.e("ChatDetailViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження користувача: ${e.message}"
                )
            }
        }
    }

    fun loadChatDetails(chatId: Int) {
        Log.d("ChatDetailViewModel", "Loading chat details for chatId: $chatId")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            loadMessages(chatId)
            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }

    private suspend fun loadMessages(chatId: Int) {
        when (val result = chatRepository.getMessagesByChat(chatId)) {
            is Resource.Success -> {
                Log.d("ChatDetailViewModel", "Messages loaded: ${result.data?.size ?: 0} items")
                val messages = result.data ?: emptyList()

                _uiState.value = _uiState.value.copy(messages = messages)
            }
            is Resource.Error -> {
                Log.e("ChatDetailViewModel", "Error loading messages: ${result.message}")
                _uiState.value = _uiState.value.copy(
                    messages = emptyList(),
                    error = "Помилка завантаження повідомлень: ${result.message}"
                )
            }
            is Resource.Loading -> {}
        }
    }

    fun updateMessageText(text: String) {
        _uiState.value = _uiState.value.copy(messageText = text)
    }

    fun sendMessage() {
        val currentState = _uiState.value
        val chatId = currentState.chat?.id ?: return
        val messageText = currentState.messageText.trim()
        val currentUserId = currentState.currentUserId ?: return

        if (messageText.isEmpty() || currentState.isSending) return

        Log.d("ChatDetailViewModel", "Sending message: $messageText")

        _uiState.value = currentState.copy(isSending = true)

        viewModelScope.launch {
            when (val result = chatRepository.sendMessage(chatId, messageText, currentUserId)) {
                is Resource.Success -> {
                    Log.d("ChatDetailViewModel", "Message sent successfully")

                    // Добавляем новое сообщение в список
                    val newMessage = result.data!!
                    val updatedMessages = currentState.messages + newMessage

                    _uiState.value = _uiState.value.copy(
                        messages = updatedMessages,
                        messageText = "",
                        isSending = false
                    )
                }
                is Resource.Error -> {
                    Log.e("ChatDetailViewModel", "Error sending message: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        isSending = false,
                        error = "Помилка відправки повідомлення: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    // ФУНКЦИОНАЛЬНОСТЬ ДЛЯ ВСТРЕЧ

    fun showAppointmentDialog() {
        _uiState.value = _uiState.value.copy(showAppointmentDialog = true)
    }

    fun hideAppointmentDialog() {
        _uiState.value = _uiState.value.copy(showAppointmentDialog = false)
    }

    fun createAppointment(datetime: String, notes: String) {
        val currentState = _uiState.value
        val chat = currentState.chat ?: return
        val patientId = currentState.currentUserId ?: return
       val doctorId = chat.participant2.user.id

        Log.d("ChatDetailViewModel", "=== APPOINTMENT DEBUG ===")
        Log.d("ChatDetailViewModel", "Chat ID: ${chat.id}")
        Log.d("ChatDetailViewModel", "Patient ID (currentUserId): $patientId")
        Log.d("ChatDetailViewModel", "Doctor ID from chat.participant2.id: $doctorId")
        Log.d("ChatDetailViewModel", "Doctor name: ${chat.participant2.user?.fullName}")
        Log.d("ChatDetailViewModel", "DateTime: $datetime")
        Log.d("ChatDetailViewModel", "Notes: $notes")

        _uiState.value = currentState.copy(isCreatingAppointment = true)

        viewModelScope.launch {
            when (val result = appointmentRepository.createAppointment(patientId, doctorId, datetime, notes)) {
                is Resource.Success -> {
                    Log.d("ChatDetailViewModel", "Appointment created successfully")
                    handleAppointmentSuccess(currentState, chat, datetime, notes)
                }
                is Resource.Error -> {
                    Log.e("ChatDetailViewModel", "Error creating appointment: ${result.message}")
                    handleAppointmentError(result.message)
                }
                is Resource.Loading -> {}
            }
        }
    }

    private fun handleAppointmentSuccess(currentState: ChatDetailState, chat: Chat, datetime: String, notes: String) {
        // Отправляем сообщение в чат о создании встречи
        val appointmentMessage = "Запропоновано зустріч на ${formatDateTimeForMessage(datetime)}"
        val notesMessage = if (notes.isNotEmpty()) "\nНотатки: $notes" else ""
        val fullMessage = appointmentMessage + notesMessage

        // Добавляем сообщение о встрече в чат
        val appointmentChatMessage = Message(
            id = System.currentTimeMillis().toInt(),
            message = fullMessage,
            sentAt = getCurrentTimestamp(),
            isRead = false,
            chatId = chat.id,
            senderId = currentState.currentUserId ?: 0
        )

        val updatedMessages = currentState.messages + appointmentChatMessage

        _uiState.value = _uiState.value.copy(
            messages = updatedMessages,
            isCreatingAppointment = false,
            showAppointmentDialog = false
        )

        // Пытаемся отправить сообщение на сервер
        viewModelScope.launch {
            sendAppointmentMessageToServer(chat.id, fullMessage, currentState.currentUserId ?: 0)
        }
    }

    private fun handleAppointmentError(errorMessage: String?) {
        _uiState.value = _uiState.value.copy(
            isCreatingAppointment = false,
            showAppointmentDialog = false,
            error = "Помилка при створенні зустрічі: $errorMessage"
        )
    }

    private suspend fun sendAppointmentMessageToServer(chatId: Int, message: String, senderId: Int) {
        try {
            chatRepository.sendMessage(chatId, message, senderId)
            Log.d("ChatDetailViewModel", "Appointment message sent to server")
        } catch (e: Exception) {
            Log.e("ChatDetailViewModel", "Failed to send appointment message to server: ${e.message}")
        }
    }

    private fun formatDateTimeForMessage(datetime: String): String {
        return try {
            // Преобразуем "2025-06-12T09:30:00" в читабельный формат
            val parts = datetime.split("T")
            if (parts.size == 2) {
                val datePart = parts[0] // "2025-06-12"
                val timePart = parts[1].substring(0, 5) // "09:30"
                "$datePart о $timePart"
            } else {
                datetime
            }
        } catch (e: Exception) {
            datetime
        }
    }

    fun setChatInfo(chat: Chat) {
        Log.d("ChatDetailViewModel", "Setting chat info:")
        Log.d("ChatDetailViewModel", "Chat ID: ${chat.id}")
        Log.d("ChatDetailViewModel", "Participant1 (Patient): ${chat.participant1.user?.fullName} (ID: ${chat.participant1.id})")
        Log.d("ChatDetailViewModel", "Participant2 (Doctor): ${chat.participant2.user?.fullName} (ID: ${chat.participant2.id})")

        _uiState.value = _uiState.value.copy(chat = chat)
        loadChatDetails(chat.id)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    private fun getCurrentTimestamp(): String {
        return try {
            val currentTime = System.currentTimeMillis()
            val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.getDefault())
            dateFormat.format(java.util.Date(currentTime))
        } catch (e: Exception) {
            "2025-06-06T10:00:00"
        }
    }
}