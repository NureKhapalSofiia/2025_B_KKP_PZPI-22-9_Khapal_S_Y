package com.skinora.app.presentation.analysis

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.skinora.app.data.model.MeasurementDto
import com.skinora.app.ui.components.PurpleWaves

@Composable
fun AnalysisBottomSheet(measurement: MeasurementDto) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(900.dp)
            .background(Color.Transparent)
    ) {
        val kleeOne = FontFamily(Font(com.skinora.app.R.font.klee_one_regular))

        Canvas(modifier = Modifier.fillMaxSize()) {
            val backWaveColor = Color(0xFFD3CBFF)
            val frontWaveColor = Color(0xFFC5BAFF)
            // Задняя волна
            val backWave = Path().apply {
                moveTo(0f, size.height * 0.28f)
                quadraticBezierTo(
                    size.width * 0.375f, size.height * 0.28f,
                    size.width * 0.59f, size.height * 0.42f
                )
                quadraticBezierTo(
                    size.width * 0.86f, size.height * 0.53f,
                    size.width, size.height * 0.40f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(backWave, color = backWaveColor)

            // Передняя волна
            val frontWave = Path().apply {
                moveTo(0f, size.height * 0.33f)
                quadraticBezierTo(
                    size.width * 0.38f, size.height * 0.33f,
                    size.width * 0.58f, size.height * 0.47f
                )
                quadraticBezierTo(
                    size.width * 0.85f, size.height * 0.58f,
                    size.width, size.height * 0.45f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(frontWave, color = frontWaveColor)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start
        ) {
            Spacer(modifier = Modifier.height(300.dp))

            Text(
                text = " ${measurement.takenAt.substringBefore("T")}",
                fontFamily = kleeOne,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.Black
            )

            Spacer(modifier = Modifier.height(100.dp))

            Spacer(modifier = Modifier.height(8.dp))
            Text("Тип шкіри: ${measurement.skinType}", fontSize = 15.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Температура: ${measurement.temperature}°C", fontSize = 15.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Зволоження: ${measurement.moistureLevel}%", fontSize = 15.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Коментар: ${measurement.comments}", fontSize = 15.sp, color = Color.Black)
        }
    }
}
