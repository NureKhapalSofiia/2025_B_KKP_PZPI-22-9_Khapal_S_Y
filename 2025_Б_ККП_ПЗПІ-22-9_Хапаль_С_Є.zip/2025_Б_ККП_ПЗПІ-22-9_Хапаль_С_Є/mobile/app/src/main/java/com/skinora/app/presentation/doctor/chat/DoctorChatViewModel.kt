package com.skinora.app.presentation.doctor.chat

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.Chat
import com.skinora.app.data.repository.ChatRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DoctorChatState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val chats: List<Chat> = emptyList(),
    val doctorId: Int? = null
)

@HiltViewModel
class DoctorChatViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _chatState = MutableStateFlow(DoctorChatState())
    val chatState: StateFlow<DoctorChatState> = _chatState.asStateFlow()

    init {
        loadDoctorData()
    }

    private fun loadDoctorData() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()

                if (userId <= 0) {
                    _chatState.value = _chatState.value.copy(
                        error = "Помилка: ID лікаря не знайдено. Увійдіть в акаунт знову."
                    )
                    return@launch
                }

                _chatState.value = _chatState.value.copy(doctorId = userId)
                Log.d("DoctorChatViewModel", "Doctor ID loaded: $userId")

            } catch (e: Exception) {
                Log.e("DoctorChatViewModel", "Error loading doctor data: ${e.message}")
                _chatState.value = _chatState.value.copy(
                    error = "Помилка завантаження даних лікаря: ${e.message}"
                )
            }
        }
    }

    fun loadChats() {
        val doctorId = _chatState.value.doctorId
        if (doctorId == null || doctorId <= 0) {
            _chatState.value = _chatState.value.copy(
                error = "Неможливо завантажити чати: невірний ID лікаря"
            )
            return
        }

        Log.d("DoctorChatViewModel", "Loading chats for doctor: $doctorId")
        _chatState.value = _chatState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            try {
                // В реальной реализации здесь будет вызов API для получения чатов доктора
                // Пока создаем dummy данные для демонстрации
                val dummyChats = createDummyChatsForDoctor(doctorId)

                _chatState.value = _chatState.value.copy(
                    isLoading = false,
                    chats = dummyChats
                )

                Log.d("DoctorChatViewModel", "Chats loaded: ${dummyChats.size} items")

            } catch (e: Exception) {
                Log.e("DoctorChatViewModel", "Error loading chats: ${e.message}")
                _chatState.value = _chatState.value.copy(
                    isLoading = false,
                    error = "Помилка завантаження чатів: ${e.message}"
                )
            }
        }
    }

    private fun createDummyChatsForDoctor(doctorId: Int): List<Chat> {
        // Создаем несколько dummy чатов для демонстрации
        return listOf(
            Chat(
                id = 1,
                participant1 = createDummyPatient(1, "Іван Петренко", "Чоловіча", "Проблеми з сухістю шкіри"),
                participant2 = createDummyDoctor(doctorId)
            ),
            Chat(
                id = 2,
                participant1 = createDummyPatient(2, "Марія Коваленко", "Жіноча", "Акне та підвищена жирність"),
                participant2 = createDummyDoctor(doctorId)
            ),
            Chat(
                id = 3,
                participant1 = createDummyPatient(3, "Олексій Іванов", "Чоловіча", "Алергічні реакції на косметику"),
                participant2 = createDummyDoctor(doctorId)
            ),
            Chat(
                id = 4,
                participant1 = createDummyPatient(4, "Анна Сидоренко", "Жіноча", "Ознаки старіння шкіри"),
                participant2 = createDummyDoctor(doctorId)
            )
        )
    }

    private fun createDummyPatient(
        id: Int,
        fullName: String,
        gender: String,
        notes: String
    ): com.skinora.app.data.model.Patient {
        return com.skinora.app.data.model.Patient(
            id = id,
            birthDate = "1990-01-0$id",
            gender = gender,
            notes = notes,
            user = com.skinora.app.data.model.User(
                id = id,
                email = "patient$id@example.com",
                passwordHash = "",
                fullName = fullName,
                avatarUrl = null,
                role = com.skinora.app.data.model.Role(3, "patient"),
                isActive = true,
                createdAt = "2024-12-01T00:00:00",
                updatedAt = "2024-12-01T00:00:00"
            ),
            doctor = null
        )
    }

    private fun createDummyDoctor(doctorId: Int): com.skinora.app.data.model.Doctor {
        return com.skinora.app.data.model.Doctor(
            id = doctorId,
            specialization = "Дерматолог",
            experienceYears = 8,
            bio = "Досвідчений дерматолог",
            user = com.skinora.app.data.model.User(
                id = doctorId + 100,
                email = "doctor@clinic.com",
                passwordHash = "",
                fullName = "Др. Іванова Марія",
                avatarUrl = null,
                role = com.skinora.app.data.model.Role(2, "doctor"),
                isActive = true,
                createdAt = "2024-12-01T00:00:00",
                updatedAt = "2024-12-01T00:00:00"
            )
        )
    }

    fun refreshChats() {
        Log.d("DoctorChatViewModel", "Refreshing chats...")
        loadChats()
    }

    fun clearError() {
        _chatState.value = _chatState.value.copy(error = null)
    }
}