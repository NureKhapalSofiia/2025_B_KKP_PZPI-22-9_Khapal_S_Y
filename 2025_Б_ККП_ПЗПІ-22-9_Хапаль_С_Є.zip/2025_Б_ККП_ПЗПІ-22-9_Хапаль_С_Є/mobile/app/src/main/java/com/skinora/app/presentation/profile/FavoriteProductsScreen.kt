package com.skinora.app.presentation.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.window.Dialog

import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.R
import com.skinora.app.data.model.Product
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import com.skinora.app.ui.components.TopPurpleWaves

@Composable
fun FavoriteProductsScreen(
    onBackClick: () -> Unit,
    viewModel: FavoriteProductsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()

    var isBottomSheetVisible by remember { mutableStateOf(false) }

    selectedProduct?.let {
        isBottomSheetVisible = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFE4EDFD), Color.White),
                    startY = 0f,
                    endY = Float.POSITIVE_INFINITY
                )
            )
    ) {
        // Декоративные волны сверху
        TopPurpleWaves(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .align(Alignment.TopCenter),
            backWaveColor = PurpleGradientStart.copy(alpha = 0.4f),
            frontWaveColor = PurpleGradientEnd.copy(alpha = 0.3f)
        )

        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick) {
                        Text("←", fontSize = 24.sp, color = PurpleGradientStart)
                    }

                    Text(
                        text = "Улюблені продукти",
                        fontSize = 20.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF2D1B69),
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { viewModel.refreshFavorites() }) {
                        Text("↻", fontSize = 20.sp, color = PurpleGradientStart)
                    }
                }
            }

            // Content
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PurpleGradientStart)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (uiState.favoriteProducts.isEmpty()) {
                        item {
                            EmptyFavoritesCard()
                        }
                    } else {
                        items(uiState.favoriteProducts) { product ->
                            FavoriteProductCard(
                                product = product,
                                onRemoveFromFavorites = { viewModel.removeFromFavorites(product.id) },
                                onClick = {
                                    viewModel.selectProduct(product)
                                }
                            )
                        }
                    }
                }
            }
        }

        if (isBottomSheetVisible && selectedProduct != null) {
            FavoriteProductBottomSheet(product = selectedProduct!!)
        }

        // Показ ошибок
        uiState.error?.let { error ->
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = error,
                        color = Color.White,
                        modifier = Modifier.weight(1f),
                        fontFamily = KleeOneFamily
                    )

                    TextButton(
                        onClick = { viewModel.clearError() },
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = Color.White
                        )
                    ) {
                        Text("OK", fontFamily = KleeOneFamily)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyFavoritesCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = PurpleGradientStart.copy(alpha = 0.05f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Немає улюблених продуктів",
                fontSize = 18.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.SemiBold,
                color = Color.Black
            )

            Text(
                text = "Додайте продукти в улюблені, щоб швидко їх знаходити",
                fontSize = 14.sp,
                fontFamily = KleeOneFamily,
                fontWeight = FontWeight.Normal,
                color = Color(0xFF6B7280),
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun FavoriteProductCard(
    product: Product,
    onRemoveFromFavorites: () -> Unit,
    onClick: () -> Unit
) {
    val kleeOne = FontFamily(Font(R.font.klee_one_regular))

    val imageRes = when (product.category
    ) {
        "cleanser" -> R.drawable.cleaanser
        "cream" -> R.drawable.cream
        "mask" -> R.drawable.mask
        "pads" -> R.drawable.pads
        "serum" -> R.drawable.serum
        "spf" -> R.drawable.spf
        "toner" -> R.drawable.toner
        else -> R.drawable.cream
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(
                RoundedCornerShape(
                    topStart = 60.dp,
                    topEnd = 20.dp,
                    bottomEnd = 20.dp,
                    bottomStart = 60.dp
                )
            )
            .background(Color.White)
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically

        ) {
            // Иконка продукта
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = null,
                modifier = Modifier.size(60.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Информация о продукте
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = kleeOne
                )

                Text(
                    text = product.brand,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = kleeOne
                )

                Text(
                    text = product.category,
                    fontSize = 12.sp,
                    fontFamily = KleeOneFamily,
                    fontWeight = FontWeight.Normal,
                    color = Color(0xFF6B7280)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            var showDialog by remember { mutableStateOf(false) }

            Box {
                IconButton(
                    onClick = { showDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    ThreeDotsIcon()
                }

                if (showDialog) {
                    Dialog(onDismissRequest = { showDialog = false }) {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(2.dp, PurpleGradientStart),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(24.dp)
                                    .wrapContentWidth()
                                    .wrapContentHeight(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Ви впевнені, що бажаєте видалити цей продукт?",
                                    fontSize = 16.sp,
                                    fontFamily = KleeOneFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF2D1B69)
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            onRemoveFromFavorites()
                                            showDialog = false
                                        },
                                        border = BorderStroke(1.dp, PurpleGradientStart),
                                        shape = RoundedCornerShape(50),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = Color.Transparent,
                                            contentColor = PurpleGradientStart
                                        )
                                    ) {
                                        Text("так", fontFamily = KleeOneFamily)
                                    }

                                    OutlinedButton(
                                        onClick = { showDialog = false },
                                        border = BorderStroke(1.dp, PurpleGradientStart),
                                        shape = RoundedCornerShape(50),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = Color.Transparent,
                                            contentColor = PurpleGradientStart
                                        )
                                    ) {
                                        Text("ні", fontFamily = KleeOneFamily)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ThreeDotsIcon(
    modifier: Modifier = Modifier,
    color: Color = PurpleGradientStart,
    size: Dp = 20.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val radius = size.toPx() * 0.1f
        val centerX = size.toPx() / 2
        val spacing = size.toPx() / 4

        drawCircle(color, radius, center = Offset(centerX, spacing))               // верхняя точка
        drawCircle(color, radius, center = Offset(centerX, size.toPx() / 2))       // средняя точка
        drawCircle(color, radius, center = Offset(centerX, size.toPx() - spacing)) // нижняя точка
    }
}
