package com.skinora.app.presentation.usingproducts

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.ProductRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class UsingProductsState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val usingProducts: List<UsingProduct> = emptyList(),
    val selectedProduct: UsingProduct? = null,
    val showProductDetails: Boolean = false,
    val isStoppingProduct: Boolean = false,
    val stopProductSuccess: Boolean = false,
    val patientId: Int? = null
)

@HiltViewModel
class UsingProductsViewModel @Inject constructor(
    private val productRepository: ProductRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(UsingProductsState())
    val uiState: StateFlow<UsingProductsState> = _uiState.asStateFlow()

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()
                val userEmail = preferencesManager.getUserEmail().first()

                Log.d("UsingProductsViewModel", "Current user ID: $userId, email: $userEmail")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(patientId = userId)

                // Загружаем продукты после получения ID пациента
                loadUsingProducts()

            } catch (e: Exception) {
                Log.e("UsingProductsViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження користувача: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    fun loadUsingProducts() {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо завантажити використовувані продукти: невірний ID користувача"
            )
            return
        }

        Log.d("UsingProductsViewModel", "Loading using products for patient: $patientId")

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            when (val result = productRepository.getUsingProducts(patientId)) {
                is Resource.Success -> {
                    Log.d("UsingProductsViewModel", "Using products loaded: ${result.data?.size ?: 0} items")
                    val products = result.data ?: emptyList()

                    // УБРАНО: Фильтрация по stoppedAt, так как backend теперь возвращает только активные
                    _uiState.value = _uiState.value.copy(
                        usingProducts = products,
                        isLoading = false
                    )
                }
                is Resource.Error -> {
                    Log.e("UsingProductsViewModel", "Error loading using products: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        usingProducts = emptyList(),
                        isLoading = false,
                        error = "Помилка завантаження використовуваних продуктів: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun showProductDetails(product: UsingProduct) {
        Log.d("UsingProductsViewModel", "Showing details for product: ${product.product.name}")
        _uiState.value = _uiState.value.copy(
            selectedProduct = product,
            showProductDetails = true
        )
    }

    fun hideProductDetails() {
        _uiState.value = _uiState.value.copy(
            selectedProduct = null,
            showProductDetails = false
        )
    }

    fun stopUsingProduct(product: UsingProduct) {
        val patientId = _uiState.value.patientId
        if (patientId == null || patientId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Неможливо припинити використання: невірний ID користувача"
            )
            return
        }

        Log.d("UsingProductsViewModel", "Stopping product: ${product.product.name}")

        _uiState.value = _uiState.value.copy(isStoppingProduct = true, error = null)

        viewModelScope.launch {
            // ОБНОВЛЕНО: stopUsingProduct теперь возвращает UsedProduct
            when (val result = productRepository.stopUsingProduct(patientId, product.product.id)) {
                is Resource.Success -> {
                    Log.d("UsingProductsViewModel", "Product stopped successfully, moved to used_products")
                    _uiState.value = _uiState.value.copy(
                        isStoppingProduct = false,
                        stopProductSuccess = true,
                        showProductDetails = false
                    )

                    // Обновляем список продуктов
                    loadUsingProducts()
                }
                is Resource.Error -> {
                    Log.e("UsingProductsViewModel", "Error stopping product: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        isStoppingProduct = false,
                        error = "Помилка припинення використання: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun refreshData() {
        loadUsingProducts()
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    fun clearStopSuccess() {
        _uiState.value = _uiState.value.copy(stopProductSuccess = false)
    }
}