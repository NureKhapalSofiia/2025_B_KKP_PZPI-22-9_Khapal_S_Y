package com.skinora.app.presentation.doctor.profile

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.repository.DoctorRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DoctorProfileState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val doctorId: Int? = null,
    val doctorName: String = "",
    val specialization: String = "",
    val experienceYears: Int = 0,
    val bio: String = "",
    val totalPatients: Int = 0,
    val totalRecommendations: Int = 0,
    val totalConsultations: Int = 0
)

@HiltViewModel
class DoctorProfileViewModel @Inject constructor(
    private val doctorRepository: DoctorRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _profileState = MutableStateFlow(DoctorProfileState())
    val profileState: StateFlow<DoctorProfileState> = _profileState.asStateFlow()

    init {
        loadDoctorProfile()
    }

    private fun loadDoctorProfile() {
        viewModelScope.launch {
            _profileState.value = _profileState.value.copy(isLoading = true, error = null)

            try {
                val userId = preferencesManager.getUserId().first()
                val userName = preferencesManager.getUserName().first()

                Log.d("DoctorProfileViewModel", "Current user - ID: $userId, name: $userName")

                if (userId <= 0) {
                    _profileState.value = _profileState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                // Загружаем базовую информацию из preferences
                _profileState.value = _profileState.value.copy(
                    doctorId = userId,
                    doctorName = userName.ifEmpty { "Лікар" }
                )

                // Загружаем дополнительную информацию о докторе
                loadDoctorDetails(userId)

                // Загружаем статистику
                loadDoctorStatistics(userId)

            } catch (e: Exception) {
                Log.e("DoctorProfileViewModel", "Error loading doctor profile: ${e.message}")
                _profileState.value = _profileState.value.copy(
                    error = "Помилка завантаження профілю: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    private suspend fun loadDoctorDetails(doctorId: Int) {
        try {
            when (val result = doctorRepository.getDoctorById(doctorId)) {
                is Resource.Success -> {
                    val doctor = result.data
                    if (doctor != null) {
                        Log.d("DoctorProfileViewModel", "Doctor details loaded: ${doctor.user?.fullName}")

                        _profileState.value = _profileState.value.copy(
                            doctorName = doctor.user?.fullName ?: "Лікар",
                            specialization = doctor.specialization ?: "Дерматолог",
                            experienceYears = doctor.experienceYears,
                            bio = doctor.bio ?: "Досвідчений лікар"
                        )
                    }
                }
                is Resource.Error -> {
                    Log.e("DoctorProfileViewModel", "Failed to load doctor details: ${result.message}")

                    // Для демонстрации устанавливаем dummy данные
                    _profileState.value = _profileState.value.copy(
                        specialization = "Дерматолог",
                        experienceYears = 8,
                        bio = "Досвідчений дерматолог, спеціаліст з лікування захворювань шкіри та косметологічних процедур. Надаю індивідуальний підхід до кожного пацієнта."
                    )
                }
                is Resource.Loading -> {}
            }
        } catch (e: Exception) {
            Log.e("DoctorProfileViewModel", "Exception loading doctor details: ${e.message}")

            // Fallback данные для демонстрации
            _profileState.value = _profileState.value.copy(
                specialization = "Дерматолог",
                experienceYears = 8,
                bio = "Досвідчений дерматолог"
            )
        }
    }

    private suspend fun loadDoctorStatistics(doctorId: Int) {
        try {
            // В реальной реализации здесь будут вызовы к API для получения статистики
            // Пока устанавливаем случайные значения для демонстрации

            val totalPatients = (50..200).random()
            val totalRecommendations = (100..500).random()
            val totalConsultations = (200..800).random()

            _profileState.value = _profileState.value.copy(
                totalPatients = totalPatients,
                totalRecommendations = totalRecommendations,
                totalConsultations = totalConsultations,
                isLoading = false
            )

            Log.d("DoctorProfileViewModel", "Statistics loaded - Patients: $totalPatients, Recommendations: $totalRecommendations, Consultations: $totalConsultations")

        } catch (e: Exception) {
            Log.e("DoctorProfileViewModel", "Exception loading statistics: ${e.message}")

            _profileState.value = _profileState.value.copy(
                totalPatients = 75,
                totalRecommendations = 250,
                totalConsultations = 400,
                isLoading = false
            )
        }
    }

    fun refreshProfile() {
        Log.d("DoctorProfileViewModel", "Refreshing doctor profile...")
        loadDoctorProfile()
    }

    fun clearError() {
        _profileState.value = _profileState.value.copy(error = null)
    }
}