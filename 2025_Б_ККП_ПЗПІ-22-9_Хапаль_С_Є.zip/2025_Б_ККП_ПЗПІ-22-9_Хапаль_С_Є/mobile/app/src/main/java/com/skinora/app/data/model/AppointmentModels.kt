package com.skinora.app.data.model

import com.google.gson.annotations.SerializedName

data class Appointment(
    val id: Int,
    val patient: Patient,
    val doctor: Doctor,
    val datetime: String,  // ISO format: "2025-06-07T14:30:00"
    val notes: String,
    val status: String     // "PENDING", "CONFIRMED", "CANCELLED"
)

data class CreateAppointmentRequest(
    @SerializedName("patient")
    val patient: PatientReference,
    @SerializedName("doctor")
    val doctor: DoctorReference,
    val datetime: String,  // ISO format
    val notes: String,
    val status: String = "PENDING"
)

// Упрощенные ссылки для создания записи
data class PatientReference(
    val id: Int
)

data class DoctorReference(
    val id: Int
)

// Enum для статусов
enum class AppointmentStatus(val value: String) {
    PENDING("PENDING"),
    CONFIRMED("CONFIRMED"),
    CANCELLED("CANCELLED")
}