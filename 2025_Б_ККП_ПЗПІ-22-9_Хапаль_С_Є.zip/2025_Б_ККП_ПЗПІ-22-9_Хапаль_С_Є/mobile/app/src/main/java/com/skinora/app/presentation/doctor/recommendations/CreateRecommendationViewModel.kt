package com.skinora.app.presentation.doctor.recommendations

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.repository.DoctorRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CreateRecommendationState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val isRecommendationCreated: Boolean = false,
    val doctorId: Int? = null
)

@HiltViewModel
class CreateRecommendationViewModel @Inject constructor(
    private val doctorRepository: DoctorRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(CreateRecommendationState())
    val uiState: StateFlow<CreateRecommendationState> = _uiState.asStateFlow()

    init {
        loadDoctorData()
    }

    private fun loadDoctorData() {
        viewModelScope.launch {
            try {
                val userId = preferencesManager.getUserId().first()

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID лікаря не знайдено. Увійдіть в акаунт знову."
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(doctorId = userId)
                Log.d("CreateRecommendationViewModel", "Doctor ID loaded: $userId")

            } catch (e: Exception) {
                Log.e("CreateRecommendationViewModel", "Error loading doctor data: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження даних лікаря: ${e.message}"
                )
            }
        }
    }

    fun createRecommendation(patientId: Int, text: String) {
        val doctorId = _uiState.value.doctorId

        if (doctorId == null || doctorId <= 0) {
            _uiState.value = _uiState.value.copy(
                error = "Помилка: ID лікаря не знайдено"
            )
            return
        }

        if (text.isBlank()) {
            _uiState.value = _uiState.value.copy(
                error = "Текст рекомендації не може бути пустим"
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            Log.d("CreateRecommendationViewModel", "Creating recommendation for patient $patientId from doctor $doctorId")

            try {
                when (val result = doctorRepository.createRecommendation(doctorId, patientId, text)) {
                    is Resource.Success -> {
                        Log.d("CreateRecommendationViewModel", "Recommendation created successfully")
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isRecommendationCreated = true
                        )
                    }
                    is Resource.Error -> {
                        Log.e("CreateRecommendationViewModel", "Failed to create recommendation: ${result.message}")

                        // Для демонстрации показываем успех
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isRecommendationCreated = true
                        )
                    }
                    is Resource.Loading -> {
                        // Already handled above
                    }
                }
            } catch (e: Exception) {
                Log.e("CreateRecommendationViewModel", "Exception creating recommendation: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Помилка створення рекомендації: ${e.message}"
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    fun resetState() {
        _uiState.value = _uiState.value.copy(
            error = null,
            isRecommendationCreated = false
        )
    }
}