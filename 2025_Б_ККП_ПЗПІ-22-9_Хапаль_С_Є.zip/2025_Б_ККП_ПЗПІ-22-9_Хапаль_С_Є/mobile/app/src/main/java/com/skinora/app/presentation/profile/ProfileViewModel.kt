package com.skinora.app.presentation.profile

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.skinora.app.data.model.*
import com.skinora.app.data.repository.AuthRepository
import com.skinora.app.data.repository.PatientRepository
import com.skinora.app.data.repository.ProductRepository
import com.skinora.app.data.repository.UserRepository
import com.skinora.app.data.preferences.PreferencesManager
import com.skinora.app.utils.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProfileState(
    val isLoading: Boolean = false,
    val error: String? = null,
    val patient: Patient? = null,
    val user: User? = null,
    val currentUserId: Int? = null,
    val currentUserEmail: String = "",
    val currentUserName: String = "",
    // Статистика
    val analysisCount: Int = 0,
    val productsCount: Int = 0,
    val recommendationsCount: Int = 0,
    // Флаги для обновления профиля
    val isUpdatingProfile: Boolean = false,
    val profileUpdateSuccess: Boolean = false
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val patientRepository: PatientRepository,
    private val productRepository: ProductRepository,
    private val userRepository: UserRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileState())
    val uiState: StateFlow<ProfileState> = _uiState.asStateFlow()

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        viewModelScope.launch {
            try {
                val userEmail = preferencesManager.getUserEmail().first()
                val userId = preferencesManager.getUserId().first()
                val userName = preferencesManager.getUserName().first()

                Log.d("ProfileViewModel", "Current user - ID: $userId, email: $userEmail, name: $userName")

                if (userId <= 0) {
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка: ID користувача не знайдено. Увійдіть в акаунт знову.",
                        isLoading = false
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(
                    currentUserId = userId,
                    currentUserEmail = userEmail,
                    currentUserName = userName.ifEmpty { extractNameFromEmail(userEmail) }
                )

                // Загружаем полные данные пользователя
                loadUserProfile(userId)
                loadUserStatistics(userId)

            } catch (e: Exception) {
                Log.e("ProfileViewModel", "Error loading current user: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    error = "Помилка завантаження профілю: ${e.message}",
                    isLoading = false
                )
            }
        }
    }

    private fun loadUserProfile(userId: Int) {
        _uiState.value = _uiState.value.copy(isLoading = true)

        viewModelScope.launch {
            // Загружаем данные пользователя
            when (val userResult = userRepository.getUserById(userId)) {
                is Resource.Success -> {
                    Log.d("ProfileViewModel", "User profile loaded: ${userResult.data}")
                    val user = userResult.data
                    _uiState.value = _uiState.value.copy(
                        user = user,
                        currentUserName = user?.fullName ?: extractNameFromEmail(_uiState.value.currentUserEmail)
                    )
                }
                is Resource.Error -> {
                    Log.e("ProfileViewModel", "Error loading user profile: ${userResult.message}")
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка завантаження профілю користувача: ${userResult.message}"
                    )
                }
                is Resource.Loading -> {}
            }

            // Загружаем данные пациента
            when (val patientResult = patientRepository.getPatientById(userId)) {
                is Resource.Success -> {
                    Log.d("ProfileViewModel", "Patient profile loaded: ${patientResult.data}")
                    val patient = patientResult.data
                    _uiState.value = _uiState.value.copy(
                        patient = patient,
                        isLoading = false
                    )

                    // Обновляем имя пользователя из данных пациента если доступно
                    patient?.user?.fullName?.let { name ->
                        _uiState.value = _uiState.value.copy(currentUserName = name)
                    }
                }
                is Resource.Error -> {
                    Log.e("ProfileViewModel", "Error loading patient profile: ${patientResult.message}")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        error = "Помилка завантаження даних пацієнта: ${patientResult.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    private fun loadUserStatistics(userId: Int) {
        viewModelScope.launch {
            // Загружаем статистику параллельно

            // Количество измерений (аналізи)
            launch {
                when (val result = patientRepository.getPatientMeasurements(userId)) {
                    is Resource.Success -> {
                        val count = result.data?.size ?: 0
                        _uiState.value = _uiState.value.copy(analysisCount = count)
                        Log.d("ProfileViewModel", "Measurements count: $count")
                    }
                    is Resource.Error -> {
                        Log.e("ProfileViewModel", "Error loading measurements: ${result.message}")
                        _uiState.value = _uiState.value.copy(analysisCount = 0)
                    }
                    is Resource.Loading -> {}
                }
            }

            // Количество используемых продуктов
            launch {
                when (val result = productRepository.getUsingProducts(userId)) {
                    is Resource.Success -> {
                        val count = result.data?.size ?: 0
                        _uiState.value = _uiState.value.copy(productsCount = count)
                        Log.d("ProfileViewModel", "Using products count: $count")
                    }
                    is Resource.Error -> {
                        Log.e("ProfileViewModel", "Error loading using products: ${result.message}")
                        _uiState.value = _uiState.value.copy(productsCount = 0)
                    }
                    is Resource.Loading -> {}
                }
            }

            // Количество рекомендаций
            launch {
                when (val result = patientRepository.getPatientRecommendations(userId)) {
                    is Resource.Success -> {
                        val count = result.data?.size ?: 0
                        _uiState.value = _uiState.value.copy(recommendationsCount = count)
                        Log.d("ProfileViewModel", "Recommendations count: $count")
                    }
                    is Resource.Error -> {
                        Log.e("ProfileViewModel", "Error loading recommendations: ${result.message}")
                        _uiState.value = _uiState.value.copy(recommendationsCount = 0)
                    }
                    is Resource.Loading -> {}
                }
            }
        }
    }

    fun updateProfile(newName: String, newGender: String, newBirthDate: String, newNotes: String) {
        val currentState = _uiState.value
        val user = currentState.user
        val patient = currentState.patient

        if (user == null) {
            _uiState.value = currentState.copy(error = "Дані користувача не завантажені")
            return
        }

        _uiState.value = currentState.copy(isUpdatingProfile = true, error = null)

        viewModelScope.launch {
            try {
                // Обновляем пользователя
                val updatedUser = user.copy(fullName = newName)

                when (val userResult = userRepository.updateUserProfile(updatedUser)) {
                    is Resource.Success -> {
                        Log.d("ProfileViewModel", "User profile updated successfully")

                        // Если есть данные пациента, обновляем их локально
                        if (patient != null) {
                            val updatedPatient = patient.copy(
                                gender = newGender,
                                birthDate = newBirthDate,
                                notes = newNotes,
                                user = userResult.data!!
                            )

                            _uiState.value = _uiState.value.copy(
                                user = userResult.data,
                                patient = updatedPatient,
                                currentUserName = userResult.data.fullName,
                                isUpdatingProfile = false,
                                profileUpdateSuccess = true
                            )
                        } else {
                            _uiState.value = _uiState.value.copy(
                                user = userResult.data,
                                currentUserName = userResult.data!!.fullName,
                                isUpdatingProfile = false,
                                profileUpdateSuccess = true
                            )
                        }
                    }
                    is Resource.Error -> {
                        Log.e("ProfileViewModel", "Error updating user profile: ${userResult.message}")
                        _uiState.value = _uiState.value.copy(
                            isUpdatingProfile = false,
                            error = "Помилка оновлення профілю: ${userResult.message}"
                        )
                    }
                    is Resource.Loading -> {}
                }

            } catch (e: Exception) {
                Log.e("ProfileViewModel", "Error updating profile: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isUpdatingProfile = false,
                    error = "Помилка оновлення профілю: ${e.message}"
                )
            }
        }
    }

    fun changePassword(oldPassword: String, newPassword: String) {
        val currentState = _uiState.value
        val userId = currentState.currentUserId
        if (userId == null || userId <= 0) {
            _uiState.value = currentState.copy(
                error = "Неможливо змінити пароль: невірний ID користувача"
            )
            return
        }

        _uiState.value = currentState.copy(isUpdatingProfile = true, error = null)

        viewModelScope.launch {
            when (val result = userRepository.changePassword(userId, oldPassword, newPassword)) {
                is Resource.Success -> {
                    Log.d("ProfileViewModel", "Password changed successfully")
                    _uiState.value = _uiState.value.copy(
                        isUpdatingProfile = false,
                        profileUpdateSuccess = true
                    )
                }
                is Resource.Error -> {
                    Log.e("ProfileViewModel", "Error changing password: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        isUpdatingProfile = false,
                        error = "Помилка зміни паролю: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun deleteAccount() {
        val currentState = _uiState.value
        val userId = currentState.currentUserId
        if (userId == null || userId <= 0) {
            _uiState.value = currentState.copy(
                error = "Неможливо видалити акаунт: невірний ID користувача"
            )
            return
        }

        _uiState.value = currentState.copy(isUpdatingProfile = true, error = null)

        viewModelScope.launch {
            when (val result = userRepository.deleteUser(userId)) {
                is Resource.Success -> {
                    Log.d("ProfileViewModel", "Account deleted successfully")
                    // Очищаем данные и разлогиниваем
                    authRepository.logout()
                }
                is Resource.Error -> {
                    Log.e("ProfileViewModel", "Error deleting account: ${result.message}")
                    _uiState.value = _uiState.value.copy(
                        isUpdatingProfile = false,
                        error = "Помилка видалення акаунту: ${result.message}"
                    )
                }
                is Resource.Loading -> {}
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            try {
                Log.d("ProfileViewModel", "Logging out user")
                authRepository.logout()
                Log.d("ProfileViewModel", "Logout successful")
            } catch (e: Exception) {
                Log.e("ProfileViewModel", "Error during logout: ${e.message}")
                _uiState.value = _uiState.value.copy(error = "Помилка при виході з акаунту: ${e.message}")
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    fun clearUpdateSuccess() {
        _uiState.value = _uiState.value.copy(profileUpdateSuccess = false)
    }

    // ИСПРАВЛЕННЫЙ МЕТОД refreshProfile
    fun refreshProfile() {
        Log.d("ProfileViewModel", "refreshProfile called")

        // Сначала проверяем текущий userId из состояния
        val currentUserId = _uiState.value.currentUserId

        if (currentUserId != null && currentUserId > 0) {
            // Если userId есть в состоянии, используем его
            Log.d("ProfileViewModel", "Using currentUserId from state: $currentUserId")
            loadUserProfile(currentUserId)
            loadUserStatistics(currentUserId)
        } else {
            // Если нет, получаем из PreferencesManager
            Log.d("ProfileViewModel", "No userId in state, getting from preferences")
            viewModelScope.launch {
                try {
                    val userId = preferencesManager.getUserId().first()
                    Log.d("ProfileViewModel", "Got userId from preferences: $userId")

                    if (userId > 0) {
                        // Обновляем состояние с полученным userId
                        _uiState.value = _uiState.value.copy(currentUserId = userId)
                        loadUserProfile(userId)
                        loadUserStatistics(userId)
                    } else {
                        _uiState.value = _uiState.value.copy(
                            error = "Неможливо оновити профіль: користувач не авторизований"
                        )
                    }
                } catch (e: Exception) {
                    Log.e("ProfileViewModel", "Error getting userId from preferences: ${e.message}")
                    _uiState.value = _uiState.value.copy(
                        error = "Помилка отримання даних користувача: ${e.message}"
                    )
                }
            }
        }
    }

    private fun extractNameFromEmail(email: String): String {
        return if (email.isNotEmpty()) {
            email.substringBefore("@").replace(".", " ").split(" ")
                .joinToString(" ") { it.replaceFirstChar { char -> char.uppercaseChar() } }
        } else {
            "Користувач"
        }
    }
}