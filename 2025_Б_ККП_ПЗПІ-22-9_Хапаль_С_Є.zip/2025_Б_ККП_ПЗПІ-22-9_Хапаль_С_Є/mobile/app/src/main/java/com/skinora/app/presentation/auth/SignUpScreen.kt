package com.skinora.app.presentation.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.skinora.app.presentation.welcome.KleeOneFamily
import com.skinora.app.presentation.welcome.LightPurple
import com.skinora.app.presentation.welcome.PurpleGradientEnd
import com.skinora.app.presentation.welcome.PurpleGradientStart
import com.skinora.app.ui.components.PurpleWaves
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.skinora.app.R
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.layout.layoutId

@Composable
fun SignUpScreen(
    onSignInClick: () -> Unit,
    onSignUpSuccess: () -> Unit,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val authState by viewModel.authState.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf("patient") }
    val kleeOne = FontFamily(Font(R.font.klee_one_regular))
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp

    // Обработка успешной регистрации
    LaunchedEffect(authState.isLoggedIn) {
        if (authState.isLoggedIn) {
            onSignUpSuccess()
        }
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(screenHeight * 0.9f)
    ) {
        // ЗАДНІЙ фоновий прямокутник нижче хвиль
        Box(
            modifier = Modifier
                .matchParentSize()
                .padding(top = 500.dp)
                .background(Color(0xFFC5BAFF))
        )
        // Хвилі
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(500.dp)
                .align(Alignment.TopCenter)
        ) {
            val back = Path().apply {
                moveTo(0f, size.height * 0.25f)
                quadraticBezierTo(
                    size.width * 0.375f, size.height * 0.25f,
                    size.width * 0.52f, size.height * 0.49f
                )
                quadraticBezierTo(
                    size.width * 0.76f, size.height * 0.85f,
                    size.width, size.height * 0.54f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(back, color = Color(0xFFD3CBFF))

            val front = Path().apply {
                moveTo(0f, size.height * 0.30f)
                quadraticBezierTo(
                    size.width * 0.38f, size.height * 0.30f,
                    size.width * 0.56f, size.height * 0.57f
                )
                quadraticBezierTo(
                    size.width * 0.78f, size.height * 0.85f,
                    size.width, size.height * 0.63f
                )
                lineTo(size.width, size.height)
                lineTo(0f, size.height)
                close()
            }
            drawPath(front, color = Color(0xFFC5BAFF))
        }


                Text(
                    text = "Sign up",
                    fontFamily = kleeOne,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.Black,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 24.dp, top = screenHeight * 0.25f)
                )

                Text(
                    text = "Зареєструвати свій акаунт",
                    color = Color.Black,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 24.dp, top = screenHeight * 0.30f)
                )

            Spacer(modifier = Modifier.height(32.dp))

            // Форма регистрации
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 400.dp, start = 24.dp, end = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                    // Имя
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(text = "Ім'я", fontSize = 18.sp) },
                        shape = RoundedCornerShape(32.dp),
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xFFFBFBFB),
                            focusedContainerColor = Color(0xFFFBFBFB),
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        )
                    )

                    // Email
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text(text = "Адреса електронної пошти", fontSize = 18.sp) },
                        shape = RoundedCornerShape(32.dp),
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xFFFBFBFB),
                            focusedContainerColor = Color(0xFFFBFBFB),
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email
                        )
                    )

                    // Password
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),
                        label = { Text(text = "Пароль", fontSize = 18.sp) },
                        shape = RoundedCornerShape(32.dp),
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xFFFBFBFB),
                            focusedContainerColor = Color(0xFFFBFBFB),
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        )
                    )

                    // Confirm Password
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text(text = "Підтвердити пароль", fontSize = 18.sp) },
                        shape = RoundedCornerShape(32.dp),
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = Color(0xFFFBFBFB),
                            focusedContainerColor = Color(0xFFFBFBFB),
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        ),
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),

                        isError = confirmPassword.isNotEmpty() && password != confirmPassword
                    )

                    // Выбор роли
                    RoleSelector(
                        selectedRole = selectedRole,
                        onRoleSelected = { selectedRole = it }
                    )

                    // Кнопка Sign Up
                    Button(
                        onClick = {
                            if (name.isNotBlank() &&
                                email.isNotBlank() &&
                                password.isNotBlank() &&
                                password == confirmPassword) {
                                viewModel.register(name, email, password, selectedRole)
                            }
                        },
                        enabled = !authState.isLoading &&
                                name.isNotBlank() &&
                                email.isNotBlank() &&
                                password.isNotBlank() &&
                                password == confirmPassword,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFBFBFB),
                            contentColor = Color.Black,
                        )
                    ) {
                        if (authState.isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White
                            )
                        } else {
                            Text(text = "Sign up", fontSize = 18.sp, fontFamily = kleeOne)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Переход на вход
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(
                    onClick = onSignInClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text(
                        text = "Sign in",
                        fontSize = 16.sp,
                        fontFamily = KleeOneFamily,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF2D1B69)
                    )
                }
            }


        // Показ ошибок
        authState.error?.let { error ->
            Card(
                modifier = Modifier
                    .padding(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFEF4444)
                )
            ) {
                Text(
                    text = error,
                    modifier = Modifier.padding(16.dp),
                    color = Color.White,
                    fontFamily = KleeOneFamily
                )
            }
        }
    }

@Composable
private fun RoleSelector(
    selectedRole: String,
    onRoleSelected: (String) -> Unit
) {
    Column {
        Text(
            text = "Я пацієнт",
            fontFamily = KleeOneFamily,
            fontSize = 14.sp,
            color = Color(0xFF6B7280),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                onClick = { onRoleSelected("patient") },
                label = {
                    Text(
                        "Пацієнт",
                        fontFamily = KleeOneFamily
                    )
                },
                selected = selectedRole == "patient",
                modifier = Modifier.weight(1f)
            )

            FilterChip(
                onClick = { onRoleSelected("doctor") },
                label = {
                    Text(
                        "Лікар",
                        fontFamily = KleeOneFamily
                    )
                },
                selected = selectedRole == "doctor",
                modifier = Modifier.weight(1f)
            )
        }
    }
}