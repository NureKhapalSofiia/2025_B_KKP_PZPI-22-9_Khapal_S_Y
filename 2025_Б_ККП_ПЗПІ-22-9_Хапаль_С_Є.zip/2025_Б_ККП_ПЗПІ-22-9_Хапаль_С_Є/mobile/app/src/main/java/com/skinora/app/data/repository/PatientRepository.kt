package com.skinora.app.data.repository

import com.skinora.app.data.api.PatientApi
import com.skinora.app.data.model.*
import com.skinora.app.utils.Resource
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PatientRepository @Inject constructor(
    private val patientApi: PatientApi
) {

    suspend fun getPatientById(patientId: Int): Resource<Patient> {
        return try {
            val response = patientApi.getPatientById(patientId)
            if (response.isSuccessful) {
                response.body()?.let {
                    Resource.Success(it)
                } ?: Resource.Error("Patient not found")
            } else {
                Resource.Error("Failed to get patient: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getPatientMeasurements(patientId: Int): Resource<List<Measurement>> {
        return try {
            val response = patientApi.getPatientMeasurements(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get measurements: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getPatientRecommendations(patientId: Int): Resource<List<Recommendation>> {
        return try {
            val response = patientApi.getPatientRecommendations(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get recommendations: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getPatientUsedProducts(patientId: Int): Resource<List<UsedProduct>> {
        return try {
            val response = patientApi.getPatientUsedProducts(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get used products: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    // Дополнительные методы для совместимости с разными endpoints
    suspend fun getMeasurementsByPatient(patientId: Int): Resource<List<Measurement>> {
        return try {
            val response = patientApi.getMeasurementsByPatient(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get measurements: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }

    suspend fun getRecommendationsByPatient(patientId: Int): Resource<List<Recommendation>> {
        return try {
            val response = patientApi.getRecommendationsByPatient(patientId)
            if (response.isSuccessful) {
                Resource.Success(response.body() ?: emptyList())
            } else {
                Resource.Error("Failed to get recommendations: ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error("Network error: ${e.message}")
        }
    }
}