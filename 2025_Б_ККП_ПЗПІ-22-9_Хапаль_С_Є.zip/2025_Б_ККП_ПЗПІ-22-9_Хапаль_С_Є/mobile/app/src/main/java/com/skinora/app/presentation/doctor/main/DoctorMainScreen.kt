package com.skinora.app.presentation.doctor.main

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.skinora.app.presentation.doctor.home.DoctorHomeScreen
import com.skinora.app.presentation.doctor.chat.DoctorChatScreen
import com.skinora.app.presentation.doctor.chat.DoctorChatDetailScreen
import com.skinora.app.presentation.doctor.profile.DoctorProfileScreen
import com.skinora.app.presentation.doctor.recommendations.CreateRecommendationScreen
import com.skinora.app.presentation.doctor.products.AssignProductScreen
import com.skinora.app.ui.components.DoctorBottomNavigation
import com.skinora.app.ui.components.DoctorBottomNavItem

// Navigation routes для докторов
object DoctorRoutes {
    const val HOME = "doctor_home"
    const val CHAT = "doctor_chat"
    const val PROFILE = "doctor_profile"
    const val CREATE_RECOMMENDATION = "create_recommendation"
    const val ASSIGN_PRODUCT = "assign_product"
    const val CHAT_DETAIL = "doctor_chat_detail"
}

@Composable
fun DoctorMainScreen(
    onLogout: () -> Unit
) {
    val navController = rememberNavController()
    var currentRoute by remember { mutableStateOf(DoctorBottomNavItem.Home.route) }

    Scaffold(
        bottomBar = {
            DoctorBottomNavigation(
                currentRoute = currentRoute,
                onItemClick = { route ->
                    currentRoute = route
                    navController.navigate(route) {
                        // Очистка back stack для предотвращения накопления экранов
                        popUpTo(DoctorBottomNavItem.Home.route) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = DoctorBottomNavItem.Home.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            // Главная страница доктора
            composable(DoctorBottomNavItem.Home.route) {
                DoctorHomeScreen(
                    onCreateRecommendationClick = {
                        navController.navigate(DoctorRoutes.CREATE_RECOMMENDATION)
                    },
                    onAssignProductClick = {
                        navController.navigate(DoctorRoutes.ASSIGN_PRODUCT)
                    }
                )
            }

            // Чаты доктора
            composable(DoctorBottomNavItem.Chat.route) {
                DoctorChatScreen(
                    onChatClick = { chat ->
                        // Передаем ID чата через аргументы
                        navController.navigate("${DoctorRoutes.CHAT_DETAIL}/${chat.id}")
                    }
                )
            }

            // Профиль доктора
            composable(DoctorBottomNavItem.Profile.route) {
                DoctorProfileScreen(
                    onLogout = onLogout
                )
            }

            // Создание рекомендации
            composable(DoctorRoutes.CREATE_RECOMMENDATION) {
                CreateRecommendationScreen(
                    onBackClick = {
                        navController.popBackStack()
                    },
                    onRecommendationCreated = {
                        navController.popBackStack()
                    }
                )
            }

            // Назначение продукта
            composable(DoctorRoutes.ASSIGN_PRODUCT) {
                AssignProductScreen(
                    onBackClick = {
                        navController.popBackStack()
                    },
                    onProductAssigned = {
                        navController.popBackStack()
                    }
                )
            }

            // Детальный чат
            composable(
                route = "${DoctorRoutes.CHAT_DETAIL}/{chatId}",
                arguments = listOf(navArgument("chatId") { type = NavType.IntType })
            ) { backStackEntry ->
                val chatId = backStackEntry.arguments?.getInt("chatId") ?: return@composable

                // Создаем dummy chat для демонстрации
                val dummyChat = createDummyChatById(chatId)

                DoctorChatDetailScreen(
                    chat = dummyChat,
                    onBackClick = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}

// Helper functions для создания dummy данных (пока API не готово)
private fun createDummyPatient(patientId: Int = 1): com.skinora.app.data.model.Patient {
    val patientNames = mapOf(
        1 to "Іван Петренко",
        2 to "Марія Коваленко",
        3 to "Олексій Іванов"
    )

    return com.skinora.app.data.model.Patient(
        id = patientId,
        birthDate = "1995-03-15",
        gender = "Чоловіча",
        notes = "Проблеми з сухістю шкіри та подразненням",
        user = com.skinora.app.data.model.User(
            id = patientId,
            email = "patient$patientId@example.com",
            passwordHash = "",
            fullName = patientNames[patientId] ?: "Пацієнт №$patientId",
            avatarUrl = null,
            role = com.skinora.app.data.model.Role(3, "patient"),
            isActive = true,
            createdAt = "2024-12-01T00:00:00",
            updatedAt = "2024-12-01T00:00:00"
        ),
        doctor = null
    )
}

private fun createDummyDoctor(): com.skinora.app.data.model.Doctor {
    return com.skinora.app.data.model.Doctor(
        id = 1,
        specialization = "Дерматолог",
        experienceYears = 8,
        bio = "Досвідчений дерматолог",
        user = com.skinora.app.data.model.User(
            id = 6,
            email = "doctor@clinic.com",
            passwordHash = "",
            fullName = "Др. Іванова Марія",
            avatarUrl = null,
            role = com.skinora.app.data.model.Role(2, "doctor"),
            isActive = true,
            createdAt = "2024-12-01T00:00:00",
            updatedAt = "2024-12-01T00:00:00"
        )
    )
}

private fun createDummyChatById(chatId: Int): com.skinora.app.data.model.Chat {
    return com.skinora.app.data.model.Chat(
        id = chatId,
        participant1 = createDummyPatient(chatId),
        participant2 = createDummyDoctor()
    )
}