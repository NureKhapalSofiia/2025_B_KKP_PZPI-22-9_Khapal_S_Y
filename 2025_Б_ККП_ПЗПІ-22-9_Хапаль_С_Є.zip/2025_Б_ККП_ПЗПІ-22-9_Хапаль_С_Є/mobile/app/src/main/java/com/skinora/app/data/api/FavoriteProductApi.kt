package com.skinora.app.data.api

import com.skinora.app.data.model.FavoriteProduct
import retrofit2.Response
import retrofit2.http.*

interface FavoriteProductApi {

    @POST("favorites/add")
    suspend fun addFavoriteProduct(
        @Query("patientId") patientId: Int,
        @Query("productId") productId: Int
    ): Response<FavoriteProduct>

    @DELETE("favorites/remove")
    suspend fun removeFavoriteProduct(
        @Query("patientId") patientId: Int,
        @Query("productId") productId: Int
    ): Response<Unit>

    @GET("favorites/patient/{patientId}")
    suspend fun getFavoritesByPatient(
        @Path("patientId") patientId: Int
    ): Response<List<FavoriteProduct>>
}