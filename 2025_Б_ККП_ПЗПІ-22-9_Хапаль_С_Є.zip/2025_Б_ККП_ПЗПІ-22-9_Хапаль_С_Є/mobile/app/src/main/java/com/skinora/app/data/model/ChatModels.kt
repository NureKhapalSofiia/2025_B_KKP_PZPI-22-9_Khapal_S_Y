package com.skinora.app.data.model

import com.google.gson.annotations.SerializedName

data class Chat(
    val id: Int,
    @SerializedName("participant1")
    val participant1: Patient,
    @SerializedName("participant2")
    val participant2: Doctor
)

data class Message(
    val id: Int?,
    val message: String,
    // ИСПРАВЛЕНО: сервер возвращает "sentAt", а не "sent_at"
    val sentAt: String?,
    // ИСПРАВЛЕНО: сервер возвращает "isRead", а не "is_read"
    val isRead: Boolean,
    val chatId: Int?,
    val senderId: Int
)

data class SendMessageRequest(
    val message: String,
    val senderId: Int
)

// Отдельная модель для поиска докторов
data class DoctorSearchResult(
    val id: Int,
    val specialization: String?,
    @SerializedName("expirienceYears")  // с опечаткой как на сервере
    val experienceYears: Int,
    val bio: String?,
    val user: User?
)